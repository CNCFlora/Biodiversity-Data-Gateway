###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 07/06/2022, Pablo H.
################################################################################################################################

#' @section Tabela Flora e Funga do Brasil IPT

 
print('carregando tabela Flora e Funga do Brasil IPT...')

FloraBrasil2020 <- read.csv("C:\\BiodiversityDataGateway\\data\\ipt\\FB2020.csv", row.names = 1, fileEncoding = "UTF-8") 

FB2020_get_taxon_scientificname_from_IPT_v2 <- function(binomialSearch, 
                                                        FloraBrasil2020_tmp=FloraBrasil2020,
                                                        somente_especie = FALSE) 
{
   
   
   if (somente_especie==TRUE)
   {   
      binomialSearch <- paste0(word(binomialSearch,1), ' ', word(binomialSearch,2))
   }
   
   # colnames(FloraBrasil2020_tmp) <- paste0(colnames(FloraBrasil2020_tmp),'_FB2020')
   thirdWord <- word(binomialSearch,3)
   withAuthor <- (!is.na(thirdWord)) & (! tolower(thirdWord) %in% c('form.', 'var.', 'subsp.'))
   camposFB <- FloraBrasil2020_tmp[1,]
   camposFB[1,] <- NA

   FB2020 <- list(found = data.frame(found = FALSE),
                  acceptedName = data.frame(camposFB,
                                            searchNotes='Name not found',
                                            searchName=binomialSearch),
                  synonyms = data.frame(NULL),
                  infrataxa = data.frame(NULL),
                  searchNotes='Name not found')
   
   if (is.na(word(binomialSearch,2)))
   {
      FB2020$acceptedName$searchNotes <- 'Inform a binomial, Genus species'
      FB2020$searchNotes <- FB2020$acceptedName$searchNotes
      print(FB2020$searchNotes)
      return(FB2020)
   }

   if (withAuthor == FALSE) 
   { 
      spp_ipt <- FloraBrasil2020_tmp %>%
         dplyr::filter( scientificNamewithoutAuthorship_FB2020 %in% binomialSearch)
   } else 
   {
      spp_ipt <- FloraBrasil2020_tmp %>%
         dplyr::filter(raster::trim(scientificName_FB2020 )  %in% raster::trim(binomialSearch))
   }
   
   
   FB2020$found <- NROW(spp_ipt) > 0
   
   # nome não encontrado
   if ( FB2020$found==FALSE )
   {
      
      # {
      #    spp_ipt2 <- FloraBrasil2020_tmp %>%
      #       dplyr::filter(grepl(binomialSearch, 
      #                           FloraBrasil2020_tmp$acceptedNameUsage_FB2020,
      #                           ignore.case = TRUE) &
      #                        taxonomicStatus_FB2020 == 'NOME_ACEITO')
      #    if ( NROW(spp_ipt2)==0 )
      #    {
      #       FB2020 <- list(found = data.frame(found = TRUE),
      #                      acceptedName = data.frame(camposFB,#spp_ipt,
      #                                                searchNotes='Não ocorre no Brasil',
      #                                                searchName=binomialSearch),
      #                      synonyms = data.frame(NULL),
      #                      infrataxa = data.frame(NULL),
      #                      searchNotes='Não ocorre no Brasil')
      #       print(FB2020$searchNotes)
      #       return(FB2020) 
      # }
      #    
      # }
      
      FB2020$acceptedName <- FB2020$acceptedName %>%
         dplyr::mutate(searchNotes='Name not found')
      
      FB2020$searchNotes <- FB2020$acceptedName$searchNotes
      
      # FB2020$found <- FALSE
      print(FB2020$searchNotes) 
      return(FB2020)
   }
   
   if (any(spp_ipt$taxonomicStatus_FB2020 %in% "NOME_ACEITO" )==TRUE)
   {
      FB2020$acceptedName <- spp_ipt %>%
         dplyr::filter(taxonomicStatus_FB2020 %in% "NOME_ACEITO") %>%
         dplyr::mutate(searchNotes='Matching name',
                       searchName=binomialSearch)
      
      FB2020$searchNotes <- FB2020$acceptedName$searchNotes
   } else
   {     
      # sinônimos homônimos
      if (nrow(spp_ipt)>1)
      {
         x_names <- spp_ipt$scientificName_FB2020[1]
         for (ix in 2:NROW(spp_ipt)) 
         {x_names <- paste0(x_names, ', ', spp_ipt$scientificName_FB2020[ix])}
         
         # teste para recuperacao do s. hom. valido
         ###
         spp_iptx <- spp_ipt %>%
            dplyr::filter(taxonomicStatus_FB2020=='NOME_ACEITO') %>%
            dplyr::mutate(searchNotes=paste0('Enter binomial + author for exact resolution: ',NROW(spp_ipt), ' names found (', x_names,')'))
         
         if (NROW(spp_iptx) == 1)
         {
            # se achar
            FB2020$acceptedName <- spp_iptx
            FB2020$searchNotes <- FB2020$acceptedName$searchNotes
            FB2020$found <- TRUE
         } else
         {
            FB2020$acceptedName <- FB2020$acceptedName %>%
               dplyr::mutate(searchNotes=paste0('Enter binomial + author for exact resolution: ',NROW(spp_ipt), ' names found (', x_names,')'),
                             searchName=binomialSearch)
            FB2020$searchNotes <- FB2020$acceptedName$searchNotes
            FB2020$found <- FALSE
         }
         print(FB2020$searchNotes) 
         return(FB2020)
      } 
      
      # situação taxonômica não definida
      if (spp_ipt$taxonomicStatus_FB2020 == "" |
          is.na(spp_ipt$taxonomicStatus_FB2020))
      {
         FB2020$acceptedName <- FB2020$acceptedName %>%
            dplyr::mutate(searchNotes='Name without resolution',
                          searchName=binomialSearch)
         
         FB2020$searchNotes <- FB2020$acceptedName$searchNotes
         
         FB2020$found <- FALSE
         
         print(FB2020$searchNotes) 
         
         return(FB2020)
      } 
      
      # sinônimo sem resolução
      if (spp_ipt$taxonomicStatus_FB2020 == "SINONIMO" & is.na(spp_ipt$acceptedNameUsageID_FB2020) )
      {
         FB2020$acceptedName <- FB2020$acceptedName %>%
            # dplyr::mutate(searchNotes= paste0('Database inconsistency, check website: ( ',references_2020,' )'),
            dplyr::mutate(searchNotes= paste0('Database inconsistency, check website'),
                          searchName=binomialSearch)
         
         FB2020$searchNotes <- FB2020$acceptedName$searchNotes
         
         FB2020$found <- FALSE
         
         print(FB2020$searchNotes) 
         
         return(FB2020)
      }
      
      ### atualizar nome aceito em caso de sinônimo
      if (spp_ipt$taxonomicStatus_FB2020 == "SINONIMO" & !is.na(spp_ipt$acceptedNameUsageID_FB2020) )
      {
         FB2020$acceptedName <- FloraBrasil2020_tmp %>%
            dplyr::filter(id_FB2020 %in% spp_ipt$acceptedNameUsageID_FB2020) %>%
            dplyr::mutate(searchNotes='Updated synonym',
                          searchName=binomialSearch)
         
         if (NROW(FB2020$acceptedName)==0)#(FB2020$searchNotes=="Name not found")
         {
            FB2020 <- list(found = data.frame(found = TRUE),
                           acceptedName = data.frame(camposFB,#spp_ipt,
                                                     searchNotes='Não ocorre no Brasil',
                                                     searchName=binomialSearch),
                           synonyms = data.frame(NULL),
                           infrataxa = data.frame(NULL),
                           searchNotes='Não ocorre no Brasil')
            print(FB2020$searchNotes)
            return(FB2020)
         }
            
         FB2020$searchNotes <- FB2020$acceptedName$searchNotes
         
      }    
      ###
   }
   
   # synonyms <-  plyr::ldply(returnFB2020$result$SINONIMO, data.frame)
   FB2020$synonyms <- FloraBrasil2020_tmp %>%
      dplyr::filter(parentNameUsageID_FB2020 %in% FB2020$acceptedName$id_FB2020 &
                       taxonomicStatus_FB2020 %in% "SINONIMO") %>%
      dplyr::mutate(searchName=binomialSearch)
   
   # infrataxa
   FB2020$infrataxa <- FloraBrasil2020_tmp %>%
      dplyr::filter(parentNameUsageID_FB2020 %in% FB2020$acceptedName$id_FB2020 &
                       taxonomicStatus_FB2020 == 'NOME_ACEITO' & 
                       !is.na(infraspecificEpithet_FB2020) ) %>%
      dplyr::mutate(searchName=binomialSearch)
   
   FB2020$searchNotes <- 'OK'
   
   return(FB2020)
   
}



# binomialSearch = 'Gordonia fruticosa var. sericea'

# binomialSearch <- 'Poidium calotheca'
# binomialSearch <- 'Blechnum acutum'

# binomialSearch <- 'Blechnum acutum'
# binomialSearch <- 'Lomaridium acutum'
# binomialSearch <- "Odontoschisma splendens"
# binomialSearch <- "Piper corcovadense"
# x <- FB2020_get_taxon_scientificname_from_IPT_v2(binomialSearch)
# x$found
# x$acceptedName


FB2020_get_taxon_scientificname_from_IPT <- function(binomialSearch) 
{
   
   colnames(FloraBrasil2020) <- paste0(colnames(FloraBrasil2020),'_FB2020')
   
   # colnames(FloraBrasil2020) <- paste0(colnames(FloraBrasil2020),'_FB2020')
   thirdWord <- word(binomialSearch,3)
   withAuthor <- (!is.na(thirdWord)) & (! tolower(thirdWord) %in% c('form.', 'var.', 'subsp.'))
   camposFB <- FloraBrasil2020[1,]
   camposFB[1,] <- NA
   
   FB2020 <- list(found = data.frame(found = FALSE),
                  acceptedName = data.frame(camposFB,
                                            searchNotes='Name not found',
                                            searchName=binomialSearch),
                  synonyms = data.frame(NULL),
                  infrataxa = data.frame(NULL),
                  searchNotes='Name not found')
   
   
   if (withAuthor == FALSE) 
   { 
      spp_ipt <- FloraBrasil2020 %>%
         dplyr::filter( scientificNamewithoutAuthorship_FB2020 %in% binomialSearch)
   } else 
   {
      spp_ipt <- FloraBrasil2020 %>%
         dplyr::filter(raster::trim(scientificName_FB2020 )  %in% raster::trim(binomialSearch))
   }
   
   
   FB2020$found <- NROW(spp_ipt) > 0
   
   # nome não encontrado
   if ( FB2020$found==FALSE )
   {  
      FB2020$acceptedName <- FB2020$acceptedName %>%
         dplyr::mutate(searchNotes='Name not found')
      
      FB2020$searchNotes <- FB2020$acceptedName$searchNotes
      
      # FB2020$found <- FALSE
      # print(FB2020$searchNotes) 
      
      return(FB2020)
   }
   
   if (any(spp_ipt$taxonomicStatus_FB2020 %in% "NOME_ACEITO" )==TRUE)
   {
      FB2020$acceptedName <- spp_ipt %>%
         dplyr::filter(taxonomicStatus_FB2020 %in% "NOME_ACEITO") %>%
         dplyr::mutate(searchNotes='Matching name',
                       searchName=binomialSearch)
      
      FB2020$searchNotes <- FB2020$acceptedName$searchNotes
   } else
   {     
      # sinônimos homônimos
      if (nrow(spp_ipt)>1)
      {
         x_names <- spp_ipt$scientificName_FB2020[1]
         for (ix in 2:NROW(spp_ipt)) 
         {x_names <- paste0(x_names, ', ', spp_ipt$scientificName_FB2020[ix])}
         
         # teste para recuperacao do s. hom. valido
         ###
         spp_iptx <- spp_ipt %>%
            dplyr::filter(taxonomicStatus_FB2020=='NOME_ACEITO') %>%
            dplyr::mutate(searchNotes=paste0('Enter binomial + author for exact resolution: ',NROW(spp_ipt), ' names found (', x_names,')'))
         
         if (NROW(spp_iptx) == 1)
         {
            # se achar
            FB2020$acceptedName <- spp_iptx
            FB2020$searchNotes <- FB2020$acceptedName$searchNotes
            FB2020$found <- TRUE
         } else
         {
            FB2020$acceptedName <- FB2020$acceptedName %>%
               dplyr::mutate(searchNotes=paste0('Enter binomial + author for exact resolution: ',NROW(spp_ipt), ' names found (', x_names,')'),
                             searchName=binomialSearch)
            FB2020$searchNotes <- FB2020$acceptedName$searchNotes
            FB2020$found <- FALSE
         }
         print(FB2020$searchNotes) 
         
         return(FB2020)
      } 
      
      # situação taxonômica não definida
      if (spp_ipt$taxonomicStatus_FB2020 == "" |
          is.na(spp_ipt$taxonomicStatus_FB2020))
      {
         FB2020$acceptedName <- FB2020$acceptedName %>%
            dplyr::mutate(searchNotes='Name without resolution',
                          searchName=binomialSearch)
         
         FB2020$searchNotes <- FB2020$acceptedName$searchNotes
         
         FB2020$found <- FALSE
         
         print(FB2020$searchNotes) 
         
         return(FB2020)
      } 
      
      # sinônimo sem resolução
      if (spp_ipt$taxonomicStatus_FB2020 == "SINONIMO" & is.na(spp_ipt$acceptedNameUsageID_FB2020) )
      {
         FB2020$acceptedName <- FB2020$acceptedName %>%
            dplyr::mutate(searchNotes= paste0('Database inconsistency, check website: ( ',references,' )'),
                          searchName=binomialSearch)
         
         FB2020$searchNotes <- FB2020$acceptedName$searchNotes
         
         FB2020$found <- FALSE
         
         print(FB2020$searchNotes) 
         
         return(FB2020)
      }
      
      ### atualizar nome aceito em caso de sinônimo
      if (spp_ipt$taxonomicStatus_FB2020 == "SINONIMO" & !is.na(spp_ipt$acceptedNameUsageID_FB2020) )
      {
         
         FB2020$acceptedName <- FloraBrasil2020 %>%
            dplyr::filter(id_FB2020 %in% spp_ipt$acceptedNameUsageID_FB2020) %>%
            dplyr::mutate(searchNotes='Updated synonym',
                          searchName=binomialSearch)
         
         FB2020$searchNotes <- FB2020$acceptedName$searchNotes
         
      }    
      ###
   }
   
   # synonyms <-  plyr::ldply(returnFB2020$result$SINONIMO, data.frame)
   FB2020$synonyms <- FloraBrasil2020 %>%
      dplyr::filter(parentNameUsageID_FB2020 %in% FB2020$acceptedName$id_FB2020 &
                       taxonomicStatus_FB2020 %in% "SINONIMO") %>%
      dplyr::mutate(searchName=binomialSearch)
   
   # infrataxa
   FB2020$infrataxa <- FloraBrasil2020 %>%
      dplyr::filter(parentNameUsageID_FB2020 %in% FB2020$acceptedName$id_FB2020 &
                       taxonomicStatus_FB2020 == 'NOME_ACEITO' & 
                       !is.na(infraspecificEpithet_FB2020) ) %>%
      dplyr::mutate(searchName=binomialSearch)
   
   FB2020$searchNotes <- 'OK'
   
   return(FB2020)
   
# else
#    {
#       w1 <- word(binomialSearch,1)
#       w2 <- word(binomialSearch,2)
#       w3 <- word(binomialSearch,3)
#       w4 <- word(binomialSearch,4)
#       
#       infrataxa_in <- (!is.na(w3)) & (! tolower(w3) %in% c('form.', 'var.', 'subsp.'))
#       
#       try({
#          FB2020URL <- sprintf("http://servicos.jbrj.gov.br/flora/taxon/%s",  list(page = paste0(w1, ' ', w2)))
#          returnFB2020 <- jsonlite::read_json(FB2020URL, simplifyVector=TRUE)
#          FB2020$found <- !is.null(returnFB2020$result)
#       })
#       
#       if ( FB2020$found==TRUE ) 
#       {  
#          acceptedName <- returnFB2020$result[1:14] %>%
#             dplyr::mutate(scientificNameWithoutAuthor =
#                              str_remove(
#                                 scientificname %>%
#                                    stringr::str_replace_all("[/' '()]", " ") %>%
#                                    stringr::str_replace_all(" +", " ") %>%
#                                    stringr::str_replace(" $", ""),
#                                 paste0(' ', scientificnameauthorship) %>%
#                                    stringr::str_replace_all("[/' '()]", " ") %>%
#                                    stringr::str_replace_all(" +", " ") %>%
#                                    stringr::str_replace(" $", "")) ) %>%
#             dplyr::mutate(searchNotes='Matching name',
#                           searchName=binomialSearch)
#          
#          acceptedName <- acceptedName %>%
#             dplyr::filter(trim(scientificNameWithoutAuthor)  %in% trim(binomialSearch))
#          
#          # não achou nada
#          if (nrow(acceptedName)==0)
#          {
#             FB2020$acceptedName <- FB2020$acceptedName %>%
#                dplyr::mutate(searchNotes='Name not found')
#             
#             FB2020$searchNotes <- FB2020$acceptedName$searchNotes
#             
#             FB2020$found <- FALSE
#             
#             print(FB2020$searchNotes) 
#             
#             return(FB2020)
#          }
#          
#          
#          synonyms <-  plyr::ldply(returnFB2020$result$SINONIMO, data.frame)
#          
#          if ( NROW(synonyms)>0)
#          {  
#             
#             synonyms <- synonyms %>%
#                mutate(scientificNameWithoutAuthor =  str_remove(
#                   scientificname %>%   
#                      stringr::str_replace_all("[/' '()]", " ") %>% 
#                      stringr::str_replace_all(" +", " ") %>%        
#                      stringr::str_replace(" $", ""),                
#                   paste0(' ', scientificnameauthorship) %>%    
#                      stringr::str_replace_all("[/' '()]", " ") %>% 
#                      stringr::str_replace_all(" +", " ") %>%        
#                      stringr::str_replace(" $", "")),
#                   searchName=binomialSearch) 
#          }  
#          
#          FB2020$acceptedName <- data.frame(acceptedName)
#          FB2020$synonyms <- data.frame(synonyms)
#          FB2020$searchNotes <- FB2020$acceptedName$searchNotes
#       }
#    }  
#    print(FB2020$searchNotes) 
#    
#    return(FB2020)   
}



####
# group

FB2020_get_group <- function(x)
{
   if (is.na(x))
   {return('')}
   # higherClassification <- FloraBrasil2020_tmp$higherClassification[999] %>% as_tibble()
   x <- x %>% as_tibble()
   group <- x$value %>% str_split(.,pattern = ';', simplify = TRUE)
   group <- group[2]
   return(group)
}
# group <- lapply(FloraBrasil2020$higherClassification, FB2020_get_group)
# group <- ldply(group, data.frame) 
# colnames(group) <- 'group'
# FloraBrasil2020$group <- group$group %>% as.character()

###

FB2020_to_table <- function(FloraBrasil2020)
{
   
   # group
   group <- FB2020_get_group(FloraBrasil2020$higherClassification)
   group <- lapply(FloraBrasil2020$higherClassification, FB2020_get_group)
   group <- ldply(group, data.frame) 
   group
   
   # phytogeographicDomain
   phytogeographicDomain <- lapply(FloraBrasil2020$occurrenceRemarks, FB2020_get_phytogeographicDomain)
   phytogeographicDomain <- ldply(phytogeographicDomain, data.frame) 
   phytogeographicDomain
   
   # lifeForm
   lifeForm <- lapply(FloraBrasil2020$lifeForm, FB2020_get_lifeForm)
   lifeForm <- ldply(lifeForm, data.frame) 
   lifeForm
   
   # habitat
   lifeForm <- lapply(FloraBrasil2020$lifeForm, FB2020_get_lifeForm)
   lifeForm <- ldply(lifeForm, data.frame) 
   lifeForm
   
   # vegetationType
   vegetationType <- lapply(FloraBrasil2020$vegetationType, FB2020_get_vegetationType)
   vegetationType <- ldply(vegetationType, data.frame) 
   vegetationType
   
   # IUCN vegetationType X FB2020 X CNCFlora
   IUCN_vegetationType <- lapply(FloraBrasil2020$vegetationType, FB2020_get_IUCN_vegetationType,
                                 vegetationType.IUCN_CNCFlora_FB2020)
   IUCN_vegetationType <- ldply(IUCN_vegetationType, data.frame) 
   IUCN_vegetationType
   
   # endemism
   endemism <- lapply(returnFB2020$distribuition[[1]]$occurrenceremarks$endemism, FB2020_get_IUCN_endemism)
   endemism <- ldply(endemism, data.frame)
   endemism
   
   establishmentmeans
   
   vernacular_name
   
}

# group
{
   FB2020_get_group <- function(higherclassification)
   {
      # higherClassification <- FloraBrasil2020$higherClassification[999] %>% as_tibble()
      higherClassification <- higherClassification %>% as_tibble()
      group <- higherClassification$value %>% str_split(.,pattern = ';', simplify = TRUE)
      group <- group[2]
      return(group)
   }
}


# UF
{
FB2020_get_UF <- function(uf)
{
   uf.d <- data.frame( AC=0, AL=0, AM=0, AP=0, BA=0, CE=0, DF=0, ES=0, GO=0, MA=0, MG=0,MS=0, MT=0, PA=0, PB=0, PE=0, PI=0, PR=0, RJ=0, RN=0, RO=0, RR=0, RS=0, SC=0, SE=0, SP=0, TO=0)      
   uf = gsub('BR-', '', uf)
   uf = strsplit(uf, '-')[[1]]
   i=1
   for (i in 1:NROW(uf))
   {
      d2 <-  colnames(uf.d) %in% uf[i]
      uf.d[1,d2] <- 1
   }
   uf.d
   return(uf.d)
}

# uf <- lapply(FloraBrasil2020$location[1:5000], FB2020_get_UF)
# uf <- ldply(uf, data.frame) 
# uf
}

# phytogeographicDomain
{
FB2020_get_phytogeographicDomain <- function(phytogeographicDomain)
{
   # phytogeographicDomain <- FloraBrasil2020$occurrenceRemarks[999]
   phytogeographicDomain.d <- data.frame( `Amazônia`=0, Caatinga=0, Cerrado=0, `Mata_Atlântica`=0, Pampa=0, Pantanal=0)      
   phytogeographicDomain <- gsub('Não endemica|Endemica|/', '', phytogeographicDomain)
   phytogeographicDomain = strsplit(phytogeographicDomain, '-')[[1]]
   phytogeographicDomain
   i=1
   for (i in 1:NROW(phytogeographicDomain))
   {
      d2 <-  sub('_',' ', colnames(phytogeographicDomain.d)) %in% phytogeographicDomain[i]
      phytogeographicDomain.d[1,d2] <- 1
   }
   phytogeographicDomain.d
   return(phytogeographicDomain.d)
}

# phytogeographicDomain <- lapply(FloraBrasil2020$occurrenceRemarks[1:5000], FB2020_get_phytogeographicDomain)
# phytogeographicDomain <- ldply(phytogeographicDomain, data.frame) 
# phytogeographicDomain
}

# lifeForm
{
FB2020_get_lifeForm <- function(lifeForm)
{
   lifeForm <- lifeForm  %>% as.character()
   
   # lifeForm <- FloraBrasil2020$lifeForm[963]  %>% as.character()
   # 
   lifeForm.d  <- data.frame(`Árvore` = 0,
                             Subarbusto = 0,
                              Arbusto = 0,
                              Erva = 0,
                              Palmeira = 0,
                              Suculenta = 0,
                              `Liana_volúvel_trepadeira` = 0,
                              Desconhecida = 0,
                             `Dracenóide` = 0,
                              Bambu = 0,
                              Talosa = 0,
                              Saprobio = 0,
                              `Aquática_Plâncton` = 0,
                              `Aquática_Bentos` = 0,
                              Simbionte = 0,
                              Tapete = 0,
                              Folhosa = 0,
                              Tufo = 0,
                              `Aquática_Neuston` = 0,
                              Parasita = 0,
                              Coxim = 0,
                              Trama = 0,
                              Pendente = 0,
                              `Dendróide` = 0,
                              Flabelado = 0)
   
   # lifeForm <- gsub('Não endemica|Endemica|/', '', phytogeographicDomain)
   lifeForm = strsplit(lifeForm, '-')[[1]]
   lifeForm
   
   i=1
   for (i in 1:NROW(lifeForm))
   {
      d2 <-  sub('_',' ', colnames(lifeForm.d)) %in% lifeForm[i]
      lifeForm.d[1,d2] <- 1
   }
   lifeForm.d
   return(lifeForm.d)
}

# lifeForm <- lapply(FloraBrasil2020$lifeForm[1:5000], FB2020_get_lifeForm)
# lifeForm <- ldply(lifeForm, data.frame) 
# lifeForm
}

# habitat
{
FB2020_get_habitat <- function(habitat)
{
   # habitat <- FloraBrasil2020$habitat [963]  %>% as.character()
   habitat <- habitat  %>% as.character()
   
   # 
   habitat.d = data.frame(
      `Terrícola` = 0,
      `Rupícola` = 0,
      `Epífita` = 0,
      `Hemiepífita` = 0,
      `Aquática` = 0,
      Hemiparasita = 0,
      Parasita = 0,
      Desconhecido = 0,
      `Saprófita` = 0,
      `Corticícola` = 0,
      `Tronco_em_decomposição` = 0,
      Solo = 0,
      `Planta_viva_-_raiz` = 0,
      Epixila = 0,
      Rocha = 0,
      `Planta_viva_-_córtex_do_caule` = 0,
      Areia = 0,
      `Sub-aérea` = 0,
      Folhedo = 0,
      `Edáfica` = 0,
      `Planta_viva_-_fruto` = 0,
      `Planta_viva_-_inflorescência` = 0,
      `Planta_viva_-_folha` = 0,
      `Folhedo_aéreo` = 0,
      `Água` = 0,
      `Saxícola` = 0,
      `Epífila` = 0,
      `Simbionte_incluindo_fungos_liquenizados`=0)
   
   habitat.t = c(
      'Terrícola',
      'Rupícola',
      'Epífita',
      'Hemiepífita',
      'Aquática',
      'Hemiparasita',
      'Parasita',
      'Desconhecido',
      'Saprófita',
      'Corticícola',
      'Tronco em decomposição',
      'Solo',
      'Planta viva - raiz',
      'Epixila',
      'Rocha',
      'Planta viva - córtex do caule',
      'Areia',
      'Sub-aérea',
      'Folhedo',
      'Edáfica',
      'Planta viva - fruto',
      'Planta viva - inflorescência',
      'Planta viva - folha',
      'Folhedo aéreo',
      'Água',
      'Saxícola',
      'Epífila',
      'Simbionte (incluindo fungos liquenizados)') # Simbionte (incluindo fungos liquenizados)

   habitat = strsplit(habitat, '-')[[1]]
   habitat
   
   i=1
   for (i in 1:NROW(habitat))
   {
      d2 <-  habitat.t %in% habitat[i]
      habitat.d[1, d2] <- 1
   }
   habitat.d
   return(habitat.d)
   
}

# lifeForm <- lapply(FloraBrasil2020$lifeForm[1:5000], FB2020_get_lifeForm)
# lifeForm <- ldply(lifeForm, data.frame) 
# lifeForm
}

# vegetationType
{
   # vegetationType <-   FB2020_IPT$vegetationType
FB2020_get_vegetationType <- function(vegetationType)
{
   # vegetationType <- FloraBrasil2020$vegetationType [963]  %>% as.character()
   vegetationType <- vegetationType  %>% as.character()
   vegetationType = strsplit(vegetationType, '-')[[1]]
   vegetationType
   
   vegetationType.d <- data.frame( `Área Antrópica` = 0,
                                   `Caatinga (stricto sensu)` = 0,
                                   `Campinarana` = 0,
                                   `Campo de Altitude` = 0,
                                   `Campo de Várzea` = 0,
                                   `Campo Limpo` = 0,
                                   `Campo Rupestre` = 0,
                                   Carrasco = 0,
                                   `Cerrado (lato sensu)` = 0,
                                   `Floresta Ciliar ou Galeria` = 0,
                                   `Floresta de Igapó` = 0,
                                   `Floresta de Terra Firme` = 0,
                                   `Floresta de Várzea` = 0,
                                   `Floresta Estacional Decidual` = 0,
                                   `Floresta Estacional Perenifólia` = 0,
                                   `Floresta Estacional Semidecidual` = 0,
                                   `Floresta Ombrófila (= Floresta Pluvial)` = 0,
                                   `Floresta Ombrófila Mista` = 0,
                                   Manguezal = 0,
                                   Palmeiral = 0,
                                   Restinga = 0,
                                   `Savana Amazônica` = 0,
                                   `Vegetação Aquática` = 0,
                                   `Vegetação Sobre Afloramentos Rochosos` =0,
                                   stringsAsFactors = FALSE)
   colnames(vegetationType.d)
   
   
   vegetationType.t.i  = c( "Anthropic area",
                            "Caatinga (stricto sensu)",
                            "Amazonian Campinarana",
                            "High Altitude Grassland",
                            "Flooded Field (Várzea)",
                            "Grassland",
                            "Highland Rocky Field",
                            "Carrasco Vegetation",
                            "Cerrado (lato sensu)",
                            "Riverine Forest and/or Gallery Forest",
                            "Inundated Forest (Igapó)",
                            "Terra Firme Forest",
                            "Inundated Forest (Várzea)",
                            "Seasonally Deciduous Forest",
                            "Seasonal Evergreen Forest",
                            "Seasonally Semideciduous Forest",
                            "Ombrophyllous Forest (Tropical Rain Forest)",
                            "Mixed Ombrophyllous Forest",
                            "Mangrove",
                            "Palm Grove",
                            "Coastal Forest (Restinga)",
                            "Amazonian Savanna",
                            "Aquatic vegetation",
                            "Rock outcrop vegetation")
   
   vegetationType.t  = c( "Área Antrópica",
                          "Caatinga (stricto sensu)",
                          "Campinarana",
                          "Campo de Altitude",
                          "Campo de Várzea",
                          "Campo Limpo",
                          "Campo Rupestre",
                          "Carrasco",
                          "Cerrado (lato sensu)",
                          "Floresta Ciliar ou Galeria",
                          "Floresta de Igapó",
                          "Floresta de Terra Firme",
                          "Floresta de Várzea",
                          "Floresta Estacional Decidual",
                          "Floresta Estacional Perenifólia",
                          "Floresta Estacional Semidecidual",
                          "Floresta Ombrófila (= Floresta Pluvial)",
                          "Floresta Ombrófila Mista",
                          "Manguezal",
                          "Palmeiral",
                          "Restinga",
                          "Savana Amazônica",
                          "Vegetação Aquática",
                          "Vegetação Sobre Afloramentos Rochosos")

   i=1
   for (i in 1:NROW(vegetationType))
   {
      d2 <- vegetationType.t %in% vegetationType[i]
      vegetationType.d[1, d2] <- 1
   }
   
   vegetationType.d
   return(vegetationType.d)
   
}

# vegetationType <- lapply(FloraBrasil2020$vegetationType[1:1000], FB2020_get_vegetationType)
# vegetationType <- ldply(vegetationType, data.frame) 
# vegetationType
}

# endemism
{

   # fruit <- c("apple", "banana", "pear", "pinapple")
   # str_detect(fruit, "a")
   # str_detect(fruit, "^a")
   # str_detect(fruit, "a$")
   # str_detect(fruit, "b")
   # str_detect(fruit, "[aeiou]")
   
   FB2020_get_endemism <- function(endemism)
   {
      # endemism <- FloraBrasil2020$occurrenceRemarks[99]
      endemism <- FloraBrasil2020$occurrenceRemarks
      endemism.d <- data.frame( `Não endemica`=0, Endemica=0)      
      endemism.d$`Não.endemica` <- str_detect(endemism, 'Não endemica')
      endemism.d$Endemica <- str_detect(endemism, 'Endemica')
      endemism
      endemism.d
      return(endemism.d)
   }
   
   # endemism <- lapply(returnFB2020$distribuition[[1]]$occurrenceremarks$endemism, FB2020_get_IUCN_endemism)
   # endemism <- ldply(endemism, data.frame)
   # endemism
}

# establishmentmeans
{
   FB2020_get_establishmentMeans <- function(establishmentMeans)
   {
      return(establishmentMeans)
   }
}

# vernacular_name
{
   FB2020_get_vernacular_name <- function(vernacular_name)
   {
      # FloraBrasil2020$vernacular_names[996]
      return(vernacular_name)
   }
}

# print(nrow(FloraBrasil2020))
# FloraBrasil2020 <- FloraBrasil2020 %>% dplyr::distinct_all()
print(paste0(nrow(FloraBrasil2020), ' - nomes aceitos e sinônimos de espécies, subsp., var., form. de plantas vasculareas, briófiras e fungos conforme FB2020'))
print(ifelse(NROW(FloraBrasil2020) > 0, 'OK!', 'Falhou!'))

# binomialSearch <- 'Gardnerina angustata'
# binomialSearch <- 'Piqueria angustata'
# binomialSearch <- 'Lala lalala'
# binomialSearch <- 'Acacallis caerulea'
 
# binomialSearch <- 'Gomphrena gnaphaloides (Lf.) Vahl.'

# x <- FB2020_get_taxon_scientificname_from_IPT(binomialSearch)
# x$acceptedName$searchName
# x$acceptedName$searchNotes
# x$searchNotes

# library(sqldf)
# tbl <- sqldf::sqldf("SELECT scientificNamewithoutAuthorship_FB2020, Count(scientificNamewithoutAuthorship_FB2020) FROM FloraBrasil2020
#                     GROUP BY scientificNamewithoutAuthorship_FB2020
#                     HAVING Count(scientificNamewithoutAuthorship_FB2020) > 1")


# binomialSearch <- "Eugenia brasiliana"
# 
# binomialSearch <- 'Eugenia viridis'
# x <- FB2020_get_taxon_scientificname_from_IPT(binomialSearch)
# x$found
# 
# x$acceptedName$scientificName_FB2020




# Codigo para atualização de nomes científicos
# 
# ####
# file.lista <- 'C:\\Dados\\CNCFlora\\shiny\\cncflora\\scriptsAdd\\AvaliacaoFloraPara\\Anexo1-AvaliacaoFloraPara_v1.1_graficos.xlsx'
# file.lista.fb2020 <- 'C:\\Dados\\CNCFlora\\shiny\\cncflora\\scriptsAdd\\AvaliacaoFloraPara\\EdaphicEndemismAmazon.csv'
# # 
# # 
# # file.lista <- 'C:/Dados/CNCFlora/shiny/cncflora/scriptsAdd/2022/Brazil Species List Check 101221.xlsx'
# # file.lista.fb2020 <- 'C:/Dados/CNCFlora/shiny/cncflora/scriptsAdd/2022/Brazil Species List Check 101221_FB2020.csv'
# # 
# lista <- readxl::read_excel(file.lista,
#                             sheet = 'ListaAvaliacaoRicoPara') %>%
#    # dplyr::mutate(spp = scientificNameSearch) %>%
#    dplyr::filter(listagemOrigem=='Edaphic Endemism in the Amazon') %>%
#    dplyr::select(`nomeCientificoParaAvaliacaoPara`) %>%
#    data.frame(stringsAsFactors = TRUE)
# # # 
# x <- FB2020_IPT(lista)
# x$x %>% View()
# 
# x$x %>% colnames()
# x$FB2020 %>% colnames()
# 
# write.csv(x$x, file.lista.fb2020, na = "", fileEncoding = "UTF-8",
#           row.names = FALSE)
####

FB2020_IPT <- function(lista)
{
   
   lista <- lista %>%
      dplyr::mutate(Status='',
                    Notes='',
                    selecaoCheck = TRUE,
                    check=0)
   
   FB2020 <- acceptedName <- synonyms <- infrataxa <- {}
   restart <- FALSE
   i <- 1
   tot <- NROW(lista)
   
   while(restart==FALSE)
   {
      restart <- FALSE
      
      # if (lista$selecaoCheck[i]==FALSE) {next}
      
      
      for (i in 1:tot)
      {
         if (lista$selecaoCheck[i]==FALSE) {next}

         spp <- lista[i,1]
         
         if (lista$check[i]==0)
         {
            # SearchFB2020 <- FB2020_get_taxon_scientificname_from_IPT(spp)
            
            SearchFB2020 <- FB2020_get_taxon_scientificname_from_IPT_v2(spp)
            
            if (SearchFB2020[[1]]==FALSE)
            {
               FB2020 <- rbind(FB2020, SearchFB2020$acceptedName)
               next
            }
            
            acceptedName <- SearchFB2020$acceptedName %>% as.data.frame()
            synonyms <- SearchFB2020$synonyms
            infrataxa <- SearchFB2020$infrataxa
            
            FB2020 <- rbind(FB2020, acceptedName)
            print(spp)
            
         }   
         
         print(paste0(i, ' com ', NROW(FB2020)))
         
      }
      restart <- TRUE
      print('acabou!')
   }
   
   # View(FB2020)
   
   # View(lista)
   # View(FB2020)
   #
   # lista <- cbind(lista,
   #                FB2020)
   
   x <- FB2020 %>%
      dplyr::select(group_FB2020,
                    taxonID_FB2020,
                    scientificName_FB2020,
                    taxonRank_FB2020,	
                    nomenclaturalStatus_FB2020,
                    taxonomicStatus_FB2020,
                    kingdom_FB2020,
                    phylum_FB2020,
                    class_FB2020,
                    order_FB2020,
                    family_FB2020,	
                    genus_FB2020,
                    specificEpithet_FB2020,
                    infraspecificEpithet_FB2020,
                    scientificNameAuthorship_FB2020,
                    acceptedNameUsage_FB2020,
                    higherClassification_FB2020,
                     # source_FB2020,
                    parentNameUsage_FB2020,
                    parentNameUsageID_FB2020,
                    bibliographicCitation_FB2020,
                    namePublishedIn_FB2020,
                    namePublishedInYear_FB2020,
                    references_FB2020,
                    acceptedNameUsageID_FB2020,
                    bibliographicCitation_FB2020,  #bibliographiccitation_how_to_cite_FB2020,
                    modified_FB2020,
                    vernacular_FB2020,
                    establishmentMeans_FB2020,
                    endemism_FB2020,
                    Amazônia_FB2020,
                    Caatinga_FB2020,
                    Cerrado_FB2020,
                    Mata.Atlântica_FB2020,
                    Pampa_FB2020,
                    Pantanal_FB2020,	
                    AC_FB2020,
                    AL_FB2020,	
                    AM_FB2020,
                    AP_FB2020,
                    BA_FB2020,
                    CE_FB2020,
                    DF_FB2020,
                    ES_FB2020,
                    GO_FB2020,
                    MA_FB2020,
                    MG_FB2020,
                    MS_FB2020,
                    MT_FB2020,
                    PA_FB2020,
                    PB_FB2020,	
                    PE_FB2020,	
                    PI_FB2020,
                    PR_FB2020,	
                    RJ_FB2020,
                    RN_FB2020,
                    RO_FB2020,
                    RR_FB2020,
                    RS_FB2020,
                    SC_FB2020,
                    SE_FB2020,
                    SP_FB2020,
                    TO_FB2020,
                    searchNotes,
                    searchName,
                    occurrenceRemarks_FB2020,
                    location_FB2020,
                    scientificNamewithoutAuthorship_FB2020, #  scientificNameWithoutAuthor_FB2020,
                    vegetationType_FB2020,
                    Árvore_FB2020,
                    Subarbusto_FB2020,	
                    Arbusto_FB2020,	
                    Erva_FB2020,
                    Palmeira_FB2020,
                    Suculenta_FB2020,
                    Liana.volúvel.trepadeira_FB2020,
                    Desconhecida_FB2020,
                    Dracenóide_FB2020,
                    Bambu_FB2020,
                    Talosa_FB2020,
                    Tapete_FB2020,
                    Folhosa_FB2020,
                    Tufo_FB2020,
                    Coxim_FB2020,
                    Trama_FB2020,
                    Pendente_FB2020,
                    Dendróide_FB2020,
                    Flabelado_FB2020,
                    Terrícola_FB2020,
                    Rupícola_FB2020,
                    Epífita_FB2020,
                    Hemiepífita_FB2020,
                    Aquática_FB2020,
                    Hemiparasita_FB2020,
                    Saprófita_FB2020,
                    Corticícola_FB2020,
                    Epixila_FB2020,
                    Saxícola_FB2020,
                    Epífila_FB2020)
   
   
   return(list(FB2020=FB2020,
               x=x))
}



