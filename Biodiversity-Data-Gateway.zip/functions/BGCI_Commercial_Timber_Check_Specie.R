###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 07/06/2022, Pablo H.
################################################################################################################################

#' @section Buscar pos usos madeireiros 

BGCI_Commercial_Timber_Check_Specie <- function(acceptedNameSearch='Araucaria angustifolia (Bertol.) Kuntze',
                                                path_bgci='C:\\PlantRecordsChecker\\data\\BGCI-Commercial-Timber-List-2014',
                                                list_BGCI_Commercial_Timber = NULL,
                                                source_BGCI_Commercial_Timber = NULL)
{  
   
   if (is.null(list_BGCI_Commercial_Timber)){
      list_BGCI_Commercial_Timber <- readr::read_csv(paste0(path_bgci,'\\WorkingList-Appendix2.csv'),
                                                     locale = locale(encoding = "UTF-8"),
                                                     show_col_types = FALSE)
   }
   
   if (is.null(source_BGCI_Commercial_Timber)){
      source_BGCI_Commercial_Timber <- readr::read_csv(paste0(path_bgci,'\\KeyToSource_WorkingList-Appendix2.csv'),
                                                       locale = locale(encoding = "UTF-8"),
                                                       show_col_types = FALSE)
   }
   
   index <- list_BGCI_Commercial_Timber$`Scientific name` == 'Morus alba'
   resultNA <- list_BGCI_Commercial_Timber[index==TRUE,]
   resultNA[1,1:20] <- NA
   resultNA$spSearch <- NA
   resultNA$sourceResult <- NA
   
   rawResult <-resultNA[-1,]
   
   
   i<-1
   for (i in 1:NROW(acceptedNameSearch))
   {   
      
      if( length(str_locate_all(acceptedNameSearch[i], 'var.')[[1]][,] )>0 |
          length(str_locate_all(acceptedNameSearch[i], 'supsp.')[[1]][,] )>0 |
          length(str_locate_all(acceptedNameSearch[i], 'form.')[[1]][,] )>0)
      {
         binomialSearch <- paste0(word(acceptedNameSearch[i],1), ' ',
                                  word(acceptedNameSearch[i],2), ' ',
                                  word(acceptedNameSearch[i],3), ' ',
                                  word(acceptedNameSearch[i],4))
         
      } else {
         binomialSearch <- paste0(word(acceptedNameSearch[i],1), ' ',
                                  word(acceptedNameSearch[i],2))
      }
      
      print(binomialSearch)
      
      index <- list_BGCI_Commercial_Timber$`Scientific name` == binomialSearch
      # index <- list_BGCI_Commercial_Timber$`Scientific name` == 'Morus alba'

      if(any(index==TRUE))
      {
         rawResult[i,1:20] <- list_BGCI_Commercial_Timber[index==TRUE,]
         # rawResult[i,21] <- acceptedNameSearch[i]
      }else{
         rawResult[i,] <- resultNA
         # rawResult[i,21] <- acceptedNameSearch[i]
      }
      
      source <- source_BGCI_Commercial_Timber$Source[(source_BGCI_Commercial_Timber$key %in% na.omit(colnames(rawResult)[(rawResult[i,1:20]=='y')==TRUE]))==TRUE]
      
      if(NROW(source)>=1)
      {   
         rawResult$sourceResult[i] <- source[1]
         
         if(NROW(source)>=2)
         {   
            for (i2 in 2:NROW(source))
            {rawResult$sourceResult[i] <- paste0(rawResult$sourceResult[i], ' - ',source[i2])}   
            
         }   
      }
   }
   rawResult$acceptedNameSearch <- acceptedNameSearch
   
   colnames(list_BGCI_Commercial_Timber)[4:20] <- source_BGCI_Commercial_Timber$Source
   
   return(list(rawResult = rawResult,
               sourceResult = data.frame( acceptedNameSearch = rawResult$acceptedNameSearch,
                                          commercialTimberSource=rawResult$sourceResult,
                                          stringsAsFactors = FALSE)))
   
}

