###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 07/06/2022, Pablo H.
################################################################################################################################

#' @section Ajusta grafia UFs Brasil



grafia_UF <- function(path_estadosESTADOS="C:\\BiodiversityDataGateway\\data\\estadosESTADOS.csv", 
                      stateProvince_standardized)
{
   estadosESTADOS <- readr::read_csv2(path_estadosESTADOS) 
   
   # stateProvince_standardized <- occ_sel$Ctrl_stateProvince_standardized
   stateProvince_standardized_r <- stateProvinceSigla_r <- rep('', length(stateProvince_standardized))
   
   i=1
   for (i in 1: nrow(estadosESTADOS) )
   {
      index <- stateProvince_standardized == estadosESTADOS$ESTADO[i] 
      # %>% ifelse(is.na(.), FALSE,.)
      index <- ifelse(is.na(index), FALSE,index)
      any(is.na(index))
      stateProvince_standardized_r[index==TRUE] <- estadosESTADOS$Estado[i] 
      stateProvinceSigla_r[index==TRUE] <- estadosESTADOS$Sigla[i] 
   } 
   return(data.frame(stateProvince=stateProvince_standardized_r,
                     stateProvinceSigla=stateProvinceSigla_r))
}  


grafia_UF_v2 <- function(stateProvinceName=NULL,
                         # stateProvinceCode=NULL,
                         path_estadosESTADOS="C:\\BiodiversityDataGateway\\data\\estadosESTADOS.csv")
{
   
   # if (is.null(stateProvinceName)==TRUE)
   # {
   #    stateProvinceName <- rep(NA, length(stateProvinceCode))
   # }  
   # 
   # if (is.null(stateProvinceCode)==TRUE)
   # {
   #    stateProvinceCode <- rep(NA, length(stateProvinceName))
   # }  
   
   estadosESTADOS <- readr::read_csv2(path_estadosESTADOS) 
   
   stateProvince_standardized_R <- stateProvince_standardized_r <- stateProvinceCode_r <- rep('', length(stateProvinceName))
   
   i=1
   for (i in 1: nrow(estadosESTADOS) )
   {
      index <- toupper(stateProvinceName) == estadosESTADOS$ESTADO[i] 
      index <- ifelse(is.na(index), FALSE,index)
      
      # if (index==FALSE)
      # {
      #    index <- toupper(stateProvinceCode) == estadosESTADOS$Sigla[i] 
      #    index <- ifelse(is.na(index), FALSE,index)
      # }

      stateProvince_standardized_r[index==TRUE] <- estadosESTADOS$Estado[i] 
      stateProvinceCode_r[index==TRUE] <- estadosESTADOS$Sigla[i]
      stateProvince_standardized_R[index==TRUE] <- estadosESTADOS$ESTADO[i] 
   } 
   return(data.frame(stateProvince=stateProvince_standardized_r,
                     stateProvinceCode=stateProvinceCode_r))
}  
