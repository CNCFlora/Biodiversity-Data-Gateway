###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 07/06/2022, Pablo H.
################################################################################################################################

#' @section Exportar CSVs CNCFlora 


# occ_tmp <- occ_sel

in_out_cncflora <- function(occ_tmp)
{
  occ_in <- occ_out <- occ_global <- {}
  
  occ_tmp <- occ_tmp %>% 
    dplyr::mutate(ID = 1:nrow(occ_tmp),
                  in_out_status = FALSE)
  
  
  occ_in = occ_tmp %>% dplyr::filter(
    ( (Ctrl_selectedMoreInformativeRecord == TRUE) &
      (autoGeoStatus == TRUE)))  %>% 
    dplyr::mutate(in_out_status = TRUE)

  # 26-10-2021 - registros unicios para recuperação
  occ_out_to_recover <- anti_join(occ_tmp %>% 
                                    dplyr::filter(Ctrl_selectedMoreInformativeRecord == TRUE), occ_in, "ID")
  
  # 26-10-2012 deixar no out somente as duplicatas?
  # occ_out <- anti_join(occ_tmp, occ_in, "ID")

  occ_out <- anti_join(occ_tmp %>% 
                         dplyr::filter(Ctrl_selectedMoreInformativeRecord == FALSE), occ_in, "ID")
  
  # occ_out$temCoordenadas
  # occ_out %>%
  #   dplyr::select(Ctrl_decimalLatitude,
  #                 Ctrl_decimalLongitude,
  #                 temCoordenadas,
  #                 Ctrl_selectedMoreInformativeRecord,
  #                 autoGeoStatus,
  #                 in_out_status,
  #                 codigofraseSaida
  #                 ) %>% 
  #   dplyr::filter((codigofraseSaida == '6')) %>%
  #   View()
  
  # occ_global <- rbind(occ_in,
  #                  occ_out) %>% 
  #   dplyr::filter((Ctrl_selectedMoreInformativeRecord == TRUE) &
  #                   (temCoordenadas == TRUE))
  
  # occ_global <- rbind(occ_in,
  #                     occ_out) %>% 
  #   dplyr::filter((in_out_status == TRUE) | (codigofraseSaida == '6' & temCoordenadas == TRUE))
  
  occ_global <- rbind(occ_in,
                      occ_out) %>% 
    dplyr::filter((in_out_status == TRUE) |
                    (codigofraseSaida == '6' & temCoordenadas == TRUE))
  
  return(list(occ_all = rbind(occ_in,
                              occ_out), 
              occ_in = occ_in, 
              occ_out = occ_out,
              occ_global = occ_global,
              occ_out_to_recover= occ_out_to_recover))
}

# x <- grafia_UF(stateProvince_standardized = occ_sel$Ctrl_stateProvince_standardized)

# occ_tmp <- occ_sel

# occ_tmp <- occ_sel
# familias <- familias
# especies <- especies
# FB2020_acceptedNameUsage <- acceptedName

export_CSV_v3 <- function(occ_tmp, 
                       familias,
                       especies,
                       FB2020_acceptedNameUsage,
                       dir_output='', 
                       estadosESTADOS=estadosESTADOS,
                       tipoAcessoFB2020='API')
{
  
  if (!dir.exists(paste0("./",dir_output))) {dir.create(paste0("./",dir_output))}
  
  if (!dir.exists(paste0("./",dir_output,"/occurrence"))){dir.create(paste0("./",dir_output,"/occurrence"))}
  
  if (!dir.exists(paste0("./",dir_output,"/occurrence/in"))){dir.create(paste0("./",dir_output,"/occurrence/in"))}
  
  if (!dir.exists(paste0("./",dir_output,"/occurrence/out"))){dir.create(paste0("./",dir_output,"/occurrence/out"))}
  
  if (!dir.exists(paste0("./",dir_output,"/occurrence/all"))){dir.create(paste0("./",dir_output,"/occurrence/all"))}

  # 26-10-2021 - registros unicios para recuperação occ_out_to_recover
  if (!dir.exists(paste0("./",dir_output,"/occurrence/out_to_recover"))){dir.create(paste0("./",dir_output,"/occurrence/out_to_recover"))}
  

  x <- in_out_cncflora(occ_tmp)
  
  # x[[r]]$comments
  # x[[r]]$autoGeoNotes

  r=names(x)[3]
  for (r in names(x))
  {
    stateProvince_tmp <- grafia_UF(stateProvince_standardized = x[[r]]$Ctrl_stateProvince_standardized)$stateProvince

    x[[r]] <- x[[r]] %>%
      dplyr::mutate(modified='') %>%
      dplyr::select(modified,
                    Ctrl_institutionCode,
                    Ctrl_collectionCode,
                    Ctrl_catalogNumber,
                    # Ctrl_scientificName,
                    Ctrl_scientificNameSearched, # Aqui SUBSPP no sistema
                    Ctrl_scientificNameReference,
                    Ctrl_identificationQualifier,
                    Ctrl_family,
                    Ctrl_genus,
                    Ctrl_specificEpithet,
                    Ctrl_infraspecificEpithet,
                    Ctrl_scientificNameAuthorship,
                    Ctrl_identifiedBy,
                    Ctrl_dateIdentified,
                    Ctrl_typeStatus,
                    Ctrl_recordNumber,
                    Ctrl_fieldNumber,
                    Ctrl_recordedBy,
                    Ctrl_year,
                    Ctrl_month,
                    Ctrl_day,
                    Ctrl_country,
                    # Ctrl_country_standardized,
                    
                    Ctrl_stateProvince_standardized,
                    
                    # 17-09-2021
                    Ctrl_municipality_standardized,
                    # Ctrl_municipality,
                    Ctrl_locality,
                    Ctrl_decimalLongitude,
                    Ctrl_decimalLatitude,
                    Ctrl_occurrenceRemarks,
                    Ctrl_acceptedNameUsage,
                    Ctrl_occurrenceID,
                    Ctrl_comments,
                    Ctrl_bibliographicCitation,
                    
                    codigofraseSaida,

                    verbatimNotes,
                    autoGeoNotes,
                    autoGeoStatus,
                    in_out_status,

                    Ctrl_autoGeoLongitude,
                    Ctrl_autoGeoLatitude,

                    Ctrl_key_family_recordedBy_recordNumber,
                    Ctrl_moreInformativeRecord,
                    Ctrl_selectedMoreInformativeRecord,
                    Ctrl_thereAreDuplicates
                    ) %>%
      # 15-04-2020
      dplyr::mutate(Ctrl_occurrenceRemarks = ifelse(is.na(Ctrl_comments), Ctrl_occurrenceRemarks, paste0(Ctrl_comments, Ctrl_occurrenceRemarks))) %>%
      # 
      dplyr::rename(institutionCode	 = Ctrl_institutionCode,
                    collectionCode = Ctrl_collectionCode,
                    catalogNumber = Ctrl_catalogNumber,	
                    
                    scientificName = Ctrl_scientificNameSearched,
                    # scientificName = Ctrl_scientificNameReference,	
                    
                    identificationQualifier = Ctrl_identificationQualifier,	
                    family = Ctrl_family,	
                    genus = Ctrl_genus,
                    specificEpithet = Ctrl_specificEpithet,	
                    infraspecificEpithet = Ctrl_infraspecificEpithet,	
                    scientificNameAuthorship = Ctrl_scientificNameAuthorship,	
                    identifiedBy = Ctrl_identifiedBy,	
                    dateIdentified = Ctrl_dateIdentified,	
                    typeStatus = Ctrl_typeStatus,	
                    recordNumber = Ctrl_recordNumber,	
                    fieldNumber = Ctrl_fieldNumber,	
                    recordedBy = Ctrl_recordedBy,	
                    year = Ctrl_year,	
                    month = Ctrl_month,	
                    day = Ctrl_day,
                    country = Ctrl_country,	
                    
                    stateProvince = Ctrl_stateProvince_standardized,
                    
                    # # 04-06-2020 grafia original do nome do municipio
                    # # municipality = Ctrl_municipality_standardized,	
                    # municipality = Ctrl_municipality,	

                    # 17-09-2021 exportar corrigida do nome do municipio
                    # Acordado com Glaucia, Lucas Jordão e Duda
                    
                    municipality = Ctrl_municipality_standardized,	
                    # municipality = Ctrl_municipality,	
                    
                    locality = Ctrl_locality,	
                    
                    decimalLatitude = Ctrl_decimalLatitude,	
                    decimalLongitude = Ctrl_decimalLongitude,	
                    
                    occurrenceRemarks = Ctrl_occurrenceRemarks,
                    
                    acceptedNameUsage = Ctrl_acceptedNameUsage,	
                    occurrenceID = Ctrl_occurrenceID,	
                    comments = Ctrl_comments,	
                    bibliographicCitation  = Ctrl_bibliographicCitation
                    
                    # resumo dos estados da planilha in stateProvinceConfirmedOccurrence = 
                    
                    ) %>%
      dplyr::mutate(modified	= '',
                    institutionCode = '',
                    fieldNumber = '',
                    
                    # 18-10-2021
                    # occurrenceID = '',
                    
                    # 04-06-2020 ajustar grafia de UF
                    stateProvince = stateProvince_tmp, 

                    # ajustes finos 03-06-2020 - informação de typo nos comentários
                    comments = toupper(typeStatus),
                    comments = ifelse(is.na(comments)==TRUE, autoGeoNotes, paste0(comments,'; ',autoGeoNotes)),
                                      
                    identificationQualifier  = '') %>%
      
      # dplyr::mutate(comments = dplyr::if_else( (Ctrl_thereAreDuplicates == TRUE & in_out_status == FALSE ),
      dplyr::mutate(comments = dplyr::if_else( (Ctrl_thereAreDuplicates == TRUE & Ctrl_selectedMoreInformativeRecord == FALSE),
                                               paste0('Duplicata; ',comments),comments)) %>%
      dplyr::mutate(decimalLatitude = ifelse(is.na(Ctrl_autoGeoLatitude)==TRUE, decimalLatitude, Ctrl_autoGeoLatitude),	
                    decimalLongitude = ifelse(is.na(Ctrl_autoGeoLongitude)==TRUE, decimalLongitude, Ctrl_autoGeoLongitude)) %>%
      # dplyr::mutate(comments = ifelse(verbatimNotes=='',comments , 
      #                                 paste0(comments, '; Sem informações de (',verbatimNotes,')') )) 
      dplyr::mutate(comments = ifelse(is.na(verbatimNotes),comments , 
                                      paste0(comments, '; Sem informações de (',verbatimNotes,')') )) %>%
      
      # 18-10-20
      # memória de registro
      # comments = Ctrl_comments,
      dplyr::mutate(comments = paste0(comments, ' [occurrenceID : ',occurrenceID,']')) %>%
      dplyr::mutate(occurrenceID = '')
      
    
    # %>%
    #   dplyr::select(-codigofraseSaida,
    #                 -verbatimNotes,
    #                 -autoGeoNotes,
    #                 -autoGeoStatus,
    #                 -in_out_status,
    #                 
    #                 -Ctrl_autoGeoLongitude,
    #                 -Ctrl_autoGeoLatitude,
    #                 
    #                 -Ctrl_key_family_recordedBy_recordNumber,
    #                 -Ctrl_moreInformativeRecord,
    #                 -Ctrl_selectedMoreInformativeRecord,
    #                 -Ctrl_thereAreDuplicates)
    
    # 04-06-2020 ordernar com coletor + número 
    x[[r]] <- x[[r]] %>%
      dplyr::arrange(Ctrl_scientificNameReference, Ctrl_key_family_recordedBy_recordNumber)
    
  }
  
  # Exportar planilhas com as ocorrências
  i=1
  for (i in 1:length(especies))
  {
    
    ###
    dir.create(paste0("./",dir_output,"/occurrence/in/",familias[i]), showWarnings = F)
    nome_arquivo <- paste0("./",dir_output,"/occurrence/in/", familias[i],"/",familias[i],"_", especies[i],"_", "in.csv")
    print(paste("Processando", especies[i], i, "de", length(especies), sep = " "))
    
    if (tipoAcessoFB2020=='API')
    {  
      especies_tmp <- FB2020_get_taxon_scientificname_from_API(FB2020_acceptedNameUsage[i])
    } else {
      especies_tmp <- FB2020_get_taxon_scientificname_from_IPT_v2(binomialSearch= FB2020_acceptedNameUsage[i],
                                                                  FloraBrasil2020_tmp=FloraBrasil2020,
                                                                  somente_especie = FALSE)$acceptedName
    }
      
    
    # 16-08-2021
    # if (especies_tmp$found == FALSE)
    # {
    #   next
    # }  
    
    if (!file.exists(nome_arquivo)){
      occs_sp <- list()
      occs_sp[[i]] <- x[['occ_in']] %>% 
        # dplyr::filter(Ctrl_scientificNameReference==especies_tmp$acceptedName$scientificname) %>%
        dplyr::filter(Ctrl_scientificNameReference==FB2020_acceptedNameUsage[i]) %>%
        # 04-06-2020 ordernar com coletor + número 
        dplyr::arrange(Ctrl_key_family_recordedBy_recordNumber)   %>%
        dplyr::select(-codigofraseSaida,
                      -verbatimNotes,
                      -autoGeoNotes,
                      -autoGeoStatus,
                      -in_out_status,
                      
                      -Ctrl_autoGeoLongitude,
                      -Ctrl_autoGeoLatitude,
                      
                      -Ctrl_key_family_recordedBy_recordNumber,
                      -Ctrl_moreInformativeRecord,
                      -Ctrl_selectedMoreInformativeRecord,
                      -Ctrl_thereAreDuplicates,
                      -Ctrl_scientificNameReference)
      
      # print(lapply(occs_sp,dim))
      if (NROW(occs_sp[[i]])>0) {
        dim.null <- lapply(occs_sp, function(x) {!is.null(dim(x))})
        occs.f <- subset(occs_sp, dim.null == T)
        occs.f <- dplyr::bind_rows(occs.f)
        print(nome_arquivo)
        write.csv(occs.f, nome_arquivo, na = "", fileEncoding = "UTF-8",
                  row.names = FALSE)
      }
    } else {
      warning(paste("No data", especies[i], "\n"))
    }
    
    # 26-10-2021
    # occ_out_to_recover
    # out_to_recover
    dir.create(paste0("./",dir_output,"/occurrence/out_to_recover/",familias[i]), showWarnings = F)
    nome_arquivo_e <- paste0("./",dir_output,"/occurrence/out_to_recover/", familias[i],"/",familias[i],"_", especies[i],"_", "out_to_recover.csv")
    print(paste("Processando", especies[i], i, "de", length(especies), sep = " "))
    
    if (!file.exists(nome_arquivo_e)){
      occs_sp <- list()
      occs_sp[[i]] <- x[['occ_out_to_recover']] %>% 
        # dplyr::filter(Ctrl_scientificNameReference==especies_tmp$acceptedName$scientificname) %>%
        dplyr::filter(Ctrl_scientificNameReference==FB2020_acceptedNameUsage[i]) %>%
        # 04-06-2020 ordernar com coletor + número 
        dplyr::arrange(Ctrl_key_family_recordedBy_recordNumber)   %>%
        dplyr::select(-codigofraseSaida,
                      -verbatimNotes,
                      -autoGeoNotes,
                      -autoGeoStatus,
                      -in_out_status,
                      
                      -Ctrl_autoGeoLongitude,
                      -Ctrl_autoGeoLatitude,
                      
                      -Ctrl_key_family_recordedBy_recordNumber,
                      -Ctrl_moreInformativeRecord,
                      -Ctrl_selectedMoreInformativeRecord,
                      -Ctrl_thereAreDuplicates,
                      -Ctrl_scientificNameReference)
      
      
      # print(lapply(occs_sp,dim))
      if (NROW(occs_sp[[i]])>0) {
        dim.null <- lapply(occs_sp, function(x) {!is.null(dim(x))})
        occs.f <- subset(occs_sp, dim.null == T)
        occs.f <- dplyr::bind_rows(occs.f)
        print(nome_arquivo)
        write.csv(occs.f, 
                  nome_arquivo_e, 
                  na = "", 
                  fileEncoding = "UTF-8",
                  row.names = FALSE)
      }
    } else {
      warning(paste("No data ex", especies[i], "\n"))
      
    }
    
    
    # out
    dir.create(paste0("./",dir_output,"/occurrence/out/",familias[i]), showWarnings = F)
    nome_arquivo_e <- paste0("./",dir_output,"/occurrence/out/", familias[i],"/",familias[i],"_", especies[i],"_", "out.csv")
    print(paste("Processando", especies[i], i, "de", length(especies), sep = " "))
    
    if (!file.exists(nome_arquivo_e)){
      occs_sp <- list()
      occs_sp[[i]] <- x[['occ_out']] %>% 
        # dplyr::filter(Ctrl_scientificNameReference==especies_tmp$acceptedName$scientificname) %>%
        dplyr::filter(Ctrl_scientificNameReference==FB2020_acceptedNameUsage[i]) %>%
        # 04-06-2020 ordernar com coletor + número 
        dplyr::arrange(Ctrl_key_family_recordedBy_recordNumber)   %>%
        dplyr::select(-codigofraseSaida,
                      -verbatimNotes,
                      -autoGeoNotes,
                      -autoGeoStatus,
                      -in_out_status,
                      
                      -Ctrl_autoGeoLongitude,
                      -Ctrl_autoGeoLatitude,
                      
                      -Ctrl_key_family_recordedBy_recordNumber,
                      -Ctrl_moreInformativeRecord,
                      -Ctrl_selectedMoreInformativeRecord,
                      -Ctrl_thereAreDuplicates,
                      -Ctrl_scientificNameReference)
      
      
      # print(lapply(occs_sp,dim))
      if (NROW(occs_sp[[i]])>0) {
        dim.null <- lapply(occs_sp, function(x) {!is.null(dim(x))})
        occs.f <- subset(occs_sp, dim.null == T)
        occs.f <- dplyr::bind_rows(occs.f)
        print(nome_arquivo)
        write.csv(occs.f, 
                  nome_arquivo_e, 
                  na = "", 
                  fileEncoding = "UTF-8",
                  row.names = FALSE)
      }
    } else {
      warning(paste("No data ex", especies[i], "\n"))
      
    }
    
    dir.create(paste0("./",dir_output,"/occurrence/all/",familias[i]), showWarnings = F)
    nome_arquivo <- paste0("./",dir_output,"/occurrence/all/", familias[i],"/",familias[i],"_", especies[i],"_", "all.csv")
    
    if (!file.exists(nome_arquivo)){
      occs_sp <- list()
      occs_sp[[i]] <- x[['occ_all']] %>% 
        # dplyr::filter(Ctrl_scientificNameReference==especies_tmp$acceptedName$scientificname) %>%
        dplyr::filter(Ctrl_scientificNameReference==FB2020_acceptedNameUsage[i]) %>%
        # 04-06-2020 ordernar com coletor + número 
        dplyr::arrange(Ctrl_key_family_recordedBy_recordNumber)   %>%
        dplyr::select(-codigofraseSaida,
                      -verbatimNotes,
                      -autoGeoNotes,
                      -autoGeoStatus,
                      -in_out_status,
                      
                      -Ctrl_autoGeoLongitude,
                      -Ctrl_autoGeoLatitude,
                      
                      -Ctrl_key_family_recordedBy_recordNumber,
                      -Ctrl_moreInformativeRecord,
                      -Ctrl_selectedMoreInformativeRecord,
                      -Ctrl_thereAreDuplicates,
                      -Ctrl_scientificNameReference)
      
      
      # print(lapply(occs_sp,dim))
      if (NROW(occs_sp[[i]])>0) {
        dim.null <- lapply(occs_sp, function(x) {!is.null(dim(x))})
        occs.f <- subset(occs_sp, dim.null == T)
        occs.f <- dplyr::bind_rows(occs.f)
        print(nome_arquivo)
        write.csv(occs.f, nome_arquivo, na = "", fileEncoding = "UTF-8",
                  row.names = FALSE)
      }
    } else {
      warning(paste("No data", especies[i], "\n"))
      
    }
    
    
  }   
  
  for (r in names(x))
  {
    # # # 04-06-2020 ordernar com coletor + número 
    # x[[r]] <- x[[r]] %>%
    #   dplyr::arrange(Ctrl_scientificNameReference, Ctrl_key_family_recordedBy_recordNumber)
    
    
    name_output <- paste0("./",dir_output,"/occurrence/occ_join_",r,".csv")
    write.csv(x[[r]], 
              file = name_output,
              na = "", 
              fileEncoding = "UTF-8", 
              row.names = FALSE)
    print(name_output)
  }
  
  
}  


