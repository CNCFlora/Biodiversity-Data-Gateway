###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 07/06/2022, Pablo H.
################################################################################################################################

#' @section Pegar, via API categorias IUCN


IUCNRedList_Check_Specie <- function(acceptedNameUsage='Araucaria angustifolia (Bertol.) Kuntze',
                                     token="b90e34ffb514ff9649441a4a522b639f1ef34ba5a4820db54fd0139e36e97f5f",
                                     show=FALSE)
{  
   if( length(str_locate_all(acceptedNameUsage, 'var.')[[1]][,] )>0 |
       length(str_locate_all(acceptedNameUsage, 'supsp.')[[1]][,] )>0 |
       length(str_locate_all(acceptedNameUsage, 'form.|\\sf.')[[1]][,] )>0)
   {
      binomialSearch <- paste0(word(acceptedNameUsage,1), ' ',
                               word(acceptedNameUsage,2), ' ',
                               word(acceptedNameUsage,3), ' ',
                               word(acceptedNameUsage,4))
      
   } else {
      binomialSearch <- paste0(word(acceptedNameUsage,1), ' ',
                               word(acceptedNameUsage,2))
   }
   
   if (show==TRUE) {print(binomialSearch)}
      
   options(stringsAsFactors = FALSE)
   IUCNURL <- sprintf("http://apiv3.iucnredlist.org/api/v3/species/%s?token=%s",  list(page = binomialSearch), token)
   returnIUCN <- jsonlite::read_json(IUCNURL, simplifyVector=TRUE)
   IUCN <- list(found=FALSE,
                IUCNData=data.frame(taxonid=NA,
                                    scientific_name=NA,
                                    kingdom=NA,
                                    phylum=NA,
                                    class=NA,
                                    order=NA,
                                    family=NA,
                                    genus=NA,
                                    main_common_name=NA,
                                    authority=NA,
                                    published_year=NA,
                                    assessment_date=NA,
                                    category=NA,
                                    criteria=NA,
                                    population_trend=NA,
                                    marine_system=NA,
                                    freshwater_system=NA,
                                    terrestrial_system=NA,
                                    assessor=NA,
                                    reviewer=NA,
                                    aoo_km2=NA,
                                    eoo_km2=NA,
                                    elevation_upper=NA,
                                    elevation_lower=NA,
                                    depth_upper=NA,
                                    depth_lower=NA,
                                    errata_flag=NA,
                                    errata_reason=NA,
                                    amended_flag=NA,
                                    amended_reason=NA))
   
   if (length(returnIUCN$result)>0 ) # se a lista não estiver vazia
   {  
      IUCNData <- returnIUCN$result
      IUCN <- list(found=TRUE,
                   IUCNData=data.frame(IUCNData))
   }
   return(IUCN)
   
}  


# x <- IUCNRedList_Check_Specie('Mollinedia heteranthera')
# 
# x <- IUCNRedList_Check_Specie('Lindackeria paraensis')


# colnames(x$IUCNData)

IUCNRedList_Check_Specie_ALL <- function(acceptedNameUsage='Araucaria angustifolia (Bertol.) Kuntze',
                                         includeSynonym=TRUE,
                                         token="b90e34ffb514ff9649441a4a522b639f1ef34ba5a4820db54fd0139e36e97f5f")
{
   SearchFB2020 <- FB2020_get_taxon_scientificname_from_API(acceptedNameUsage)
   
   if (SearchFB2020[[1]]==FALSE)
   {
      IUCN <- IUCNRedList_Check_Specie()$IUCNData
      IUCN[1,] <- NA
      return(IUCN)
   }   
   
   synonymSearch <- SearchFB2020$synonyms$scientificname
   
   # infrataxa <- SearchFB2020$infrataxa$scientificname
   
   spp <- SearchFB2020$acceptedName$scientificname
   if (includeSynonym==TRUE & length(synonymSearch)>0) { spp <- c(spp, synonymSearch) }   
   
   binomialSearch <- paste0(word(spp,1), ' ',
                            word(spp,2))
   
   binomialSearch <- binomialSearch %>% data.frame() %>%
      dplyr::distinct() 

   i=2
   for (i in 1:nrow(binomialSearch))
   {   
      x <- IUCNRedList_Check_Specie(binomialSearch[i,], 
                                    token=token)
      if (x[[1]]==TRUE)
      {return(x)}   
   }   
   return(x)
   
}

# IUCNRedList_Check_Specie()
# IUCNRedList_Check_Specie_ALL()
