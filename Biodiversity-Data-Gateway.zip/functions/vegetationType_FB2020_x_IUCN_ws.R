###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 08/06/2022, Pablo H.
################################################################################################################################

#' @section Relação tipos de vegetação FB2020 e IUCN


vegetationType.IUCN_CNCFlora_FB2020 <- readr::read_csv('C:\\BiodiversityDataGateway\\data\\TabelaComparativaTiposVegetacaoIUCN_FB2020.csv',
                                                       locale = locale(encoding = "UTF-8"),
                                                       show_col_types = FALSE)

# vegetationType <- FB2020_IPT$vegetationType
FB2020_get_IUCN_vegetationType <- function(vegetationType,
                                           vegetationType.IUCN_CNCFlora_FB2020=vegetationType.IUCN_CNCFlora_FB2020)
{
  
  # vegetationType <- FloraBrasil2020$vegetationType  %>% as.character()
  
  vegetationType <- vegetationType  %>% as.character()
  vegetationType = strsplit(vegetationType, '-')[[1]]
  vegetationType <- vegetationType %>%
    as.data.frame()
  colnames(vegetationType)  <- c('FB_POR')
  vegetationType
  
  vegetationType.IUCN_CNCFlora_FB2020$FB_POR <- gsub(" ","",textclean::replace_non_ascii(toupper(vegetationType.IUCN_CNCFlora_FB2020$FB_POR)))
  vegetationType$FB_POR <- gsub(" ","",textclean::replace_non_ascii(toupper(vegetationType$FB_POR)))
  
  vegetationType.IUCN_x_FB2020 <- left_join(vegetationType,
                                            vegetationType.IUCN_CNCFlora_FB2020,
                                            by='FB_POR') %>%
    dplyr::select(IUCN_HABITATS_CLASSIFICATION_SCHEME_CODE) %>%
    dplyr::distinct()
  vegetationType.IUCN_x_FB2020
  if (any(is.na(vegetationType.IUCN_x_FB2020))==TRUE)
  {
    return('')
  }
  
  vegetationType.IUCN_x_FB2020 <- vegetationType.IUCN_x_FB2020 %>% na.omit()
  
  # vegetationType.IUCN_x_FB2020.txt <- vegetationType.IUCN_x_FB2020[1,]
  vegetationType.IUCN_x_FB2020.txt <- ''
  for (i in 1:nrow(vegetationType.IUCN_x_FB2020))
  {
    vegetationType.IUCN_x_FB2020.txt <- ifelse(vegetationType.IUCN_x_FB2020.txt!="",
                                               paste0(vegetationType.IUCN_x_FB2020.txt, ', ', vegetationType.IUCN_x_FB2020[i,]),
                                               vegetationType.IUCN_x_FB2020[i,])
  }
  vegetationType.IUCN_x_FB2020.txt
  return(vegetationType.IUCN_x_FB2020.txt)
}

# IUCN_vegetationType <- lapply(FloraBrasil2020$vegetationType[1:1000], FB2020_get_IUCN_vegetationType,
#                               vegetationType.IUCN_CNCFlora_FB2020)
# IUCN_vegetationType <- ldply(IUCN_vegetationType, data.frame)
# IUCN_vegetationType


# nomes

# vegetationType <- spp$vegetationType_FB2020

get_vegetationType_FB2020_x_IUCN <- function(acceptedNameSearch, # = 'Gaya dentata Krapov.',
                                             vegetationType_FB2020,
                                             vegetationType.IUCN_CNCFlora_FB2020=NULL,
                                             path.vegetationType.IUCN_CNCFlora_FB2020 = './data/Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv')
{
  if(is.null(vegetationType.IUCN_CNCFlora_FB2020))
  {
    vegetationType.IUCN_CNCFlora_FB2020 <- readr::read_csv(path.vegetationType.IUCN_CNCFlora_FB2020,
                                                           locale = locale(encoding = "UTF-8"),
                                                           show_col_types = FALSE)
  }
  
  vegetationType.IUCN_CNCFlora_FB2020$`IUCN_Habitats_Classification_Scheme_Version_3.1` <- vegetationType.IUCN_CNCFlora_FB2020$`IUCN HABITATS CLASSIFICATION SCHEME - Version 3.1`
  # vegetationType <- FloraBrasil2020$vegetationType  %>% as.character()
  
  result_vegetationType_FB2020_x_IUCN <- data.frame(vegetationType_FB2020 = NA,
                                                    `IUCN_Habitats_Classification_Scheme_Version_3.1` = NA,
                                                    acceptedNameSearch = NA)[-1,]
  i=28
  for (i in 1:NROW(acceptedNameSearch))
  {
    
    vegetationType <- vegetationType_FB2020[i]  %>% as.character()
    vegetationType = strsplit(vegetationType, '-')[[1]]
    vegetationType <- vegetationType %>%
      as.data.frame()
    colnames(vegetationType)  <- c('FB_POR')
    vegetationType
    
    
    vegetationType$vegetationType_FB2020 <- vegetationType$FB_POR
    
    # ajuste tipo vegetação campo rupestre e area antropica 08-06-2022
    vegetationType.IUCN_CNCFlora_FB2020$FB_POR <- gsub(" ","",textclean::replace_non_ascii(toupper(vegetationType.IUCN_CNCFlora_FB2020$FB_POR)))
    vegetationType$FB_POR <- gsub(" ","",textclean::replace_non_ascii(toupper(vegetationType$FB_POR)))
    #
    
    vegetationType.IUCN_x_FB2020 <- left_join(vegetationType,
                                              vegetationType.IUCN_CNCFlora_FB2020,
                                              by='FB_POR') %>%
      dplyr::select(vegetationType_FB2020, `IUCN_Habitats_Classification_Scheme_Version_3.1`) %>%
      dplyr::distinct() %>%
      na.omit()
    
    if (any(!is.na(vegetationType.IUCN_x_FB2020))==TRUE)
    {
      result_vegetationType_FB2020_x_IUCN <- rbind(result_vegetationType_FB2020_x_IUCN,
                                                   data.frame(vegetationType_FB2020 = vegetationType.IUCN_x_FB2020$vegetationType_FB2020,
                                                              `IUCN_Habitats_Classification_Scheme_Version_3.1` = vegetationType.IUCN_x_FB2020$IUCN_Habitats_Classification_Scheme_Version_3.1,
                                                              acceptedNameSearch = rep(acceptedNameSearch[i],NROW(vegetationType.IUCN_x_FB2020))) )
    }
    # else
    # {
    #    data.frame(vegetationType_FB2020 = NA,
    #               `IUCN_Habitats_Classification_Scheme_Version_3.1` = NA,
    #               acceptedNameUsage = acceptedNameUsage[i])
    # }
    
  }
  
  return(result_vegetationType_FB2020_x_IUCN)
}

