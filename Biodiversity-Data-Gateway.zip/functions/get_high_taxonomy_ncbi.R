# library(rentrez)
# 
# # https://www.ncbi.nlm.nih.gov/Taxonomy/taxonomyhome.html/
# search_name='Urticaceae2'
# search_name='Gardnerina'
# search_name='Gardnerina angustata'
# # search_name='Piqueria angustata'

# library(ontologyPlot)

get_high_taxonomy_ncbi <- function(search_name='Urticaceae')
{
   x_res <- data.frame(family=NA,
                       class=NA,
                       order=NA,
                       phylum=NA,
                       subphylum=NA,
                       kingdom=NA,
                       superkingdom=NA,
                       search_name = search_name,
                       search_notes = NA)
   
   
   x <- rentrez::entrez_search(db='taxonomy',
                               term = paste0(search_name, '[SCIN]'),
                               retmax = 1,
                               use_history=TRUE)
   # names(x)
   
   x_fet <- rentrez::entrez_fetch(db='taxonomy',
                                  # id=x$ids,
                                  web_history = x$web_history,
                                  rettype= 'xml',#'native', #fasta
                                  retmode='') 
   x_fet
   
   
   
   doc<-XML::xmlParse(x_fet)
   x_df <- XML::xmlToDataFrame(nodes = XML::getNodeSet(doc, "//Taxon"))
   
   nl <- 1
   
   x_res[nl,]$search_notes = ifelse(NROW(x_df)==0,'not found', 'ok')
   
   
   x_res[nl,]$family <- x_df$ScientificName[x_df$Rank=='family']
   x_res[nl,]$class <- x_df$ScientificName[x_df$Rank=='class']
   x_res[nl,]$order <- x_df$ScientificName[x_df$Rank=='order']
   x_res[nl,]$phylum <- x_df$ScientificName[x_df$Rank=='phylum']
   x_res[nl,]$subphylum <- x_df$ScientificName[x_df$Rank=='subphylum']
   x_res[nl,]$kingdom <- x_df$ScientificName[x_df$Rank=='kingdom']
   x_res[nl,]$superkingdom <- x_df$ScientificName[x_df$Rank=='superkingdom']
   
   # View(x_res)
   return(x_res)
}
