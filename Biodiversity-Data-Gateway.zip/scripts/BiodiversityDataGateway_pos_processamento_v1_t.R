###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 19/08/2022, Pablo H.
################################################################################################################################

   # 0. Selecionar dataset e overwrite ####
   #' @section Selecionar dataset e overwrite
   {
     
     #' @section Limpar ambiente  R
     { 
       rm(list = ls())
       
       # temp dir R
       if(!dir.exists('C:\\temps')){dir.create('C:\\temps')}
       tempdir <- function() "C:\\temps"
       assignInNamespace("tempdir", tempdir, ns="base", envir=baseenv())
       # assign("tempdir", tempdir, baseenv())
       lockBinding("tempdir", baseenv())
       tempdir()
       
       memory.limit (9999999999)
     }
     
     #' @section Sobrescrever dados?
     overwrite <- FALSE
     
     
     #' @section Selecionar dataset
     # dir_output <- 'WS_Asteraceae_Endemicas' # ok
     # 
     # dir_output <- 'WS_Briofitas_Endemicas'  # ok
     # 
     # dir_output <- 'WS_Bromeliaceae_Endemicas' # ok
     # 
     # dir_output <- 'WS_Euphorbiaceae_Endemicas' # ok
     # 
     # dir_output <- 'WS_Fabaceae_Endemicas'
     # 
     # dir_output <- 'WS_Malvaceae_Endemicas'
     # 
     # dir_output <- 'WS_Melastomataceae_Endemicas'
     # 
     # dir_output <- 'WS_Myrtaceae_Endemicas'
     # 
     # dir_output <- 'WS_Orchidaceae_Endemicas'
     # 
     # dir_output <- 'WS_Poaceae_Endemicas'
     # 
     # dir_output <- 'WS_Rubiaceae_Endemicas'
     # 
     dir_output <- 'WS_Samambaias_e_Licofitas_Endemicas'
     
     
     print(dir_output)
   }
   
   
   # 1. Carregar dados de Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ ####
   #' @section Carregar dados, mapas, e aplicativo
   {
     
     # 1.1. Preparar ambiente R ####
     #' @section Preparar ambiente R
     {
       #' @section Preparar R
       { 
         # rm(list = ls())
         # 
         # # temp dir R
         # if(!dir.exists('C:\\temps')){dir.create('C:\\temps')}
         # tempdir <- function() "C:\\temps"
         # assignInNamespace("tempdir", tempdir, ns="base", envir=baseenv())
         # # assign("tempdir", tempdir, baseenv())
         # lockBinding("tempdir", baseenv())
         # tempdir()
         # 
         # memory.limit (9999999999)
         # 
         #' # 1.1. Instalar pacotes ####
         #' #' @section 1.1. Instalar pacotes
         #' {
         #'   install.packages('shiny', dependencies = TRUE)
         #'   install.packages('DT', dependencies = TRUE)
         #'   install.packages('kableExtra', dependencies = TRUE)
         #'   install.packages('readr', dependencies = TRUE)
         #'   install.packages('dplyr', dependencies = TRUE)
         #'   install.packages('plyr', dependencies = TRUE)
         #'   install.packages('stringr', dependencies = TRUE)
         #'   install.packages('lubridate', dependencies = TRUE)
         #'   install.packages('CoordinateCleaner', dependencies = TRUE)
         #'   install.packages('rnaturalearthdata', dependencies = TRUE)
         #'   install.packages('monographaR', dependencies = TRUE)
         #'   install.packages('stringr', dependencies = TRUE)
         #'   install.packages('jsonlite', dependencies = TRUE)
         #'   install.packages('sqldf', dependencies = TRUE)
         #'   install.packages('RCurl', dependencies = TRUE)
         #'   install.packages('shinydashboard', dependencies = TRUE)
         #'   install.packages('leaflet', dependencies = TRUE)
         #'   
         #'   install.packages('rhandsontable', dependencies = TRUE)
         #'   install.packages('dygraphs', dependencies = TRUE)
         #'   install.packages('shinyWidgets', dependencies = TRUE)
         #'   install.packages('shinythemes', dependencies = TRUE)
         #'   install.packages('sf', dependencies = TRUE)
         #'   install.packages('shinydashboard', dependencies = TRUE)
         #'   install.packages('leaflegend', dependencies = TRUE)
         #'   install.packages('stringi', dependencies = TRUE)
         #'   install.packages('shinyjs', dependencies = TRUE)
         #'   install.packages('redlistr', dependencies = TRUE)
         #'   
         #'   
         #' 
         #' }
         
         library(shiny)
         library(DT)
         library(kableExtra)
         
         # carregar pacotes
         library(readr)
         library(dplyr)
         library(plyr)
         library(stringr)
         library(lubridate)
         library(CoordinateCleaner)
         library(rnaturalearthdata)
         library(raster)
         # library(geobr)
         library(monographaR)
         library(stringr)
         library(jsonlite)
         library(sqldf)
         library(RCurl)
         library(shinydashboard)
         library(leaflet)
         
         # install.packages('dygraphs')
         library(dygraphs)
         
         
         library(rhandsontable) # tabela editavel
         library(shinyWidgets) # botoes
         
         library(shinyjs)
         library(shinythemes)
         library(sf)
         
         
         library(dismo) #dismo::circles()
         
         library(shinydashboard)
         library(leaflegend)
         
         library(stringi)
         
         # library(remotes)
         # options("install.lock"=FALSE)
         # remotes::install_github("brunobrr/bdc")
         library(bdc)
         # devtools::install_github("ropensci/rnaturalearthhires")
         
         # install.packages("MazamaSpatialUtils")
         library(MazamaSpatialUtils)
         
         
         
         # source('./functions/export_CSV_v3.R', encoding = "UTF-8")
         # source('./functions/grafia_UF.R', encoding = "UTF-8")
         # source('./functions/FB2020_IPT_Use_v2.R', encoding = "UTF-8")
         # 
         source('C:\\BiodiversityDataGateway\\functions\\FB2020_IPT_Use_v2_ws.R', encoding = "UTF-8")
         colnames(FloraBrasil2020) <- paste0(colnames(FloraBrasil2020),'_FB2020')
         # 
         # 
         # source('C:\\BiodiversityDataGateway\\functions\\export_CSV_v3.R', encoding = "UTF-8")
         # source('C:\\BiodiversityDataGateway\\functions\\grafia_UF.R', encoding = "UTF-8")
         # 
         # 
         # # source('./functions/FB2020_IPT_Use_v2.R', encoding = "UTF-8")
         # # colnames(FloraBrasil2020) <- paste0(colnames(FloraBrasil2020),'_FB2020')
         # 
         # source('C:\\BiodiversityDataGateway\\functions\\vegetationType_FB2020_x_IUCN_ws.R', encoding = "UTF-8")
         # 
         # source('C:\\BiodiversityDataGateway\\functions\\IUCNRedList_Check_Specie.R', encoding = "UTF-8")
         # # iucn.file <- paste0("./",dir_output,"/results/iucn_status.csv")
         # 
         # source('C:\\BiodiversityDataGateway\\functions\\BGCI_Commercial_Timber_Check_Specie.R', encoding = "UTF-8")
         
         source('C:\\BiodiversityDataGateway\\functions\\get_high_taxonomy_ncbi.R', encoding = "UTF-8")
         
       }
     }
     

     # 1.2. Preparar dados ####
     #' @section Preparar dados
     {
       
       #' @section Preparar estrutura de pastas
       { 
         # path_app <- 'C:\\BiodiversityDataGateway'
         
         # Arecaceae
         # path_app <- 'C:\\BiodiversityDataGateway\\RESULTADOS_WORKSHOP_CNCFLORA2022\\ASTERACEAE'
         path_app <- 'C:\\BiodiversityDataGateway\\RESULTADOS_WORKSHOP_CNCFLORA2022\\SAMAMBAIAS'
         
         path_dataset <- paste0(path_app,'\\',dir_output)
         path_results <- paste0(path_app,'\\',dir_output,'\\results')
         path_results_pre_processamento <- paste0(path_app,'\\',dir_output,'\\results_pre_processamento')
         path_data <- paste0(path_app,'\\',dir_output,'\\data')
         path_bgci <- paste0(path_app,'\\data\\BGCI-Commercial-Timber-List-2014')
         
         # path_TiposVegetacaoFB2020_IUCN <- paste0(path_app,'\\data\\TiposVegetacaoFB2020_IUCN')
         path_TiposVegetacaoFB2020_IUCN <- 'C:\\BiodiversityDataGateway\\data\\TiposVegetacaoFB2020_IUCN'
         
         
         
         path_avaliacoes <- paste0(path_app,'\\',dir_output,'\\assessments')
         path_occ_avaliacoes <- paste0(path_app,'\\',dir_output,'\\occ_assessments')
         path_workshop <- paste0(path_app,'\\',dir_output,'\\Workshop')
         
         
         path_csv_modelo <- paste0('C:\\BiodiversityDataGateway\\data\\CSVsToProflora\\modelos')
         path_csv_results <- paste0(path_app,'\\',dir_output,'\\CSVsToProflora')
         if(!dir.exists(path_csv_results)){dir.create(path_csv_results)}
         
         path_iucn_value <- paste0('C:\\BiodiversityDataGateway\\data\\CSVsToProflora\\iucn_values')
         
         
         # if(!dir.exists(path_app)){dir.create(path_app)}
         # if(!dir.exists(path_dataset)){dir.create(path_dataset)}
         # if(!dir.exists(path_results)){dir.create(path_results)}
         # if(!dir.exists(path_results_pre_processamento)){dir.create(path_results_pre_processamento)}
         # if(!dir.exists(path_data)){dir.create(path_data)}
         # if(!dir.exists(path_avaliacoes)){dir.create(path_avaliacoes)}
         # if(!dir.exists(path_occ_avaliacoes)){dir.create(path_occ_avaliacoes)}
         # if(!dir.exists(path_workshop)){dir.create(path_workshop)}
         
         
       }
       
       #' @section Carregar lista de espécies
       {
         # nome_arquivo <- paste0("./",dir_output,"/results/planilha_acompanhamento_padrao.csv")
         nome_arquivo <- paste0(path_results_pre_processamento,"\\planilha_acompanhamento_padrao.csv")
         spp <- read.csv(nome_arquivo,
                         fileEncoding = "UTF-8") %>%
           dplyr::mutate(NameFB_semAutor = gsub('   ', ' ',NameFB_semAutor)) %>%
           arrange_at(c('FB2020_Family','FB2020_AcceptedNameUsage'))
         # arrange_at(c('FB2020_AcceptedNameUsage'))
         
         
         index <- spp$FB2020_AcceptedNameUsage==''
         sum(index!=TRUE)
         
         spp <- spp[index!=TRUE,]
         
         # ajustar no pre-processamento para ja vir assim
         spp$CITES <- ifelse(is.na(spp$CITES),'',spp$CITES)
         spp$use <- ifelse(is.na(spp$use),'',spp$use)
         
       }
       
       #' @section Buscar informações em FB2020 via IPT
       {
         
         spp <- left_join(spp %>%
                            dplyr::mutate(sppx=FB2020_AcceptedNameUsage),
                          FloraBrasil2020 %>%
                            dplyr::mutate(sppx=scientificName_FB2020),
                          by = 'sppx') %>%
           dplyr::select(-sppx)
         
         
         index <- spp$taxonRank_FB2020 %in% 'ESPECIE'
         spp <- spp[index==TRUE,]
         nrow(spp)
         
         
         familias <- spp$family_FB2020 %>% as.character()
         especies <- spp$scientificNamewithoutAuthorship_FB2020 %>% as.character()
         acceptedName <-spp$scientificName_FB2020 %>% as.character()
         
         #' @details processar nomes conforme backbone taxonômico: FB2020
         {   
           index <- acceptedName %in% FloraBrasil2020$scientificName_FB2020
           sum(index)
           print(paste0('Number of taxa: ',length(acceptedName)))
           
           synonym.file <- paste0(path_results_pre_processamento,"\\synonym.csv") 
           infrataxa.file <- paste0(path_results_pre_processamento,"\\infrataxa.csv")
           lista_especies.file <- paste0(path_results_pre_processamento,"\\lista_especies.csv")
           
           if((!file.exists(synonym.file) | !file.exists(infrataxa.file)) | overwrite==TRUE)
           {
             
             synonym <- FloraBrasil2020 %>% 
               dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                               taxonomicStatus_FB2020 == 'SINONIMO') %>%
               dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                             synonym = scientificName_FB2020) %>%
               dplyr::select(acceptedName,
                             synonym)
             
             infrataxa <- FloraBrasil2020 %>% 
               dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                               !is.na(infraspecificEpithet_FB2020)) %>%
               dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                             infrataxa = scientificName_FB2020) %>%
               dplyr::select(acceptedName,
                             infrataxa)
             
             
             synonym_withoutAuthorship <- FloraBrasil2020 %>% 
               dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                               taxonomicStatus_FB2020 == 'SINONIMO') %>%
               dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                             synonym = scientificNamewithoutAuthorship_FB2020) %>%
               dplyr::select(acceptedName,
                             synonym)
             
             infrataxa_withoutAuthorship <- FloraBrasil2020 %>% 
               dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                               !is.na(infraspecificEpithet_FB2020)) %>%
               dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                             infrataxa = scientificNamewithoutAuthorship_FB2020) %>%
               dplyr::select(acceptedName,
                             infrataxa)
             
             write.csv(synonym, synonym.file, fileEncoding = "UTF-8", na = "",
                       row.names = FALSE)
             
             write.csv(infrataxa, infrataxa.file, fileEncoding = "UTF-8", na = "",
                       row.names = FALSE)
             
             write.csv(spp, lista_especies.file, fileEncoding = "UTF-8", na = "",
                       row.names = FALSE)
           }else
           {
             synonym <- readr::read_csv(synonym.file,
                                        locale = locale(encoding = "UTF-8"),
                                        show_col_types = FALSE)
             
             infrataxa <- readr::read_csv(infrataxa.file,
                                          locale = locale(encoding = "UTF-8"),
                                          show_col_types = FALSE)
           }
         }
       }
       
       #' @section Selecionar Possíveis Lcs
       {
         
         eoo_limit_LC <- 30000
         aoo_limit_LC <- 3000
         locations_min_number_LC <- 10
         
         # ifelse( ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number)), 
         #         'Possivelmente Menos preocupante (LC)', 'Possivelmente ameaça ou dados insuficientes '), 
         
         # index <- ( ( spp$eoo > eoo_limit_LC) & ( (spp$aoo2*4) > aoo_limit_LC) & (TRUE==TRUE) )  | 
         #          ( ( spp$eoo > eoo_limit_LC) & ( (spp$aoo2*4) > aoo_limit_LC) & (spp$nusado > locations_min_number_LC) )
         
         index <- ( ( spp$eoo > eoo_limit_LC) & (spp$nusado > locations_min_number_LC) )
         
         sum(index==TRUE)
         
         spp <- spp[index==TRUE,]
         
         nrow(spp)
       }
       
       #' @section Buscar informações sobre avaliaçõe em IUCN via API
       {
         iucn.file <- paste0(path_results_pre_processamento,"\\iucn_status.csv")
         
         if((!file.exists(iucn.file)) | overwrite==TRUE)
         {
           IUCN <- {}
           restart <- 0
           i<- 1
           
           for (i in 1:NROW(spp))
           {
             
             if (i < restart) 
             { 
               print(i) 
               next
             }
             
             x <- spp$NameFB_semAutor[i] #spp$FB2020_AcceptedNameUsage[i]
             
             print( paste0(i, ' : ', x))
             if (i>restart)
             {
               IUCN <- rbind(IUCN, IUCNRedList_Check_Specie(x)$IUCNData)
             } else {
               IUCN[i,] <- IUCNRedList_Check_Specie(x)$IUCNData
             }
             
             if (!is.na(IUCN[NROW(IUCN),]$category)==TRUE) {  print(paste0('IUCN: ', IUCN[NROW(IUCN),c('category', 'criteria')]))}
           }
           
           IUCN$acceptedNameSearch <- spp$FB2020_AcceptedNameUsage
           
           # gravar dados iucn
           write.csv(IUCN, iucn.file, fileEncoding = "UTF-8", na = "",
                     row.names = FALSE)
           
         }else
         {
           IUCN <- readr::read_csv(iucn.file,
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)
         }
         
       }
       
       #' @section Buscar informações sobre uso madeireiro - BGCI-Commercial-Timber-List-2014
       {
         
         BGCI_CommercialTimber.file <- paste0(path_results_pre_processamento,"\\bgci_commercial_timber_status.csv")
         
         if((!file.exists(BGCI_CommercialTimber.file)) | overwrite==TRUE)
         {
           
           bgci_CommercialTimber <- BGCI_Commercial_Timber_Check_Specie(acceptedNameSearch=spp$scientificName_FB2020,
                                                                        path_bgci=path_bgci)
           
           # bgci_CommercialTimber <- BGCI_Commercial_Timber_Check_Specie(acceptedNameSearch=rep('Morus alba',NROW(spp)),
           #                                                              path_bgci=path_bgci)
           
           # gravar dados bgci
           write.csv(bgci_CommercialTimber$sourceResult, BGCI_CommercialTimber.file, fileEncoding = "UTF-8", na = "",
                     row.names = FALSE)
           
           write.csv(bgci_CommercialTimber$rawResult, paste0(path_results_pre_processamento,"\\bgci_commercial_timber_raw.csv"), fileEncoding = "UTF-8", na = "",
                     row.names = FALSE)
           
           bgci_CommercialTimber <- bgci_CommercialTimber$sourceResult
           
         }else
         {
           bgci_CommercialTimber <- readr::read_csv(BGCI_CommercialTimber.file,
                                                    locale = locale(encoding = "UTF-8"),
                                                    show_col_types = FALSE)
         }
       }
       
       #' @section IUCN Vegetation Type x FB2020 IPT Vegetation Type
       {
         
         #' @details Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv
         name.file <- paste0(path_TiposVegetacaoFB2020_IUCN,"\\Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv")
         TiposVegetacaoFB2020_IUCN <- readr::read_csv(name.file,
                                                      locale = locale(encoding = "UTF-8"),
                                                      show_col_types = FALSE) %>%
           dplyr::arrange_at('IUCN_HABITATS_CLASSIFICATION_SCHEME_CODE')
         
         
         #' @details arquivo resultado com os tipos de vegetacao da espécie
         vegetationType_FB2020_x_IUCN.file <- paste0(path_results_pre_processamento,"\\vegetationType_FB2020_x_IUCN.csv")
         
         
         if((!file.exists(vegetationType_FB2020_x_IUCN.file)) | overwrite==TRUE)
         {
           # source('./functions/vegetationType_FB2020_x_IUCN.R', encoding = "UTF-8")
           
           vegetationType_FB2020_x_IUCN <- get_vegetationType_FB2020_x_IUCN(acceptedNameSearch = spp$FB2020_AcceptedNameUsage,
                                                                            vegetationType_FB2020 = spp$vegetationType_FB2020,
                                                                            vegetationType.IUCN_CNCFlora_FB2020=vegetationType.IUCN_CNCFlora_FB2020,
                                                                            path.vegetationType.IUCN_CNCFlora_FB2020 = paste0(path_TiposVegetacaoFB2020_IUCN,"\\Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv"))#'./data/Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv')
           
           # gravar dados bgci
           write.csv(vegetationType_FB2020_x_IUCN, vegetationType_FB2020_x_IUCN.file, fileEncoding = "UTF-8", na = "",
                     row.names = FALSE)
           
         }else
         {
           vegetationType_FB2020_x_IUCN <- readr::read_csv(vegetationType_FB2020_x_IUCN.file,
                                                           locale = locale(encoding = "UTF-8"),
                                                           show_col_types = FALSE)
         }
         
         
       }
       
       #' #' @section Preparar CSV base para cada espécie
       #' {
       #'    
       #'    # name.file <- paste0("./",dir_output,"/results/5_occ_selectMoreInformativeRecord.csv")
       #'    name.file <- paste0(path_results_pre_processamento,"\\5_occ_selectMoreInformativeRecord.csv")
       #'    
       #'    occ_csv <- readr::read_csv(name.file,
       #'                               locale = locale(encoding = "UTF-8"),
       #'                               show_col_types = FALSE) %>%
       #'       dplyr::mutate(Identificação=FALSE,
       #'                     Localização=FALSE,
       #'                     verticeEOO=FALSE,
       #'                     # Verificar_Vertice_EOO=FALSE,
       #'                     preValidacao='',
       #'                     emUC=FALSE,
       #'                     tipoUC=NA,
       #'                     nomeUC=NA,
       #'                     emJB=FALSE,
       #'                     
       #'                     # outros flags
       #'                     Duplicação=FALSE,
       #'                     bioma='',
       #'                     
       #'                     
       #'                     .before = 1)
       #'    
       #'    #  ID geral
       #'    occ_csv <- occ_csv %>%
       #'       dplyr::mutate(ID_PRV= paste0(dir_output,'_',1:NROW(occ_csv)),
       #'                     emUso=FALSE)
       #'    
       #'    
       #'    occ_in <- in_out_cncflora(occ_csv)$occ_in %>%
       #'       dplyr::mutate(Longitude = Ctrl_autoGeoLongitude,
       #'                     Latitude = Ctrl_autoGeoLatitude,
       #'                     preValidacao='in',
       #'                     
       #'                     Identificação=TRUE,
       #'                     Localização=TRUE,
       #'                     
       #'                     emUso=TRUE)
       #'    
       #'    occ_out_to_recover <- in_out_cncflora(occ_csv)$occ_out_to_recover %>%
       #'       dplyr::mutate(Longitude = Ctrl_decimalLongitude,
       #'                     Latitude = Ctrl_decimalLatitude,
       #'                     preValidacao='out_to_recover',
       #'                     
       #'                     Identificação=TRUE,
       #'                     Localização=FALSE,
       #'                     
       #'                     emUso=FALSE)
       #'    
       #'    occ_global <- in_out_cncflora(occ_csv)$occ_global %>%
       #'       dplyr::mutate(Longitude = Ctrl_decimalLongitude,
       #'                     Latitude = Ctrl_decimalLatitude,
       #'                     preValidacao='global')
       #'    
       #'    occ_global <- anti_join(occ_global,
       #'                            rbind(occ_in,
       #'                                  occ_out_to_recover),
       #'                            by = 'ID_PRV') %>%
       #'       dplyr::mutate(Identificação=TRUE,
       #'                     Localização=TRUE,
       #'                     emUso=TRUE)
       #'    
       #'    
       #'    occ_out <- in_out_cncflora(occ_csv)$occ_out %>%
       #'       dplyr::mutate(Longitude = Ctrl_decimalLongitude,
       #'                     Latitude = Ctrl_decimalLatitude,
       #'                     preValidacao='out',
       #'                     emUso=FALSE)
       #'    
       #'    occ <- rbind(occ_out_to_recover,
       #'                 occ_in,
       #'                 occ_global,
       #'                 occ_out)
       #'    
       #'    # preparação ou manutanção do conjutno de dados
       #'    
       #'    if (overwrite==TRUE)
       #'    { file.remove(list.files(path_data, full.names = TRUE))}
       #'    
       #'    
       #'    # 11-05-2022 nomo sem autor
       #'    # path_file_csv <- paste0(path_data,'/',dir_output,' ',spp$FB2020_AcceptedNameUsage,'.csv')
       #'    path_file_csv <- paste0(path_data,'/',dir_output,' ',spp$NameFB_semAutor,'.csv')
       #'    
       #'    path_file_csv <- gsub(' ', '_', path_file_csv)
       #'    
       #'    i=1
       #'    for (i in 1:NROW(spp))
       #'    {
       #'       
       #'       
       #'       occ_tmp <- occ[occ$Ctrl_scientificNameReference %in% spp$FB2020_AcceptedNameUsage[i],]
       #'       # occ_tmp <- occ %>% 
       #'       #    dplyr::filter(Ctrl_scientificNameReference == spp$FB2020_AcceptedNameUsage[i])
       #'       
       #'       
       #'       tot <- NROW(occ_tmp)
       #'       print(paste0(path_file_csv[i], ' ',tot))
       #'       
       #'       if (tot>0)
       #'       {
       #'          if (!file.exists(path_file_csv[i]) | overwrite==TRUE)
       #'          {
       #'             write.csv(occ_tmp, path_file_csv[i], fileEncoding = "UTF-8", na = "", row.names = FALSE)
       #'             print('novo conjunto de dados criado')
       #'             
       #'          }else
       #'          {
       #'             print('conjunto de dados antigo mantido')
       #'          }   
       #'       }
       #'       
       #'       
       #'    }   
       #' }
       
       #' #' @section Preparar CSV lista de espécies e ocorrências PLC para pre-validacao de especialistas
       #' {
       #'    # tabelas para pre-validacao de especialistas
       #'    path_file_csv_especilista <- paste0(path_results_pre_processamento,'/',dir_output,' Lista especies PLC Especialistas.csv')
       #'    write.csv(spp, path_file_csv_especilista, fileEncoding = "UTF-8", na = "", row.names = FALSE)
       #'    
       #'    path_file_csv_especilista <- paste0(path_results_pre_processamento,'/',dir_output,' Ocorrencias PLC Especialistas.csv')
       #'    write.csv(occ_in, path_file_csv_especilista, fileEncoding = "UTF-8", na = "", row.names = FALSE)
       #' }
       
     }
     
     # 1.3. Carregar shapes PATS
     {
       # ucs BR
       # http:://
       shape_path <- "C:\\BiodiversityDataGateway\\Shapefiles\\PATs"
       shape_file <- "PANs_Publicados"
       pan_publicados <- rgdal::readOGR(dsn=shape_path,
                                layer=shape_file,
                                verbose=FALSE,
                                stringsAsFactors=FALSE,
                                encoding = 'UTF-8', #'1252', #'ESRI Shapefile',#'UTF-8', #'SHAPE_ENCODING'
                                use_iconv =TRUE)
       proj4string(pan_publicados) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
       pan_publicados$PAN
       pan_publicados$PAN[3] <- "Plano de Ação Nacional para a conservação da flora ameaçada de extinção da Serra do Espinhaço Meridional"
       pan_publicados$PAN

       # pan_publicados$PAN
       
       shape_path <- "C:\\BiodiversityDataGateway\\Shapefiles\\PATs"
       shape_file <- "PANs_em_Elaboracao"
       pan_em_elaboracao <- rgdal::readOGR(dsn=shape_path,
                                        layer=shape_file,
                                        verbose=FALSE,
                                        stringsAsFactors=FALSE,
                                        encoding =  'UTF-8',#'SHAPE_ENCODING', #'UTF-8',
                                        use_iconv =TRUE)
       proj4string(pan_em_elaboracao) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
       # pan_em_elaboracao$pan_nome
       
       
       shape_path <- "C:\\BiodiversityDataGateway\\Shapefiles\\PATs"
       shape_file <- "PATs_GEF_ProEspecies"
       pats_gef_proespecies <- rgdal::readOGR(dsn=shape_path,
                                         layer=shape_file,
                                         verbose=FALSE,
                                         stringsAsFactors=FALSE,
                                         encoding =  'UTF-8',#'SHAPE_ENCODING', #'UTF-8',
                                         use_iconv =TRUE)
       proj4string(pats_gef_proespecies) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
       
       pats_gef_proespecies$nome <- NA
       pats_gef_proespecies$codigo <- NA
       it = 1
       for(it in 1:NROW(pats_gef_proespecies))
       {
         if(is.na(pats_gef_proespecies$territorio[it])==T){next}
         pats_gef_proespecies$nome[it] <- gsub(paste0(pats_gef_proespecies$territorio[it]," - "), '', pats_gef_proespecies$Nome_compl[it])  
         pats_gef_proespecies$codigo[it] <- gsub('TER', '', pats_gef_proespecies$territorio[it])
       }
    }
   }   
   
   
   # 2. Carregar modelos CSVs IUCN
   {
     fil <- list.files(path_csv_modelo,full.names = TRUE)
     csv_result_file <- paste0(path_csv_results,'\\', list.files(path_csv_modelo,full.names = FALSE))
     
     # allfields.csv
     # assessments.csv        
     # commonnames.csv
     # conservationneeded.csv
     # countries.csv
     # credits.csv
     # habitats.csv        
     # maps.csv
     # plantspecific.csv
     # references.csv        
     # synonyms.csv
     # taxonomy.csv
     # threats.csv
     # usetrade.csv
     
     
     # allfields.csv
     m_allfields <- readr::read_csv(fil[1],
                                    locale = locale(encoding = "UTF-8"),
                                    show_col_types = FALSE)[-0,]
     
     
     # assessments.csv        
     m_assessments <- readr::read_csv(fil[2],
                                      locale = locale(encoding = "UTF-8"),
                                      show_col_types = FALSE)[-0,]
     
     # commonnames.csv
     m_commonnames <- readr::read_csv(fil[3],
                                      locale = locale(encoding = "UTF-8"),
                                      show_col_types = FALSE)[-0,]
     
     # conservationneeded.csv
     m_conservationneeded <- readr::read_csv(fil[4],
                                             locale = locale(encoding = "UTF-8"),
                                             show_col_types = FALSE)[-0,]
     
     # countries.csv
     m_countries <- readr::read_csv(fil[5],
                                    locale = locale(encoding = "UTF-8"),
                                    show_col_types = FALSE)[-0,]
     
     path_iucn_value 
     
     
     # Countryoccurrence.countryoccurrencelookup.csv
     Countryoccurrence.countryoccurrencelookup <- readr::read_delim(paste0(path_iucn_value,'\\Countryoccurrence.countryoccurrencelookup.csv'),
                                                                    delim = ',',
                                                                    locale = locale(encoding = "UTF-8"),
                                                                    show_col_types = T)
     
     Countryoccurrence.countryoccurrencelookup
     
     # credits.csv
     m_credits <- readr::read_csv(fil[6],
                                  locale = locale(encoding = "UTF-8"),
                                  show_col_types = FALSE)[-0,]
     
     # habitats.csv        
     m_habitats <- readr::read_csv(fil[7],
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)[-0,]
     
     # maps.csv
     m_maps <- readr::read_csv(fil[8],
                               locale = locale(encoding = "UTF-8"),
                               show_col_types = FALSE)[-0,]
     
     # plantspecific.csv
     m_plantspecific <- readr::read_csv(fil[9],
                                        locale = locale(encoding = "UTF-8"),
                                        show_col_types = FALSE)[-0,]
     
     # references.csv        
     m_references <- readr::read_csv(fil[10],
                                     locale = locale(encoding = "UTF-8"),
                                     show_col_types = FALSE)[-0,]
     
     # synonyms.csv
     m_synonyms <- readr::read_csv(fil[11],
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)[-0,]
     
     # taxonomy.csv
     m_taxonomy <- readr::read_csv(fil[12],
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)[-0,]
     
     # threats.csv
     m_threats <- readr::read_csv(fil[13],
                                  locale = locale(encoding = "UTF-8"),
                                  show_col_types = FALSE)[-0,]
     
     # usetrade.csv
     m_usetrade <- readr::read_csv(fil[14],
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)[-0,]
     
     m_occurrence <- readr::read_csv('C:\\BiodiversityDataGateway\\data\\CSVsToProflora\\occurrence.csv',
                                     locale = locale(encoding = "UTF-8"),
                                     show_col_types = FALSE)[-0,]
     
     
     
     
   }
   
   
   # Copiar estrutura csv iucn
   {
     
     allfields <- m_allfields[-1,]
     
     assessments <- m_assessments[-1,]
     
     maps <- m_maps[-1,]
     
     occurrence  <- m_occurrence[-1,]
     occurrence$dateIdentified <- occurrence$dateIdentified %>% as.character()
     occurrence$recordNumber <- occurrence$recordNumber %>% as.character()
     occurrence$catalogNumber <- occurrence$catalogNumber %>% as.character()
     
     commonnames <- m_commonnames[-1,]
     
     synonyms <- m_synonyms[-1,]
     synonyms$internal_taxon_id <- synonyms$internal_taxon_id %>% as.character()
     
     taxonomy <- m_taxonomy[-1,]
     
     countries <- m_countries[-1,]
     
     credits <- m_credits[-1,]
     
     habitats <- m_habitats[-1,]
     
     references <- m_references[-1,]
     
     
     # CSVs sem informação
     threats <- m_threats[-1,]
     threats$internal_taxon_id <- threats$internal_taxon_id %>% as.character()
     
     usetrade <- m_usetrade[-1,]
     usetrade$internal_taxon_id <- usetrade$internal_taxon_id %>% as.character()
     usetrade$UTEndUse.UTEndUseSubfield.UTEndUseLookup <- usetrade$UTEndUse.UTEndUseSubfield.UTEndUseLookup %>% as.character()
     
     plantspecific <- m_plantspecific[-1,]
     plantspecific$internal_taxon_id <- plantspecific$internal_taxon_id %>% as.character()
     
     conservationneeded <- m_conservationneeded[-1,]
     conservationneeded$internal_taxon_id <- conservationneeded$internal_taxon_id %>% as.character()
     
     occ_all <- {}
     
     # modelo de credits.csv
     {
       
       credits_recorte <- readr::read_csv(paste0(path_app,'\\Credits_Workshop_',dir_output
                                                 ,'.csv'),
                                          locale = locale(encoding = "UTF-8"),
                                          show_col_types = FALSE)
     }
   }
   
   
   i <- 1
   #' @section Processar dados
   # for( i in 1:5)#NROW(spp))
   for( i in 1:NROW(spp))
   {
     
     
     sp_selected <- spp$FB2020_AcceptedNameUsage[i]
     
     print(paste0(i, ' - ',sp_selected))
     
     binomio <- paste0(word(sp_selected,1), '_',word(sp_selected,2))
     # binomio <- 'Moquiniastrum_paniculatum'
     
     # carga ordem, classe... para familias
     {
       
       familia_busca <- spp$family_FB2020 %>% unique()
       
       ifam <- 1
       for( ifam in 1:length(familia_busca))
       {
         
         print(familia_busca[ifam])
         index_fam <- spp$family_FB2020 %in% familia_busca[ifam]
         
         
         if(any(is.na(spp$class_FB2020[index_fam==TRUE]))==FALSE){next}
         
         res_tmp <- get_high_taxonomy_ncbi(familia_busca[ifam])
         
         if(sum(index_fam)>0)
         {
           spp$class_FB2020[index_fam==TRUE] <- res_tmp$class
           spp$order_FB2020[index_fam==TRUE] <- res_tmp$order
           spp$phylum_FB2020[index_fam==TRUE] <- res_tmp$phylum
           
           print(res_tmp$class)
         }else{
           print(paste0('Não achou: ',familia_busca[ifam]))
         }
         
       }
       
     }
     
     
     # carga resultados workshop
     {
       
       # 0. testar de ha avaiação pelo arquivo txt da avaliação
       
       # 1. recuperar copias arquivos ocorrencias
       fil <- list.files(path_occ_avaliacoes,full.names = TRUE)
       index_f <- grep(binomio,fil)               
       if (NROW(index_f)>0)
       {
         
         fil_sp <- fil[index_f]
         # index_f <- grep(binomio,fil)               
         
         occ_add_avaliacao <- grep(paste(c('occ_out_to_recover', 'occ_in', 'occ_foraBR') ,collapse="|"), fil_sp, value=TRUE)
         
         occ_flag <- fil_sp[!fil_sp %in% occ_add_avaliacao]
         fil.inf <- file.info(occ_flag)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         occ_flag <- occ_flag[index==TRUE]
         occ_flag <- readr::read_csv(occ_flag,
                                     locale = locale(encoding = "UTF-8"),
                                     show_col_types = FALSE)
         
         
         occ_in <-  grep(paste('occ_in' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(occ_in)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         occ_in <- occ_in[index==TRUE]
         occ_in <- readr::read_csv(occ_in,
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)
         
         colnames(occ_in) %in% colnames(occ_flag)
         occ_out_to_recover <-  grep(paste('occ_out_to_recover' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(occ_out_to_recover)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         occ_out_to_recover <- occ_out_to_recover[index==TRUE]
         occ_out_to_recover <- readr::read_csv(occ_out_to_recover,
                                               locale = locale(encoding = "UTF-8"),
                                               show_col_types = FALSE)
         
         
         occ_foraBR <-  grep(paste('occ_foraBR' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(occ_foraBR)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         occ_foraBR <- occ_foraBR[index==TRUE]
         occ_foraBR <- readr::read_csv(occ_foraBR,
                                       locale = locale(encoding = "UTF-8"),
                                       show_col_types = FALSE)
         
         
         
         # atualizar filtros
         occ_flag <- occ_flag %>%
           dplyr::arrange_at('ID_PRV')
         
         occ_in <- occ_in %>%
           dplyr::arrange_at('ID_PRV')
         
         if (any(occ_in$Identificação == occ_flag$Identificação)==FALSE)
         {occ_in$Identificação <- occ_flag$Identificação}
         
         if (any(occ_in$Localização == occ_flag$Localização)==FALSE)
         {occ_in$Localização <- occ_flag$Localização}
         
         # occ_tmp$Verificar_Vertice_EOO[occ_tmp$preValidacao %in% c('in')] <- x$Verificar_Vertice_EOO
         if (any(occ_in$Latitude == occ_flag$Latitude)==FALSE)
         {occ_in$Latitude <- occ_flag$Latitude}
         
         if (any(occ_in$Longitude == occ_flag$Longitude)==FALSE)
         {occ_in$Longitude <- occ_flag$Longitude}
         
         
         occ_in_all <- occ_in
         
         occ_in <- occ_in_all %>%
           dplyr::filter(emUso==TRUE)
         
         NROW(occ_in_all)
         NROW(occ_in)
         
         # 
         # 
         # occ_global <- anti_join(occ_global,
         #                         rbind(occ_in,
         #                               occ_out_to_recover),
         #                         by = 'ID_PRV')
         
       }else{
         occ_in <-
           occ_in_all <-
           occ_foraBR <- 
           occ_out_to_recover <- {}
         
       }
       
       # 2. recuperar copias arquivo 'avaliacoes', 'biomas', 'estados', 'municipios', 'serie_coleta', 'uc_PI', 'uc_US', 'texto_avaliacao'
       fil <- list.files(path_avaliacoes,full.names = TRUE)
       index_f <- grep(binomio,fil)               
       if (NROW(index_f)>0)
       {
         fil_sp <- fil[index_f]
         
         add_avaliacao <- grep(paste(c('biomas', 'estados', 'municipios', 'serie_coleta', 'uc_PI', 'uc_US', 'texto_avaliacao') ,collapse="|"), fil_sp, value=TRUE)
         
         avaliacao <- fil_sp[!fil_sp %in% add_avaliacao]
         fil.inf <- file.info(avaliacao)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         avaliacao <- avaliacao[index==TRUE]
         
         data_avaliacao <- lubridate::ymd(date(file.info(avaliacao[index==TRUE])$mtime))
         # data_avaliacao <- paste0(lubridate::mday(data_avaliacao),'/',lubridate::month(data_avaliacao),'/',lubridate::year(data_avaliacao))
         data_avaliacao <- paste0(str_sub(data_avaliacao,9,10),'/',str_sub(data_avaliacao,6,7),'/',str_sub(data_avaliacao,1,4))
         
         avaliacao <- readr::read_csv(avaliacao,
                                      locale = locale(encoding = "UTF-8"),
                                      show_col_types = FALSE)
         
         
         
         biomas <-  grep(paste('biomas' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(biomas)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         biomas <- biomas[index==TRUE]
         biomas <- readr::read_csv(biomas,
                                   locale = locale(encoding = "UTF-8"),
                                   show_col_types = FALSE)
         
         
         estados <-  grep(paste('estados' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(estados)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         estados <- estados[index==TRUE]
         estados <- readr::read_csv(estados,
                                    locale = locale(encoding = "UTF-8"),
                                    show_col_types = FALSE)
         
         
         municipios <-  grep(paste('municipios' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(municipios)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         municipios <- municipios[index==TRUE]
         municipios <- readr::read_csv(municipios,
                                       locale = locale(encoding = "UTF-8"),
                                       show_col_types = FALSE)
         
         
         municipios <-  grep(paste('municipios' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(municipios)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         municipios <- municipios[index==TRUE]
         municipios <- readr::read_csv(municipios,
                                       locale = locale(encoding = "UTF-8"),
                                       show_col_types = FALSE)
         
         uc_PI <-  grep(paste('uc_PI' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(uc_PI)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         uc_PI <- uc_PI[index==TRUE]
         uc_PI <- readr::read_csv(uc_PI,
                                  locale = locale(encoding = "UTF-8"),
                                  show_col_types = FALSE)
         
         
         uc_US <-  grep(paste('uc_US' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(uc_US)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         uc_US <- uc_US[index==TRUE]
         uc_US <- readr::read_csv(uc_US,
                                  locale = locale(encoding = "UTF-8"),
                                  show_col_types = FALSE)
         
         
         texto_avaliacao <-  grep(paste('texto_avaliacao' ,collapse="|"), fil_sp, value=TRUE)
         fil.inf <- file.info(texto_avaliacao)
         index <- fil.inf$mtime == max(fil.inf$mtime)
         texto_avaliacao <- texto_avaliacao[index==TRUE]
         texto_avaliacao <- readr::read_file(texto_avaliacao,
                                             locale = locale(encoding = "UTF-8"))
         
         # ajustar texto orquideas
       }else{
         next
       }
     }
     
     
     #' @section junção br e fora br e padronizar nome de paises e codigos iso2 e iso3
     {
       
       occ_global <-rbind(occ_in %>% dplyr::select(-cor), occ_foraBR)
       occ_global$country <- occ_global$Ctrl_country
       occ_global$countryCode_ISO3 <- ''
       occ_global$CountryOccurrenceName <- ''
       

       occ_all_tmp <- rbind(occ_in %>% dplyr::select(-cor) %>% dplyr::mutate(select_record='valido',.before=1), 
                            occ_foraBR %>% dplyr::mutate(select_record='foraBR',.before=1),
                            occ_out_to_recover %>% dplyr::mutate(select_record='checar',.before=1))
       
       
       occ_all <- rbind(occ_all, 
                        occ_all_tmp)
       
       

       #' @section padronizar nome de paises e codigos iso2 e iso3
       if (NROW(occ_global)>0)
       { 
         #' @details padronizar nomes dos países
         occ_global <- bdc::bdc_country_standardized(occ_global, country = "Ctrl_country")
         
         #' @details iso2ToIso3 para utilizar em coordinateCleaner
         index_1 <- !is.na(occ_global$countryCode)
         occ_global$countryCode_ISO3[index_1==TRUE] <- MazamaSpatialUtils::iso2ToIso3(occ_global$countryCode[index_1==TRUE])
         
         occ_global$countryCode[index_1==TRUE]
         ioo=61
         for (ioo in 1:NROW(occ_global))
         {
           index_oo <- Countryoccurrence.countryoccurrencelookup$countryCode%in%occ_global$countryCode[ioo]
           
           occ_global$CountryOccurrenceName[ioo] <- na.omit(Countryoccurrence.countryoccurrencelookup$nome[index_oo==TRUE])
         }
         
       }
       
       
       
     }
     
     
     # assessments
     {
       # Campos:
       # 'HabitatDocumentation.narrative', # OK
       # 'MapStatus.status', # OK
       # 'PopulationDocumentation.narrative', OK
       # 'PopulationTrend.value', OK
       # 'RangeDocumentation.narrative', OK
       # 'RedListAssessmentDate.value', OK
       # 'RedListCriteria.critVersion', OK
       # 'RedListCriteria.manualCategory', OK
       # 'RedListCriteria.manualCriteriaString', OK
       # 'RedListCriteria.possiblyExtinct', OK
       # 'System.value', OK
       # 'ThreatsDocumentation.value', OK
       # 'internal_taxon_id' OK

       print('assessments')
       
       assessments <- assessments %>% dplyr::add_row()
       nla <- NROW(assessments)
       
       # BiogeographicRealm.realm # Neotropical
       # para todas espécies
       {
         assessments[nla,]$BiogeographicRealm.realm <- 'Neotropical'
       }
       
       
       # ConservationActionsDocumentation.narrative # A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora endêmica ameaçada de extinção do estado do Rio de Janeiro (Pougy et al., 2018).A espécie foi registrada nas seguintes Unidades de Conservação: Área de Proteção Ambiental Bacia do Rio Pandeiros, Área de Proteção Ambiental Caminhos Ecológicos da Boa Esperança, Área de Proteção Ambiental da Pedra Branca, Área de Proteção Ambiental do Itacuru, Área de Proteção Ambiental Lagoa Encantada, Estação Ecológica Estadual Wenceslau Guimarães, Parque Estadual do Desengano, Parque Nacional da Serra das Lontras, Reserva Biológica Estadual da Praia do Sul e Reserva Particular do Patrimônio Natural Mutum Preto.
       # # texto padrão  de unidades de conservação
       # # checar planos de ação 
       {
         # PAN, PAT e UCS
         
         UCs <- c(uc_PI$nameUC_PI,
                  uc_US$nameUC_US)
         
         UCs_n <- NROW(UCs)
         
         # PATs e PANs
         {
           index_ucs <- ! occ_global$autoGeoNotes %in% "Coordenada centróide de município"
           index_ucs_in <- ! occ_global$autoGeoNotes %in% "Coordenada centróide de município"
           
           occ.pto_ucs <- sp::SpatialPointsDataFrame(cbind.data.frame(occ_global$Longitude[index_ucs==TRUE],
                                                                      occ_global$Latitude[index_ucs==TRUE]),
                                                     data.frame(occ_global[index_ucs==TRUE,] %>% dplyr::select()))
           proj4string(occ.pto_ucs) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
           
           x_pats <- over(occ.pto_ucs, pats_gef_proespecies) %>% na.omit()
           # x_pats$Nome_compl
           
           # Se ocorre em PAN: A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora endêmica ameaçada de extinção do estado do Rio de Janeiro (Pougy et al., 2018)
           x_pans <- over(occ.pto_ucs, pan_publicados) %>% na.omit()
           # x_pans$PAN
           
           # somente em notas do cnservationeded
           # A espécie ocorre em territórios que poderão ser contemplados por Planos de Ação Nacional (PAN) Territorial, no âmbito do projeto GEF Pró-Espécies - Todos Contra a Extinção: Território PAT Paraná-São Paulo - 19 (PR), Território PAT Planalto Sul - 24 (RS, SC).
           x_pans_em_elaboracao <- over(occ.pto_ucs, pan_em_elaboracao) %>% na.omit()
           # x_pans_em_elaboracao$pan_nome
           

           
           # se ocorre em pan e uc 
           # PAN Se ocorre em PAN: A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora endêmica ameaçada de extinção do estado do Rio de Janeiro 
           # adicionar referencia 
           # referencia pra cada PAN -
           
           # pan_publicados$PAN
           # A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora endêmica ameaçada de extinção do estado do Rio de Janeiro (Pougy et al., 2018) 
           # A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora ameaçada de extinção da Serra do Espinhaço Meridional (Pougy et al., 2015).
           # A espécie ocorre no território de abrangência do Plano de Ação Nacional Lagoas do Sul para a conservação da flora melhorar o estado de conservação das espécies ameaçadas e dos ecossistemas das lagoas da planície costeira do sul do Brasil (ICMBio, 2018).
           # A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora ameaçada de extinção da região de Grão Mogol - Francisco Sá (Pougy et al., 2015)
           
           if(NROW(x_pans) > 0)
           {
             
             texto_pans_para_texto_ucs <- ''
             
             # RJ
             if(any(pan_publicados$PAN %in% "Plano de Ação Nacional para a Conservação da Flora Endêmica Ameaçada de Extinção do estado do Rio de Janeiro")==T)
             {
               texto_pans_para_texto_ucs <- 'A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora endêmica ameaçada de extinção do estado do Rio de Janeiro (Pougy et al., 2018).'
               # (Pougy et al., 2018)
               {
                 references <- references %>% dplyr::add_row()
                 nlref <- NROW(references)
                 
                 references[nlref,]$Reference_type <- 'Assessment'
                 references[nlref,]$author <- 'Pougy, N., Martins, E., Verdi, M., Fernandez, E., Loyola, R., Silveira-Filho, T.B., Martinelli, G. (Orgs.)' 
                 references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
                 references[nlref,]$pages <- 80
                 references[nlref,]$place_published <- 'Rio de Janeiro'
                 references[nlref,]$publisher <- 'Andrea Jakobsson Estúdio'
                 references[nlref,]$secondary_author <- 'Secretaria de Estado do Ambiente (SEA)'
                 references[nlref,]$submission_type <- 'Published'
                 references[nlref,]$title <- 'Plano de Ação Nacional para a conservação da flora endêmica ameaçada de extinção do estado do Rio de Janeiro'
                 references[nlref,]$type <- 'report'
                 # references[nlref,]$url <- NA
                 references[nlref,]$year <- 2018
               }
             }
             
             
             # Serra do Espinhaço Meridional
             if(any(pan_publicados$PAN %in% "Plano de Ação Nacional para a conservação da flora ameaçada de extinção da Serra do Espinhaço Meridional")==T)
             {
               texto_pans_para_texto_ucs <- paste0(texto_pans_para_texto_ucs, ifelse(length(texto_pans_para_texto_ucs)==0,""," "),
                                                   'A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora ameaçada de extinção da Serra do Espinhaço Meridional (Pougy et al., 2015).')
               # (Pougy et al., 2015)
               {
                 references <- references %>% dplyr::add_row()
                 nlref <- NROW(references)
                 
                 references[nlref,]$Reference_type <- 'Assessment'
                 references[nlref,]$author <- 'Pougy, N., Verdi, M., Martins, E., Loyola, R., Martinelli, G. (Orgs.)' 
                 references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
                 references[nlref,]$pages <- 100
                 references[nlref,]$place_published <- 'Rio de Janeiro'
                 references[nlref,]$publisher <- 'Andrea Jakobsson Estúdio'
                 references[nlref,]$secondary_author <- 'CNCFlora: Jardim Botânico do Rio de Janeiro'
                 references[nlref,]$submission_type <- 'Published'
                 references[nlref,]$title <- 'Plano de Ação Nacional para a conservação da flora ameaçada de extinção da Serra do Espinhaço Meridional.'
                 references[nlref,]$type <- 'report'
                 # references[nlref,]$url <- NA
                 references[nlref,]$year <- 2015
               }
             }
             
             
             #  Grão Mogol - Francisco Sá
             if(any(pan_publicados$PAN %in% "Plano de Ação Nacional para a conservação da flora ameaçada de extinção da região de Grão Mogol - Francisco Sá")==T)
             {
               texto_pans_para_texto_ucs <- paste0(texto_pans_para_texto_ucs, ifelse(length(texto_pans_para_texto_ucs)==0,""," "), 
                                                   'A espécie ocorre no território de abrangência do Plano de Ação Nacional para a conservação da flora ameaçada de extinção da região de Grão Mogol - Francisco Sá (Pougy et al., 2015)')
               # (Pougy et al., 2018)
               {
                 references <- references %>% dplyr::add_row()
                 nlref <- NROW(references)
                 
                 references[nlref,]$Reference_type <- 'Assessment'
                 references[nlref,]$author <- 'Pougy, N., Martins, E., Verdi, M., Maurenza, D., Loyola, R., Martinelli, G. (Orgs.)' 
                 references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
                 references[nlref,]$pages <- 76
                 references[nlref,]$place_published <- 'Rio de Janeiro'
                 references[nlref,]$publisher <- 'Andrea Jakobsson Estúdio'
                 references[nlref,]$secondary_author <- 'CNCFlora: Jardim Botânico do Rio de Janeiro'
                 references[nlref,]$submission_type <- 'Published'
                 references[nlref,]$title <- 'Plano de Ação Nacional para a Conservação da Flora Ameaçada de Extinção da Região de Grão Mogol - Francisco Sá.'
                 references[nlref,]$type <- 'report'
                 # references[nlref,]$url <- NA
                 references[nlref,]$year <- 2015
               }
             }
             
           
             #  Ecossistemas das lagoas da planície costeira do sul do Brasil
             if(any(pan_publicados$PAN %in% "Plano de Ação Nacional Lagoas do Sul")==T)
             {
               texto_pans_para_texto_ucs <- paste0(texto_pans_para_texto_ucs, ifelse(length(texto_pans_para_texto_ucs)==0,""," "), 
                                                   'A espécie ocorre no território de abrangência do Plano de Ação Nacional Lagoas do Sul para a conservação da flora melhorar o estado de conservação das espécies ameaçadas e dos ecossistemas das lagoas da planície costeira do sul do Brasil (ICMBio, 2018).')
               # (Pougy et al., 2018)
               {
                 references <- references %>% dplyr::add_row()
                 nlref <- NROW(references)
                 
                 references[nlref,]$Reference_type <- 'Assessment'
                 references[nlref,]$author <- 'ICMBio - Instituto Chico Mendes de Conservação da Biodiversidade' 
                 references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
                 references[nlref,]$pages <- 54
                 # references[nlref,]$place_published <- 'Brasilia'
                 references[nlref,]$publisher <- 'Diário Oficial da União, 29/08/2018'
                 # references[nlref,]$secondary_author <- 'CNCFlora: Jardim Botânico do Rio de Janeiro'
                 references[nlref,]$secondary_title <- 'Edição 167, Seção 1'
                 references[nlref,]$submission_type <- 'Published'
                 references[nlref,]$title <- 'Portaria nº 751, de 27 de agosto de 2018'
                 references[nlref,]$type <- 'report'
                 references[nlref,]$url <- 'https://www.gov.br/icmbio/pt-br/assuntos/biodiversidade/pan/pan-lagoas-do-sul/1-ciclo/pan-lagoas-do-sul-portaria-aprovacao.pdf'
                 references[nlref,]$year <- 2018
               }
               
               
             }
             
           
         # UCs
         if(UCs_n > 0)
         {
           if(UCs_n==1)
           {
             UCs_texto <- paste0(texto_pans_para_texto_ucs, 'A espécie foi registrada na Unidade de Conservação: ',
                                 stringi::stri_replace_last(paste(UCs, collapse = ', '), fixed = ",", " e"))
             
           }else{
             UCs_texto <- paste0(texto_pans_para_texto_ucs, 'A espécie foi registrada nas seguintes Unidades de Conservação: ',
                                 stringi::stri_replace_last(paste(UCs, collapse = ', '), fixed = ",", " e"))
           }
         }else
         {
           UCs_texto<- paste0(texto_pats_para_texto_ucs, "Que não é registrada em Unidades de Conservação")
         }
         
         
         assessments[nla,]$ConservationActionsDocumentation.narrative <-  UCs_texto
       }
       
       # HabitatDocumentation.narrative # Árvore com até 12 m de altura. Ocorre na Mata Atlântica, em Floresta Ombrófila (Sothers e Prance, 2020).
       # # texto padrão do habito + biomas + tipos de vegetação
       {
         ENDEMICA_BRASIL <- avaliacao[avaliacao$tag == 'endemism_FB2020',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         index <- spp$scientificName_FB2020 == sp_selected
         HABITO <- spp$lifeForm_FB2020[index==TRUE]
         
         BIOMAS <- biomas$Biome %>% as.character()
         BIOMAS_n<- NROW(biomas)
         
         {
           VEGETACOES <- avaliacao[avaliacao$tag == 'TiposVegetacaoFB2020_IUCN',] %>%
             dplyr::filter(valueLogical==TRUE) %>%
             dplyr::select(valueText) %>%
             dplyr::distinct_all()
           
           VEGETACOES <- VEGETACOES$valueText
         }
         
         VEGETACOES<-sub("Floresta Ombrófila \\(= Floresta Pluvial\\)", "floresta ombrófila densa", VEGETACOES) #
         VEGETACOES<-sub("Floresta Ombrófila (= Floresta Pluvial)", "floresta ombrófila densa", VEGETACOES) #
         {# VEGETACOES<-sub("Área Antrópica", "área antrópica", VEGETACOES) #
           # VEGETACOES<-sub("Caatinga (stricto sensu)", "caatinga (stricto sensu)", VEGETACOES) #
           # VEGETACOES<-sub("Campinarana", "campinarana", VEGETACOES) #
           # VEGETACOES<-sub("Campo de Altitude", "campos de altitude", VEGETACOES)#
           # VEGETACOES<-sub("Campo de Várzea", "campos de várzea", VEGETACOES)#
           # VEGETACOES<-sub("Campo Limpo", "campo limpo", VEGETACOES)#
           # VEGETACOES<-sub("Campo Rupestre|Campo Rupestre", "campos rupestres", VEGETACOES)#
           # VEGETACOES<-sub("Carrasco", "carrasco", VEGETACOES)#
           # VEGETACOES<-sub("Cerrado (lato sensu)", "cerrado (lato sensu)", VEGETACOES)#
           # VEGETACOES<-sub("Floresta Ciliar ou Galeria", "floresta ciliar e/ou galeria", VEGETACOES)#
           # VEGETACOES<-sub("Floresta de Igapó", "floresta de igapó", VEGETACOES) #
           # VEGETACOES<-sub("Floresta de Terra Firme", "floresta de terra-firme", VEGETACOES)#
           # VEGETACOES<-sub("Floresta de Várzea", "floresta de várzea", VEGETACOES) #
           # VEGETACOES<-sub("Floresta Estacional Decidual", "floresta estacional decidual", VEGETACOES) #
           # VEGETACOES<-sub("Floresta Estacional Perenifólia", "floresta estacional perenifólia", VEGETACOES) #
           # VEGETACOES<-sub("Floresta Estacional Semidecidual", "floresta estacional semidecidual", VEGETACOES) #
           
           # VEGETACOES<-sub("Floresta Ombrófila Mista", "floresta ombrófila mista", VEGETACOES)#
           # VEGETACOES<-sub("Manguezal", "manguezal", VEGETACOES)
           # VEGETACOES<-sub("Palmeiral", "palmeiral", VEGETACOES)#
           # VEGETACOES<-sub("Restinga", "restinga", VEGETACOES) #
           # VEGETACOES<-sub("Savana Amazônica", "savana amazônica", VEGETACOES) #
           # VEGETACOES<-sub("Vegetação Aquática", "vegetação aquática", VEGETACOES)#
           # VEGETACOES<-sub("Vegetação Sobre Afloramentos Rochosos", "vegetação sobre afloramentos rochosos", VEGETACOES) #
         }
         
         VEGETACOES <- tolower(VEGETACOES)
         
         habitat_texto <- paste0(HABITO, "; ",
                                 "com ocorrência",
                                 if(BIOMAS_n > 1){
                                   " nos biomas "
                                 } else{
                                   " no bioma "
                                 },
                                 
                                 stringi::stri_replace_last(paste(BIOMAS, collapse = ', '), fixed = ",", " e"),
                                 
                                 ", em ",
                                 stringi::stri_replace_last(paste(VEGETACOES, collapse = ', '), fixed = ",", " e"),
                                 
                                 
                                 ifelse(ENDEMICA_BRASIL==TRUE, "; endêmica do Brasil, com distribuição ",
                                        "; com distribuição fora do Brasil, inclusive no Brasil"))
         
         assessments[nla,]$HabitatDocumentation.narrative <- habitat_texto
       }
       
       
       # MapStatus.status # Done - Incomplete
       # Done (para todos, incluir as fora do BR)
       {
         assessments[nla,]$MapStatus.status <- 'Done'
       }
       
       # PopulationDocumentation.narrative # Não existem dados populacionais. - Em estudo realizado por Azevedo et al. (2008), foram identificadas 15 árvores em uma área de 500 ha da Companhia Florestal Monte Dourado (Jari), na localidade Morro do Felipe, Vitória do Jari (AP).
       # # para LC - Não existem dados populacionais (pegar o flag)
       {
         {
           DADOS_POPULACIONAIS <- avaliacao[avaliacao$tag == 'no_population_data',] %>%
             dplyr::select(valueLogical) %>% as.logical()
         }
         
         assessments[nla,]$PopulationDocumentation.narrative <- ifelse(DADOS_POPULACIONAIS==FALSE, "Com dados populacionais disponíveis...",
                                                                       "Não existem dados populacionais.")
       }
       
       # PopulationTrend.value # Unknown
       # # Unknown
       { 
         assessments[nla,]$PopulationTrend.value <- 'Unknown'
       }
       
       
       # RangeDocumentation.narrative # Espécie endêmica do Brasil (Sothers e Prance, 2020), com distribuição: no estado da Bahia — nos municípios Arataca, Camacan, Ilhéus e Wenceslau Guimarães —, no estado do Espírito Santo — no município Linhares —, no estado de Minas Gerais — nos municípios Caratinga, Itambé do Mato Dentro e Januária —, no estado do Rio de Janeiro — nos municípios Angra dos Reis, Paraty, Rio de Janeiro e Santa Maria Madalena —, e no estado de São Paulo — no município Ubatuba.
       # # Endemismo + UFs + municipios
       {
         ENDEMICA_BRASIL <- avaliacao[avaliacao$tag == 'endemism_FB2020',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         DISTGEO_ES <- sqldf::sqldf("SELECT DISTINCT stateProvince_check,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in
                           WHERE emUso = TRUE AND stateProvince_check != ''
                           GROUP BY stateProvince_check
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") %>%
           dplyr::select(stateProvince_check)
         DISTGEO_ES <- DISTGEO_ES$stateProvince_check
         
         DISTGEO_ES<-sub("AC", "Acre",DISTGEO_ES)
         DISTGEO_ES<-sub("AL","Alagoas",DISTGEO_ES)
         DISTGEO_ES<-sub("AP","Amapá",DISTGEO_ES)
         DISTGEO_ES<-sub("AM","Amazonas",DISTGEO_ES)
         DISTGEO_ES<-sub("BA","Bahia",DISTGEO_ES)
         DISTGEO_ES<-sub("CE","Ceará",DISTGEO_ES)
         DISTGEO_ES<-sub("DF","Distrito Federal",DISTGEO_ES)
         DISTGEO_ES<-sub("ES","Espírito Santo",DISTGEO_ES)
         DISTGEO_ES<-sub("GO","Goiás",DISTGEO_ES)
         DISTGEO_ES<-sub("MA","Maranhão",DISTGEO_ES)
         DISTGEO_ES<-sub("MS","Mato Grosso do Sul",DISTGEO_ES)
         DISTGEO_ES<-sub("MT","Mato Grosso",DISTGEO_ES)
         DISTGEO_ES<-sub("MG","Minas Gerais",DISTGEO_ES)
         DISTGEO_ES<-sub("PA","Pará",DISTGEO_ES)
         DISTGEO_ES<-sub("PB","Paraíba",DISTGEO_ES)
         DISTGEO_ES<-sub("PR","Paraná",DISTGEO_ES)
         DISTGEO_ES<-sub("PE","Pernambuco",DISTGEO_ES)
         DISTGEO_ES<-sub("PI","Piauí",DISTGEO_ES)
         DISTGEO_ES<-sub("RJ","Rio de Janeiro",DISTGEO_ES)
         DISTGEO_ES<-sub("RN","Rio Grande do Norte",DISTGEO_ES)
         DISTGEO_ES<-sub("RS","Rio Grande do Sul",DISTGEO_ES)
         DISTGEO_ES<-sub("RO","Rondônia",DISTGEO_ES)
         DISTGEO_ES<-sub("RR","Roraima",DISTGEO_ES)
         DISTGEO_ES<-sub("SC","Santa Catarina",DISTGEO_ES)
         DISTGEO_ES<-sub("SP","São Paulo",DISTGEO_ES)
         DISTGEO_ES<-sub("SE","Sergipe",DISTGEO_ES)
         DISTGEO_ES<-sub("TO","Tocantins",DISTGEO_ES)
         
         DISTGEO_ES_n <- NROW(DISTGEO_ES)
         
         DISTGEO <- sqldf::sqldf("SELECT DISTINCT municipality_stateProvince_check,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in
                           WHERE emUso = TRUE AND municipality_stateProvince_check != ''
                           GROUP BY municipality_stateProvince_check
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") %>%
           dplyr::select(municipality_stateProvince_check)
         
         DISTGEO_n <- NROW(DISTGEO)
         DISTGEO <- DISTGEO$municipality_stateProvince_check
         
         
         rangeDocumentation_texto <- paste0(ifelse(ENDEMICA_BRASIL==TRUE, "Espécie endêmica do Brasil, com distribuição ",
                                                   "Espécie com distribuição fora do Brasil, inclusive no Brasil, onde é registrada "), 
                                            
                                            paste0(
                                              if(DISTGEO_n > 8){
                                                if(DISTGEO_ES_n > 6){
                                                  "em diversos Estados"
                                                } else{
                                                  paste0("em diversos municípios dos Estados ",
                                                         stringi::stri_replace_last(paste(DISTGEO_ES, collapse = ', '), fixed = ",", " e")
                                                  )
                                                }
                                              } else{
                                                if(DISTGEO_n<=1){
                                                  paste0("no município ",
                                                         DISTGEO)
                                                } else{
                                                  paste0("nos municípios ",
                                                         stringi::stri_replace_last(paste(DISTGEO, collapse = ', '), fixed = ",", " e")
                                                  )
                                                }
                                              }
                                            ))
         
         assessments[nla,]$RangeDocumentation.narrative <- rangeDocumentation_texto
         
       }
       
       # RedListAssessmentDate.value # 19/10/21
       # # data do ultimo salvamento (formaro 19/10/2021)
       {
         assessments[nla,]$RedListAssessmentDate.value <- data_avaliacao
       }
       
       # RedListCriteria.critVersion # 3.1
       # # 3.1
       {
         assessments[nla,]$RedListCriteria.critVersion <- 3.1
       }  
       
       # RedListCriteria.dataDeficientReason # só se for DD - Taxonomic ou Provenance
       # # para lc não precisa
       {
         assessments[nla,]$RedListCriteria.dataDeficientReason <- ''
       }  
       
       # RedListCriteria.isManual # TRUE
       # # TRUE
       {
         assessments[nla,]$RedListCriteria.isManual <- 'TRUE'
       }
       
       # RedListCriteria.manualCategory # DD LC CR EN VU
       # # categoria LC
       {
         
         categoria_LC <- avaliacao[avaliacao$tag == 'categoria_LC',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         possivelmente_dd <- avaliacao[avaliacao$tag == 'possivelmente_dd',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         avaliacao_fluxo_integral <- avaliacao[avaliacao$tag == 'avaliacao_fluxo_integral',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         
         possivelmente_ameacada <- avaliacao[avaliacao$tag == 'possivelmente_ameacada',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         
         categoria <- ifelse(categoria_LC == TRUE,'LC', 
                             ifelse(possivelmente_dd == TRUE,'DD', 
                                    ifelse(avaliacao_fluxo_integral==TRUE |
                                             possivelmente_ameacada==TRUE,'Fluxo Integral','')))
         
         assessments[nla,]$RedListCriteria.manualCategory <- categoria
         
       }
       
       # RedListCriteria.manualCriteria
       # # vazio
       {
         assessments[nla,]$RedListCriteria.manualCriteria <- ''
       }
       
       # RedListCriteria.manualCriteriaString # B1ab(i,ii,iii,iv)+2ab(i,ii,iii,iv)
       # # vazio para LC
       {
         
         criterio <- ''
         
         assessments[nla,]$RedListCriteria.manualCriteriaString <- ifelse(categoria=='LC','',criterio)
       }
       
       # RedListCriteria.possiblyExtinct # FALSE
       # # FALSE
       {
         assessments[nla,]$RedListCriteria.possiblyExtinct <- 'FALSE'
       }  
       
       # RedListRationale.value # Couepia monteclarensis é uma árvore que ocorre em diferentes fitofisionomias de Floresta Ombrófila, na Mata Atlântica. Apresenta extenso EOO= 388011km², mais de 10 situações de ameaças e, ocorrência confirmada dentro dos limites de Unidades de Conservação de proteção integral. Adicionalmente, não existem dados sobre tendências populacionais que atestem para potenciais reduções no número de indivíduos maduros, além de não serem descritos usos potenciais ou efetivos que comprometam sua perpetuação na natureza. Assim, foi considerada como de Menor Preocupação (LC), demandando ações de pesquisa (distribuição, tendências e números populacionais) a fim de se ampliar o conhecimento disponível e garantir sua sobrevivência na natureza.
       # # texto da avaliação
       {  
         assessments[nla,]$RedListRationale.value <- texto_avaliacao
       }
       
       # RedListReasonsForChange.type # Nongenuine Change
       # # Se for reavaliação - Nudança genuína, Não genuína, sem mudança
       # # se for uma reavaliação (vazio)
       {
         
         # para verificar se é reavaliação
         # spp$ultima_catagoria_cnflora
         
         assessments[nla,]$RedListReasonsForChange.type <- 'Nongenuine Change'
         
       }  
       
       # RedListReasonsForChange.changeReasons # New Information - Criteria Revision
       # # se RedListReasonsForChange.type == Nongenuine Change 'New Information'
       {
         assessments[nla,]$RedListReasonsForChange.changeReasons <- ifelse(assessments[i,]$RedListReasonsForChange.type == 'Nongenuine Change', 'New Information', 'Criteria Revision')
       }
       
       # System.value # Terrestrial
       # # Terrestrial
       {
         assessments[nla,]$System.value <- 'Terrestrial' 
       }  
       
       # ThreatsDocumentation.value # Não foram documentadas ameaças que atestem declínios para a espécie. - De acordo com o Atlas das Pastagens Brasileiras, o município Sena Madureira (AC) possui 6,62% (157192ha) do seu território convertido em áreas de pastagem, segundo dados de 2019 (Lapig, 2021). De acordo com o MapBiomas, os municípios Sena Madureira (AC) e Tarauacá (AC) possuem, respectivamente, 7,04% (167147ha) e 5,06% (102160ha) de seus territórios convertidos em áreas de pastagens, segundo dados de 2019 (MapBiomas, 2021a). Em 2014, a espécie apresentava 10,35% (165,59ha) da sua AOO útil (1600ha) em áreas de pastagem, enquanto em 2019, a espécie apresentava 12,1% (193,61ha), o que representou um acréscimo de 1,75% (28,03ha) em áreas de pastagem (MapBiomas, 2021b).Um total de 7,76% (1,24km²) da AOO útil da espécie queimaram em 2019 [Formação Florestal (6,05%), Pastagem (1,71%)] (MapBiomas-Fogo, 2021).
       # # fraze padrão o texto
       {
         assessments[nla,]$ThreatsDocumentation.value <- 'Não foram documentadas ameaças que atestem declínios para a espécie.'
       }
       
       # UseTradeDocumentation.value # Não existem dados sobre usos efetivos ou potenciais. - Croton sphaerogynus Baill. por emergir no mesmo clado que C. cajucara, torna-se promissora na prospecção de substâncias bioativas.C. sphaerogynus se caracterizou como uma espécie produtora exclusivamente de flavonóis, além de ser grande produtora de diterpenos. Dois flavonoides foram isolados, quercetina 3,7-dimetil éter e campferol 3-metil éter. Quanto às atividades biológicas, a subfração composta majoritariamente por quercetina 3,7-dimetil éter apresentou alto potencial antioxidante e a maior atividade anti-HIV-1 entre os extratos e outras subfrações testadas. A fração hexânica, rica em diterpenos, foi a que apresentou atividade antimicrobiana promissora. Dessa forma, C. spherogynus torna-se uma espécie promissora para o uso de substâncias antioxidantes (Santos, 2014).
       # # fraze padrão o texto
       {
         
         no_use <- avaliacao[avaliacao$tag == 'no_use',] %>%
           dplyr::select(valueLogical) %>% as.logical()
         
         description_use <- avaliacao[avaliacao$tag == 'description_use',] %>%
           dplyr::select(valueText) %>% as.character()
         
         
         assessments[nla,]$UseTradeDocumentation.value <- ifelse(no_use==TRUE,'Não existem dados sobre usos efetivos ou potenciais.',
                                                                 description_use)
         
         
       }
       
       # language.value # Portuguese
       # # Portuguese
       {
         assessments[nla,]$language.value <- 'Portuguese'
       }
       
       # internal_taxon_id 
       # # genero_epiteto
       {
         assessments[nla,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
         
         # paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2)) == paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
     }
     
     
     # maps
     {
       
       io<-1
       print(paste0('maps: ', NROW(occ_global)))
       print('countries')
       print('occurrence')
       
       if (NROW(occ_global)>0)
       {
         for (io in 1:NROW(occ_global))
           # for (io in 1:1)
         {
           # print(paste0(io))
           
           # maps
           {
             # Arquivo: maps.csv.
             # Campos:
             # 'Binomial', OK 
             # 'Presence', OK
             # 'Origin', OK
             # 'Seasonal', OK
             # 'Compiler', OK
             # 'Year', OK
             # 'Citation', OK
             # 'Dec_Lat', OK
             # 'Dec_Long', OK
             # 'SpatialRef', OK
             # 'BasisOfRec', OK
             # 'Event_Year', OK
             # 'Source', OK
             # 'Dist_comm', OK
             # 'collectID', OK
             # 'recordNo', OK
             # 'recordedBy', OK
             # 'day', OK
             # 'month', OK
             # 'countryCode' OK
             
             maps <- maps %>% dplyr::add_row()
             nl <- NROW(maps)
             
             maps[nl,]$Binomial	<- paste0(word(sp_selected,1), ' ',word(sp_selected,2)) 
             maps[nl,]$Presence	<- 1
             maps[nl,]$Origin	<- 1
             maps[nl,]$Seasonal <- 1
             maps[nl,]$Compiler	<- 'CNCFlora/JBRJ'
             maps[nl,]$Year <- 2022
             maps[nl,]$Citation	<- 'BP-RLA/CNCFlora/JBRJ'
             maps[nl,]$Dec_Lat <- occ_global$Latitude[io] %>% as.character()
             maps[nl,]$Dec_Long <- occ_global$Longitude[io]  %>% as.character()
             maps[nl,]$SpatialRef <- 'WGS84'
             maps[nl,]$BasisOfRec	<- 'PreservedSpecimen'
             maps[nl,]$Event_Year	<- occ_global$Ctrl_year[io] %>% as.numeric()
             maps[nl,]$Source	<- paste0(occ_global$Ctrl_recordedBy[io], ' ', occ_global$Ctrl_recordNumber[io])
             maps[nl,]$Dist_comm	<- paste0(occ_global$Ctrl_stateProvince[io], ' ', occ_global$Ctrl_municipality[io], ' ', occ_global$Ctrl_locality[io]) #UF + municipio + tipovegetação
             # Island	
             # Subspecies	
             # Subpop	
             # Tax_comm	
             maps[nl,]$Data_Sens	<- 'N'
             maps[nl,]$Sens_Comm	<- 'N'
             # ID_No	
             maps[nl,]$collectID <- occ_global$Ctrl_catalogNumber[io] %>% as.character()
             maps[nl,]$recordNo	<- occ_global$Ctrl_recordNumber[io] %>% as.character()
             maps[nl,]$recordedBy	<- occ_global$Ctrl_recordedBy[io] %>% as.character()#coletor
             maps[nl,]$day <- occ_global$Ctrl_day[io]  %>% as.numeric() #	dia coleta
             maps[nl,]$month	<- occ_global$Ctrl_month[io]  %>% as.numeric()# mes coleta
             maps[nl,]$countryCode	<- occ_global$countryCode_ISO3[io] #'BRA' # , codigo pais 3 caracteres
             maps[nl,]$locality	<- occ_global$Ctrl_locality[io] #localidade
             # minElev	
             # maxElev	
             # verbaElev
             # verbatLat
             # verbatLong
             # verbatCoord
             # verbatSRS
             # coordUncert
             # georefVeri
             # georefVeri
             # identCert
             # typeStatus
             # subgenus
             maps[nl,]$obsYrQual <- 1
             maps[nl,]$obsCompNot <- 'GC'
             # adminError	
             # adminFixed
             # adminSrcFix
             # adminChang
             maps[nl,]$id <- paste0(paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2)), ':',io) # internal_taxon_id + numero de 1 ao n de registeos
           }
           
           # occurrence
           {
             occurrence <- occurrence %>% dplyr::add_row()
             nlo <- NROW(occurrence)
             
             # occurrence[nlo,]$modified	
             # occurrence[nlo,]$institutionCode
             occurrence[nlo,]$collectionCode <- occ_global$Ctrl_collectionCode[io]
             occurrence[nlo,]$catalogNumber <- occ_global$Ctrl_catalogNumber[io] %>% as.character()
             occurrence[nlo,]$scientificName <- occ_global$Ctrl_scientificName[io]
             # occurrence[nlo,]$identificationQualifier
             occurrence[nlo,]$family <- occ_global$Ctrl_family[io]
             occurrence[nlo,]$genus <- occ_global$Ctrl_genus[io]
             occurrence[nlo,]$specificEpithet <- occ_global$Ctrl_specificEpithet[io]
             # occurrence[nlo,]$infraspecificEpithet
             occurrence[nlo,]$scientificNameAuthorship <- occ_global$Ctrl_scientificNameAuthorship[io]
             occurrence[nlo,]$identifiedBy <- occ_global$Ctrl_identifiedBy[io]
             occurrence[nlo,]$dateIdentified <- ifelse(occ_global$Ctrl_dateIdentified[io]=='NA','',occ_global$Ctrl_dateIdentified[io] %>% as.character())
             occurrence[nlo,]$typeStatus <- occ_global$Ctrl_typeStatus[io]
             occurrence[nlo,]$recordNumber <- occ_global$Ctrl_recordNumber[io] %>% as.character()
             # occurrence[nlo,]$fieldNumber
             occurrence[nlo,]$recordedBy <- occ_global$Ctrl_recordedBy[io]
             occurrence[nlo,]$year <- occ_global$Ctrl_year[io] %>% as.numeric()
             occurrence[nlo,]$month <- occ_global$Ctrl_month[io] %>% as.numeric()
             occurrence[nlo,]$day <- occ_global$Ctrl_day[io] %>% as.numeric()
             occurrence[nlo,]$country <- ifelse(is.na(occ_global$CountryOccurrenceName[io]),occ_global$Ctrl_country[io],occ_global$CountryOccurrenceName[io])
             occurrence[nlo,]$stateProvince <- occ_global$Ctrl_stateProvince_standardized_check[io] #occ_global$Ctrl_stateProvince_standardized[io]
             occurrence[nlo,]$municipality <- occ_global$municipality_check[io]
             occurrence[nlo,]$locality <- occ_global$Ctrl_locality[io]
             occurrence[nlo,]$decimalLatitude <- occ_global$Latitude[io]
             occurrence[nlo,]$decimalLongitude <- occ_global$Longitude[io]
             occurrence[nlo,]$occurrenceRemarks <- occ_global$Ctrl_occurrenceRemarks[io]
             occurrence[nlo,]$acceptedNameUsage <- sp_selected
             # occurrenceID
             occurrence[nlo,]$comments <- occ_global$Ctrl_comments[io]
             occurrence[nlo,]$bibliographicCitation<- occ_global$Ctrl_bibliographicCitation[io]
           }
           
           # countries.csv OK
           {

             # Campos:
             # 'CountryOccurrence.CountryOccurrenceSubfield.CountryOccurrenceLookup', OK
             # 'CountryOccurrence.CountryOccurrenceSubfield.CountryOccurrenceName', OK
             # 'CountryOccurrence.CountryOccurrenceSubfield.origin', OK
             # 'CountryOccurrence.CountryOccurrenceSubfield.presence', OK
             # 'internal_taxon_id' OK
             
             countries <- countries %>% dplyr::add_row()
             nlcou <- NROW(countries)
             
             countries[nlcou, ]$CountryOccurrence.CountryOccurrenceSubfield.CountryOccurrenceLookup <- occ_global$countryCode[io] # BR - CO
             
             countries[nlcou, ]$CountryOccurrence.CountryOccurrenceSubfield.CountryOccurrenceName <- occ_global$CountryOccurrenceName[io] # Brazil - Colombia - Peru
             
             countries[nlcou, ]$CountryOccurrence.CountryOccurrenceSubfield.origin <- 'Native'
             
             countries[nlcou, ]$CountryOccurrence.CountryOccurrenceSubfield.presence <- 'Extant'
             
             countries[nlcou, ]$CountryOccurrence.CountryOccurrenceSubfield.seasonality <- 'Resident'
             
             countries[nlcou, ]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
           }
         }
       }
     }
     
     
     # allfields.csv
     {
       # Arquivo: allfields.csv.
       # Campos:         
       # 'internal_taxon_id', OK
       
       print('allfields')
       
       allfields <- allfields %>% dplyr::add_row()
       nlaf <- NROW(allfields)
       
       allfields[nlaf,]$AOO.range <- avaliacao[avaliacao$tag == 'aoo',] %>%
         dplyr::select(valueNumeric) %>% as.numeric()
       # aoo
       
       # AOOContinuingDecline.isInContinuingDecline # YES - NO
       # # NO
       allfields[nlaf,]$AOOContinuingDecline.isInContinuingDecline <- 'NO'
       
       # AOOContinuingDecline.qualifier # Inferred
       # # vazio
       allfields[nlaf,]$AOOContinuingDecline.qualifier <- ''
       
       # EOO.range	
       # # eoo
       allfields[nlaf,]$EOO.range	<- avaliacao[avaliacao$tag == 'eoo',] %>%
         dplyr::select(valueNumeric) %>% as.numeric()
       
       # EOOContinuingDecline.isContinuingDecline # YES - NO
       # # no
       allfields[nlaf,]$EOOContinuingDecline.isContinuingDecline <- 'NO'
       
       # EOOContinuingDecline.qualifier # Inferred
       # # vazio
       allfields[nlaf,]$EOOContinuingDecline.qualifier <- ''
       
       # HabitatContinuingDecline.isDeclining # YES - NO
       # # no
       allfields[nlaf,]$HabitatContinuingDecline.isDeclining <- 'NO'
       
       # HabitatContinuingDecline.qualifier # Inferred
       # # vazio
       allfields[nlaf,]$HabitatContinuingDecline.qualifier <- ''
       
       # LocationContinuingDecline.inDecline # YES - NO
       # # no
       allfields[nlaf,]$LocationContinuingDecline.inDecline <- 'NO'
       
       # LocationsNumber.range
       # # situaões de ameaça buffer 20 km
       allfields[nlaf,]$LocationsNumber.range <- avaliacao[avaliacao$tag == 'locations_distance',] %>%
         dplyr::select(valueNumeric) %>% as.numeric()
       
       # NoThreats.noThreats # TRUE - FALSE
       # # TRUE
       allfields[nlaf,]$NoThreats.noThreats <- 'TRUE'
       
       # PopulationContinuingDecline.isDeclining # YES - NO
       # # NO
       allfields[nlaf,]$PopulationContinuingDecline.isDeclining <- 'NO'
       
       # PopulationContinuingDecline.qualifier # Inferred - Suspected
       # # vazio para PopulationContinuingDecline.isDeclining == NO
       allfields[nlaf,]$PopulationContinuingDecline.qualifier <- ifelse(allfields[i,]$PopulationContinuingDecline.isDeclining == 'NO',
                                                                        '', '')
       
       # ThreatsUnknown.value # TRUE
       # # TRUE
       allfields[nlaf,]$ThreatsUnknown.value <- 'TRUE'
       
       # internal_taxon_id
       # # genero_epiteto
       allfields[nlaf,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       
     }
     
     
     # commonnames.csv
     {
       print('commonnames')
       
       # Arquivo: commonnames.csv.
       # Campos:
       # 'internal_taxon_id', OK
       # 'language', OK
       # 'name', OK
       
       # 418
       # i=418
       # i=545
       vernacular_names <- str_split(spp$vernacular_names[i], '/', simplify = T)
       
       vernacular_names <- str_split(vernacular_names, ',', simplify = T)[,1] %>% na.omit()
       vernacular_names <- vernacular_names[vernacular_names != 'NA']
       
       vernacular_names <- vernacular_names %>% unique()
       # if(!is.na(vernacular_names))
       
       if(length(vernacular_names)>0)
       {
         if (vernacular_names[1]!='')
         {       
           for (iv in 1:length(vernacular_names))
           {
             commonnames <- commonnames %>% dplyr::add_row()
             nlvn <- NROW(commonnames)
             
             # internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',binomio)
             # language # Portuguese
             # name # milho-torrado-amarelo
             # primary # TRUE (SE FALSE VAZIO)
             # # cada nome popular é uma linha e na primeira linha de cada id primary == TRUE
             # # language Portuguese
             
             commonnames[nlvn,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
             commonnames[nlvn,]$language <- 'Portuguese'
             commonnames[nlvn,]$name <- vernacular_names[iv]
             commonnames[nlvn,]$primary <- ifelse(iv==1,'TRUE','FALSE')
           }
         }       
       }
       
     }
     
     # 22-08-22
     # shapes dos PATS
     # conservationneeded.csv - depende dos dados de PAT - CSV sem informação
     {
       print('conservationneeded')
       # Campos:
       #   'internal_taxon_id'

       # ConservationActions.ConservationActionsSubfield.ConservationActionsLookup # 5.1.2
       # # 5.1.2 se em PAT
       # 
       # ConservationActions.ConservationActionsSubfield.ConservationActionsName # National level - Site/area protection
       # 
       # ConservationActions.ConservationActionsSubfield.note # A espécie ocorre em territórios que poderão ser contemplados por Planos de Ação Nacional (PAN) Territorial, no âmbito do projeto GEF Pró-Espécies - Todos Contra a Extinção: Território Vale do Paraíba - 30 (RJ), Território Rio de Janeiro - 32 (RJ), Território PAT Capixaba-Gerais - 33 (ES), Território Itororó - 35 (BA), Território PAT Espinhaço Mineiro - 10 (MG).
       # 
       # internal_taxon_id
       
       
       # se não ocorre em UC
       
       if(UCs_n == 0)
       {
         ConservationActionsLookup <- '1.1'
         ConservationActionsName <- 'Site/area protection'
         texto_pats <- 'A espécie não é conhecida em nenhuma unidade de conservação, mas claramente existe a necessidade de melhorar a proteção do habitat nos locais onde se sabe que ela ocorre. São necessárias pesquisas adicionais para determinar se esta espécie está ou não experimentando um declínio efetivo ou está passando por flutuações naturais da população.'
         
         conservationneeded <- conservationneeded %>% dplyr::add_row()
         nlca <- NROW(conservationneeded)
         
         conservationneeded[nlca,]$ConservationActions.ConservationActionsSubfield.ConservationActionsLookup <- ConservationActionsLookup
         conservationneeded[nlca,]$ConservationActions.ConservationActionsSubfield.ConservationActionsName <- ConservationActionsName
         conservationneeded[nlca,]$ConservationActions.ConservationActionsSubfield.note <- texto_pats
         conservationneeded[nlca,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
         
      }
       
       if(NROW(x_pats)>0)
       {
         ConservationActionsLookup <- '5.1.2'
         ConservationActionsName <- 'National level'
         texto_pats <- paste0("A espécie ocorre em territórios que poderão ser contemplados por Planos de Ação Nacional (PAN) Territorial, no âmbito do projeto GEF Pró-Espécies - Todos Contra a Extinção: ",
                              stringi::stri_replace_last(paste(paste0(x_pats$nome, ' - ', x_pats$codigo,' (',x_pats$info_UF,')'), collapse = ', '), fixed = ",", " e"),'.')

         conservationneeded <- conservationneeded %>% dplyr::add_row()
         nlca <- NROW(conservationneeded)
         
         conservationneeded[nlca,]$ConservationActions.ConservationActionsSubfield.ConservationActionsLookup <- ConservationActionsLookup
         conservationneeded[nlca,]$ConservationActions.ConservationActionsSubfield.ConservationActionsName <- ConservationActionsName
         conservationneeded[nlca,]$ConservationActions.ConservationActionsSubfield.note <- texto_pats
         conservationneeded[nlca,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
         
         
       }
     }
       
       
       
       
     }
     
     
     # credits.csv
     {
       
       # Arquivo: credits.csv.
       # Campos:
       # 'Order',
       # 'affiliation',
       # 'credit_type',
       # 'email',
       # 'firstName',
       # 'initials',
       # 'internal_taxon_id',
       # 'lastName',
       
       print('credits')
       
       # credits_recorte <- readr::read_csv(paste0(path_app,'\\Credits_',dir_output,'.csv'),
       #                                    locale = locale(encoding = "UTF-8"),
       #                                    show_col_types = FALSE)
       
       credits_recorte$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       
       
       credits <- rbind(credits,
                        credits_recorte)
       
       # Order
       # 
       # affiliation
       # # afiliação de todos os especialistas
       # 
       # credit_type
       # 
       # # assessor - avaliador + especialistas (nessa ordem + ordem alfabetica para os especialistas)
       # 
       # # facilitator - todos dos colaboradores (todos do cncflora)
       # 
       # # reviewer (so no sistama)
       # # Dudu para toda - Briofitas
       # # Duda Briofitas
       # 
       # 
       # email
       # firstName
       # initials
       # 
       # # so a 1a
       # internal_taxon_id
       # # da planta
       # 
       # lastName
       # 
       # # nickname
       # user_id
     }
     
     
     # plantspecific.csv - CSV sem informação
     {
       
       print('plantspecific')
       
       # https://connect.iucnredlist.org/sis_classifications/135/findvalues
       
       # Arquivo: plantspecific.csv.
       # Campos:
       #   'PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup',
       # 'internal_taxon_id'
       
       # PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup
       # PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName
       # internal_taxon_id
       
       if(spp$Árvore_FB2020[i]==1 | spp$Palmeira_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'T'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Tree - size unknown'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
       if(spp$Subarbusto_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'S'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Shrub - size unknown'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
       
       if(spp$Arbusto_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'S'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Shrub - size unknown'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       

       if(spp$Epífita_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'E'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Epiphyte'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
              
       if(spp$Erva_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'F'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Forb or Herb'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       

       if(spp$Suculenta_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'SC'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Succulent - form unknown'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
       
       
       if(spp$Liana.volúvel.trepadeira_FB2020[i]==1)
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'V'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Vines'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
       
       if(spp$group_FB2020[i]=="Samambaias e Licófitas")
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'PT'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Fern'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
       if(spp$group_FB2020[i]=="Briófitas")
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'B'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Moss'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
       
       if(spp$family_FB2020[i] %in% c("Poaceae", "Cyperaceae"))
       {
         plantspecific <- plantspecific %>% dplyr::add_row()
         nlpe <- NROW(plantspecific)
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsLookup <- 'GR'
         plantspecific[nlpe,]$PlantGrowthForms.PlantGrowthFormsSubfield.PlantGrowthFormsName <- 'Graminoid'
         plantspecific[nlpe,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       }
       
     }
     
     # 22-08-22
     # autor na taxonomia
     # references.csv
     {
       # Arquivo: references.csv.
       # Campos:
       # 'Reference_type', OK
       # 'author', OK
       # 'title' , OK
       # 'year     OK
       
       print('references')
       
       index <- spp$scientificName_FB2020 == sp_selected
       
       # FB2020
       {
         references <- references %>% dplyr::add_row()
         nlref <- NROW(references)
         
         references[nlref,]$Reference_type <- 'Taxonomy'
         # access_date
         # alternate_title
         
         
         # buscar por API
         references[nlref,]$author <- '' #Colcar autor correto e separar por virgula'Flora do Brasil 2020'
         
         # date
         # edition
         # externalBibCode
         references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
         # isbnissn
         # keywords
         # references[nlref,]$number
         # references[nlref,]$number_of_volumes
         # references[nlref,]$pages
         # references[nlref,]$place_published 
         references[nlref,]$publisher <- 'Jardim Botânico do Rio de Janeiro'
         # references[nlref,]$secondary_author
         # references[nlref,]$secondary_title
         # section
         # short_title
         # references[nlref,]$submission_type 
         references[nlref,]$title <- paste0(spp[index==TRUE,]$FB2020_Family,'. Flora do Brasil 2020.')
         references[nlref,]$type <- 'electronic source'
         references[nlref,]$url <- paste0('https://floradobrasil.jbrj.gov.br/FB',spp[index==TRUE,]$taxonID)
         # references[nlref,]$volume
         references[nlref,]$year <- 2020
       }
       
       # Fern, K., 2019. Useful Tropical Plants Database [WWW Document]. Last Updat. 2019-06-13. URL http://tropical.theferns.info/ (accessed 6.1.19).
       # (Fern, K., 2019)
       {
         if((avaliacao[avaliacao$tag == 'fern_use',] %>%
             dplyr::select(valueLogical) %>% as.logical())==TRUE)
         {
           references <- references %>% dplyr::add_row()
           nlref <- NROW(references)
           
           references[nlref,]$Reference_type <- 'Assessment'
           # references[nlref,]$access_date <- '(accessed 13.4.2022)'
           # alternate_title
           references[nlref,]$author <- 'Fern, K.'
           # date
           # edition
           # externalBibCode
           references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
           # isbnissn
           # keywords
           # references[nlref,]$number
           # references[nlref,]$number_of_volumes
           # references[nlref,]$pages
           # references[nlref,]$place_published <- 'Jardim Botânico do Rio de Janeiro'
           # references[nlref,]$publisher
           # references[nlref,]$secondary_author
           # references[nlref,]$secondary_title
           # section
           # short_title
           # references[nlref,]$submission_type 
           references[nlref,]$title <- 'Useful Tropical Plants Database [WWW Document]. Last Updat. 2019-06-13'
           # references[nlref,]$type <- 'electronic source'
           references[nlref,]$url <- 'URL http://tropical.theferns.info/'
           # references[nlref,]$volume
           references[nlref,]$year <- 2019
         }
       }
       
       # Mark, J., Newton, A.C., Oldfield, S., Rivers, M., 2014. The International Timber Trade: A Working List of Commercial Timber Tree Species 1–56.
       # (Mark, et al., 2014)
       {
         if((avaliacao[avaliacao$tag == 'bgci_CommercialTimber_use',] %>%
             dplyr::select(valueLogical) %>% as.logical())==TRUE)
         {
           references <- references %>% dplyr::add_row()
           nlref <- NROW(references)
           
           references[nlref,]$Reference_type <- 'Assessment'
           # access_date
           # alternate_title
           references[nlref,]$author <- ' Mark, J., Newton, A.C., Oldfield, S., Rivers, M.'
           # date
           # edition
           # externalBibCode
           references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
           # isbnissn
           # keywords
           # references[nlref,]$number
           # references[nlref,]$number_of_volumes
           # references[nlref,]$pages
           # references[nlref,]$place_published <- 'Jardim Botânico do Rio de Janeiro'
           # references[nlref,]$publisher
           # references[nlref,]$secondary_author
           # references[nlref,]$secondary_title
           # section
           # short_title
           # references[nlref,]$submission_type 
           references[nlref,]$title <- 'The International Timber Trade: A Working List of Commercial Timber Tree Species'
           # references[nlref,]$type <- 'electronic source'
           # references[nlref,]$url <- paste0('https://floradobrasil.jbrj.gov.br/FB',spp[index==TRUE,]$taxonID)
           # references[nlref,]$volume
           references[nlref,]$year <- 2014
         }
       }
       
       # CITES, 2019. Convention on International Trade in Endangered Species of Wild Fauna and Flora [WWW Document]. CITES Append. URL https://www.cites.org/eng/app/appendices.php (accessed 5.26.19).
       # Botanic Gardens Conservation International
       # (CITES, 2019)
       {
         if((avaliacao[avaliacao$tag == 'cites_use',] %>%
             dplyr::select(valueLogical) %>% as.logical())==TRUE)
         {
           references <- references %>% dplyr::add_row()
           nlref <- NROW(references)
           
           references[nlref,]$Reference_type <- 'Assessment'
           # access_date
           # alternate_title
           references[nlref,]$author <- 'CITES'
           # date
           # edition
           # externalBibCode
           references[nlref,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
           # isbnissn
           # keywords
           # references[nlref,]$number
           # references[nlref,]$number_of_volumes
           # references[nlref,]$pages
           # references[nlref,]$place_published <- 'Jardim Botânico do Rio de Janeiro'
           references[nlref,]$publisher <- 'Botanic Gardens Conservation International'
           # references[nlref,]$secondary_author
           # references[nlref,]$secondary_title
           # section
           # short_title
           # references[nlref,]$submission_type 
           references[nlref,]$title <- 'Convention on International Trade in Endangered Species of Wild Fauna and Flora [WWW Document]. CITES Append'
           # references[nlref,]$type <- 'electronic source'
           references[nlref,]$url <- 'https://www.cites.org/eng/app/appendices.php' 
           # references[nlref,]$volume
           references[nlref,]$year <- 2019
         }
       }
       
     }
     
     # 22-08-22
     # duplicação - não achei ainda
     # synonyms.csv
     {
       print('synonyms')
       
       # Arquivo: synonyms.csv.
       # Campos:
       # 'name', OK
       # 'speciesAuthor', OK
       # 'speciesName' , OK
       # 'internal_taxon_id'
       
       # infraType
       # infrarankAuthor
       # infrarankName
       # internal_taxon_id
       # name
       # speciesAuthor	
       # speciesName
       
       synonym_sp <- FloraBrasil2020 %>% 
         dplyr::filter(acceptedNameUsage_FB2020 %in% sp_selected &
                         taxonomicStatus_FB2020 == 'SINONIMO') %>%
         dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                       synonym = scientificName_FB2020) 
       
       
       # 22-08-22
       # verificar se há duplicação de sininomo na espécie
       # synonym_sp
       
       # index_autor_infrataxa <- synonym_sp$taxonRank_FB2020 %in% c("VARIEDADE", "SUB_ESPECIE", "FORMA")
       # autor_infrataxa <- word(synonym_sp$scientificName_FB2020[index_autor_infrataxa==TRUE],3)
       # index_autor_infrataxa <- ! autor_infrataxa %in% c('var.', 'supsp.', 'form.')
       # autor_infrataxa <- ifelse(index_autor_infrataxa==TRUE,
       #        autor_infrataxa[index_autor_infrataxa==TRUE],
       #        '')
       
       
       if (NROW(synonym_sp)>0)
       {   
         synonym_sp$infraType <- ''
         synonym_sp$autor_synonym <- ''
         is <- 1
         for (is in 1:NROW(synonym_sp))
         {
           
           {
             index_autor_synonym <- synonym_sp$taxonRank_FB2020[is] %in% c("VARIEDADE", "SUB_ESPECIE", "FORMA")
             autor_synonym <- word(synonym_sp$scientificName_FB2020[index_autor_synonym==TRUE],3)
             autor_synonym <- ifelse(is.na(autor_synonym),'',autor_synonym)
             index_autor_synonym <- ! autor_synonym %in% c('var.', 'subsp.', 'form.')
             synonym_sp$autor_synonym[is] <- ifelse(index_autor_synonym==TRUE,
                                                    autor_synonym[index_autor_synonym==TRUE],
                                                    '')
           }
           
           
           {
             synonym_sp$infraType[is] <- ifelse(synonym_sp$taxonRank[is] %in% c("VARIEDADE"),
                                                'var.', synonym_sp$infraType[is])
             synonym_sp$infraType[is] <- ifelse(synonym_sp$taxonRank[is] %in% c("SUB_ESPECIE"),
                                                'subsp.', synonym_sp$infraType[is])
             synonym_sp$infraType[is] <- ifelse(synonym_sp$taxonRank[is] %in% c("FORMA"),
                                                'form.', synonym_sp$infraType[is])
           }
           
           
           synonyms <- synonyms %>% dplyr::add_row()
           nlsyn <- NROW(synonyms)
           
           synonyms[nlsyn,]$infraType <- synonym_sp$infraType[is]
           synonyms[nlsyn,]$infrarankAuthor <- synonym_sp$autor_synonym[is]
           synonyms[nlsyn,]$infrarankName <- ifelse(is.na(synonym_sp$infraspecificEpithet_FB2020[is]),'', synonym_sp$infraspecificEpithet_FB2020[is])
           synonyms[nlsyn,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
           synonyms[nlsyn,]$name <- synonym_sp$genus_FB2020[is]
           synonyms[nlsyn,]$speciesAuthor <- synonym_sp$scientificNameAuthorship_FB2020[is]
           synonyms[nlsyn,]$speciesName <- synonym_sp$specificEpithet_FB2020[is]
         }
         
       }
     }       
     
     
     # 22-08-22
     # incluir taxonomias superiores - feito
     # taxonomy.csv
     {
       # Campos:
       # 'classname',
       # 'family',
       # 'genus',
       # 'internal_taxon_id',
       # 'ordername',
       # 'phylum',
       # 'species',
       # 'taxonomicAuthority'
       
       print('taxonomy')
       
       taxonomy <- taxonomy %>% dplyr::add_row()
       nltx <- NROW(taxonomy)
       
       taxonomy[nltx,]$Redlist_id <- ''
       
       taxonomy[nltx,]$TaxonomicNotes.value <- ifelse(is.na(spp$namePublishedIn_FB2020[i]),'',paste0('Descrita em:',spp$namePublishedIn_FB2020[i]))
       taxonomy[nltx,]$classname <- spp$class_FB2020[i] # obrigatorio em ProFlora
       taxonomy[nltx,]$family <- spp$FB2020_Family[i] # obrigatorio em ProFlora
       taxonomy[nltx,]$genus <- spp$genus_FB2020[i] # obrigatorio em ProFlora
       # infraType
       # infra_authority
       # infra_name
       taxonomy[nltx,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2)) # obrigatorio em ProFlora
       taxonomy[nltx,]$kingdom <- 'PLANTAE'
       taxonomy[nltx,]$ordername <- spp$order_FB2020[i] # obrigatorio em ProFlora
       taxonomy[nltx,]$phylum <- spp$phylum_FB2020[i] # obrigatorio em ProFlora
       taxonomy[nltx,]$species <- spp$specificEpithet_FB2020[i]  # obrigatorio em ProFlora
       taxonomy[nltx,]$taxonomicAuthority <- spp$scientificNameAuthorship_FB2020[i]  # obrigatorio em ProFlora
       
     }
     
     # 22-08-22
     # trocar os traços - feito
     # habitats.csv
     {
       
       # Arquivo: habitats.csv.
       # Campos:
       # 'GeneralHabitats.GeneralHabitatsSubfield.GeneralHabitatsLookup', OK
       # 'GeneralHabitats.GeneralHabitatsSubfield.GeneralHabitatsName', OK
       # 'GeneralHabitats.GeneralHabitatsSubfield.suitability', OK
       # 'internal_taxon_id' OK
       
       # sis conect
       # em GeneralHabitats.GeneralHabitatsSubfield.GeneralHabitatsName 
       # trocar – por -
       
       print('habitats')
       ihab=1
       
       TiposVegetacaoFB2020_IUCN_sel <- avaliacao[avaliacao$tag == 'TiposVegetacaoFB2020_IUCN',] %>%
         dplyr::filter(valueLogical==TRUE) %>%
         dplyr::select(code, label) %>%
         dplyr::distinct_all()
       
       if (NROW(TiposVegetacaoFB2020_IUCN_sel)>0)
       {
         for( ihab in 1:NROW(TiposVegetacaoFB2020_IUCN_sel))
         {
           
           habitats <- habitats %>% dplyr::add_row()
           nlhab <- NROW(habitats)
           
           habitats
           
           
           
           habitats[nlhab,]$GeneralHabitats.GeneralHabitatsSubfield.GeneralHabitatsLookup <- TiposVegetacaoFB2020_IUCN_sel$code[ihab]
           habitats[nlhab,]$GeneralHabitats.GeneralHabitatsSubfield.GeneralHabitatsName <- gsub(paste0(TiposVegetacaoFB2020_IUCN_sel$code[ihab], '. '),
                                                                                                '',
                                                                                                gsub('–', '-', TiposVegetacaoFB2020_IUCN_sel$label[ihab]))
           # GeneralHabitats.GeneralHabitatsSubfield.majorImportance
           habitats[nlhab,]$GeneralHabitats.GeneralHabitatsSubfield.season <- 'Resident'
           habitats[nlhab,]$GeneralHabitats.GeneralHabitatsSubfield.suitability <- 'Suitable'
           habitats[nlhab,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
         }
       }
       
     }
     
     
     # threats.csv  - CSV sem informação para LCs
     {
       print('threats')
       # https://connect.iucnredlist.org/sis_classifications/139/findvalues
       
       # Arquivo: threats.csv.
       # Campos:
       #   'Threats.ThreatsSubfield.ThreatsLookup',
       #   'Threats.ThreatsSubfield.timing',
       #   'internal_taxon_id'
       
       # Threats.ThreatsSubfield.StressesSubfield.stress
       # Threats.ThreatsSubfield.StressesSubfield.stressdesc
       # Threats.ThreatsSubfield.ThreatsLookup
       # Threats.ThreatsSubfield.ThreatsName
       # # Threats.ThreatsSubfield.ancestry
       # # Threats.ThreatsSubfield.ias
       # Threats.ThreatsSubfield.internationalTrade
       # Threats.ThreatsSubfield.scope
       # # Threats.ThreatsSubfield.severity
       # # Threats.ThreatsSubfield.text
       # Threats.ThreatsSubfield.timing
       # # Threats.ThreatsSubfield.virus
       # internal_taxon_id

       threats <- threats %>% dplyr::add_row()
       nlth <- NROW(threats)

       threats[nlth,]$Threats.ThreatsSubfield.ThreatsLookup <- '9.6.4' #Type Unknown/Unrecorded
       threats[nlth,]$Threats.ThreatsSubfield.timing <- 'Unknown'
       threats[nlth,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
     }
     
     
     # usetrade.csv
     # utilizar o texto e cadastrar no proflora- CSV sem informação - feito
     {
       print('usetrade')
       
       # Arquivo: usetrade.csv.
       # Campos:
       #   'UTEndUse.UTEndUseSubfield.UTEndUseLookup',
       # 'internal_taxon_id'
       
       # UTEndUse.UTEndUseSubfield.UTEndUseLookup
       # UTEndUse.UTEndUseSubfield.UTEndUseName
       # # UTEndUse.UTEndUseSubfield.international
       # # UTEndUse.UTEndUseSubfield.national
       # # UTEndUse.UTEndUseSubfield.other
       # # UTEndUse.UTEndUseSubfield.subsistence
       # internal_taxon_id
       
   
       
       UTEndUse.UTEndUseSubfield.UTEndUseLookup <- avaliacao[avaliacao$tag == 'description_use',] %>%
         dplyr::select(valueText) %>%
         as.character()
       
       usetrade <- usetrade %>% dplyr::add_row()
       nluse <- NROW(usetrade)
       
       usetrade[nluse,]$UTEndUse.UTEndUseSubfield.UTEndUseLookup <- UTEndUse.UTEndUseSubfield.UTEndUseLookup
       usetrade[nluse,]$internal_taxon_id <- paste0('Workshop_CNCFlora_2022 - ',word(sp_selected,1), ' ',word(sp_selected,2))
       
     }
     
     
   }
   
   #' @section Salvar dados
   {
     
     internal_taxon_id_sel <- assessments %>%
       dplyr::filter(RedListCriteria.manualCategory%in%'LC') %>%
       dplyr::select(internal_taxon_id)
     
     sp_sel <- gsub('Workshop_CNCFlora_2022 - ',
                    '',
                    internal_taxon_id_sel$internal_taxon_id)
     
     # allfields
     csv_result <- paste0(path_csv_results,'\\allfields.csv')
     write.csv(allfields %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     
     # assessments
     csv_result <- paste0(path_csv_results,'\\assessments.csv')
     write.csv(assessments%>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # maps
     csv_result <- paste0(path_csv_results,'\\maps.csv')
     write.csv(maps %>%
                 dplyr::filter(Binomial%in%sp_sel), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # occurrence
     csv_result <- paste0(path_csv_results,'\\occurrence.csv')
     index <- paste0(word(occurrence$scientificName,1), ' ', word(occurrence$scientificName,2))%in%sp_sel
     write.csv(occurrence[index==TRUE,], 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # commonnames
     csv_result <- paste0(path_csv_results,'\\commonnames.csv')
     write.csv(commonnames %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # synonyms
     csv_result <- paste0(path_csv_results,'\\synonyms.csv')
     write.csv(synonyms %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # taxonomy
     csv_result <- paste0(path_csv_results,'\\taxonomy.csv')
     write.csv(taxonomy %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # countries
     csv_result <- paste0(path_csv_results,'\\countries.csv')
     write.csv(countries %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # credits
     csv_result <- paste0(path_csv_results,'\\credits.csv')
     write.csv(credits %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # habitats
     csv_result <- paste0(path_csv_results,'\\habitats.csv')
     write.csv(habitats %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # references
     csv_result <- paste0(path_csv_results,'\\references.csv')
     write.csv(references %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     
     # CSVs sem informação
     
     # threats 
     csv_result <- paste0(path_csv_results,'\\threats.csv')
     write.csv(threats %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # usetrade
     csv_result <- paste0(path_csv_results,'\\usetrade.csv')
     write.csv(usetrade %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id),
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # plantspecific
     csv_result <- paste0(path_csv_results,'\\plantspecific.csv')
     write.csv(plantspecific %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id),
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     # conservationneeded
     csv_result <- paste0(path_csv_results,'\\conservationneeded.csv')
     write.csv(conservationneeded %>%
                 dplyr::filter(internal_taxon_id%in%internal_taxon_id_sel$internal_taxon_id), 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     
     # occ
     col_save <- c("select_record",
                   "emUC",
                   "tipoUC",
                   # "nomeUC",
                   "bioma",
                   "Ctrl_occurrenceID",
                   "Ctrl_bibliographicCitation",                        
                   "Ctrl_downloadAsSynonym",
                   "Ctrl_scientificNameSearched",
                   "Ctrl_scientificNameReference",
                   "Ctrl_acceptedNameUsage",
                   "Ctrl_scientificNameAuthorship",
                   "Ctrl_scientificName",
                   "Ctrl_family",
                   "Ctrl_genus",
                   "Ctrl_specificEpithet",
                   "Ctrl_infraspecificEpithet",                         
                   # "Ctrl_modified"                                    
                   "Ctrl_institutionCode",
                   "Ctrl_collectionCode",                              
                   "Ctrl_catalogNumber",
                   "Ctrl_identificationQualifier",                     
                   "Ctrl_identifiedBy",
                   "Ctrl_dateIdentified" ,                             
                   "Ctrl_typeStatus",
                   "Ctrl_recordNumber",
                   "Ctrl_recordedBy",
                   "Ctrl_country",
                   "Ctrl_stateProvince",
                   "Ctrl_municipality",
                   "Ctrl_locality",
                   "Ctrl_year",
                   "Ctrl_month",                                       
                   "Ctrl_day",
                   # "Ctrl_decimalLatitude"                             
                   # "Ctrl_decimalLongitude",
                   "Ctrl_occurrenceRemarks",                           
                   "Ctrl_comments",
                   
                   # "temAnoColeta"
                   # "temCodigoInstituicao"                           
                   # "temNumeroCatalogo"
                   # "temColetor"
                   # "temNumeroColeta"  
                   # "temPais"                                          
                   # "temUF" 
                   # "temMunicipio"                                     
                   # "temLocalidade"                                     
                   # "temIdentificador"                                 
                   # "temDataIdentificacao" 
                   
                   # "Ctrl_country_standardized"                        
                   # "Ctrl_municipality_standardized"                    "Ctrl_stateProvince_standardized"                  
                   # "Ctrl_locality_standardized"                        "Ctrl_stateProvince_standardized_check"            
                   # "municipality_stateProvince_unique"                 "municipality_stateProvince_check"                 
                   # "municipality_check"                                "stateProvince_check"                              
                   # "status_municipality_stateProvince_check"           "temCoordenadas"                                   
                   # "coordenadasIncidemMunicipio"                       "inBRA"                                            
                   # "coordenadasIncidemBRA"                             "encontrouLocalidade"                              
                   # "coordenadasCentroideMunicipio"                     "coordenadasCentroidePais"                         
                   # "autoGeoStatus"                                     
                   
                   "autoGeoNotes",
                   
                   # [79] "codigofraseSaida"                                  "Ctrl_autoGeoLongitude"                            
                   # [81] "Ctrl_autoGeoLatitude"                              "Ctrl_nameRecordedBy_Standard"                     
                   # [83] "Ctrl_recordNumber_Standard"                        "Ctrl_key_family_recordedBy_recordNumber"          
                   # [85] "Ctrl_numberRecordsOfSample"                        "Ctrl_numberRecordsOfSampleByBibliographicCitation"
                   # [87] "verbatim_quality"                                  "key_quality"                                      
                   # [89] "geo_quality"                                       "Ctrl_moreInformativeRecord"                       
                   # [91] "Ctrl_selectedMoreInformativeRecord"                "Ctrl_thereAreDuplicates"                          
                   # [93] "Ctrl_unmatched"                                    "ID_PRV"                                           
                   # [95] "emUso"                                             "ID"                                               
                   # [97] "in_out_status"
                   "Longitude",                                        
                   "Latitude")
     
     
     # col_save_new <- gsub('Ctrl_','',col_save)
     # occ_all_new <- occ_all
     # colnames(occ_all_new) <- col_save_new
     
     
     # conservationneeded
     csv_result <- paste0(path_csv_results,'\\occ_all.csv')
     write.csv(occ_all[,col_save], 
               csv_result,
               fileEncoding = "UTF-8", 
               na = "", 
               row.names = FALSE)
     
     
     occ_all[,col_save]
     
     
   }
   
   
   allfields %>% View()
   
   assessments %>% View()
   
   maps %>% View()
   
   occurrence %>% View()
   
   commonnames %>% View()
   