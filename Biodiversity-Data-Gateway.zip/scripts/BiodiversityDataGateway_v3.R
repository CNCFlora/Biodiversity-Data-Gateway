###############################################################################################################################
#' @title Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ
#' @source Centro Nacional de Conservação da Flora
#' @source Diretoria de Pesquisa do Instituto de Pesquisas Jardim Botânico do Rio de Janeiro
#' @source Ministério do Meio Ambiente
#' @source Rua Pacheco Leão, 915, Sala 201
#' @source Jardim Botânico Rio de Janeiro/RJ 22.460-030
#' @source http://cncflora.jbrj.gov.br
#' @author Pablo Hendrigo Alves de Melo
#' @note  pablomelo@jbjr.gov.br / +55 21 3204 2092
#' @note  pablopains@yahoo.com.br
#' @note  CRBio4-49242/04-D
#' @author Eduardo Amorim 
#' @author Monira Bicalho 
#' @author Lucas Arguello 
#' @author George Queiroz
#' @author Fernanda Wimmer
#' @author Mario Gomes
#' @author Lucas Jordão
#' @author Gláucia Crispim
#' @author Marcio Verdi
#' @author Thais Dória
#' @author Fernanda Saleme
#' @author Vicente Calfo
#' @author André Eppinghaus
#' @author Thais Laque
#' @author Eduardo Fernandez
#' @encoding UFT-8

#' ultima modificação: 18/06/2022, Pablo H.
################################################################################################################################

# 0. Selecionar dataset e overwrite ####
#' @section Selecionar dataset e overwrite
{


  #' @section Limpar ambiente  R
  { 
    rm(list = ls())
    
    # temp dir R
    if(!dir.exists('C:\\temps')){dir.create('C:\\temps')}
    tempdir <- function() "C:\\temps"
    assignInNamespace("tempdir", tempdir, ns="base", envir=baseenv())
    # assign("tempdir", tempdir, baseenv())
    lockBinding("tempdir", baseenv())
    tempdir()
    
    memory.limit (9999999999)
  }
  
  #' @section Sobrescrever dados?
  overwrite <- FALSE
  
  
  #' @section Selecionar dataset
  # dir_output <- 'WS_Asteraceae_Endemicas' # ok
  # 
  # dir_output <- 'WS_Briofitas_Endemicas'  # ok
  # 
  dir_output <- 'WS_Bromeliaceae_Endemicas' # ok
  # 
  # dir_output <- 'WS_Euphorbiaceae_Endemicas' # ok
  # 
  # dir_output <- 'WS_Fabaceae_Endemicas'
  # 
  # dir_output <- 'WS_Malvaceae_Endemicas'
  # 
  # dir_output <- 'WS_Melastomataceae_Endemicas'
  # 
  # dir_output <- 'WS_Myrtaceae_Endemicas'
  # 
  # dir_output <- 'WS_Orchidaceae_Endemicas'
  # 
  # dir_output <- 'WS_Poaceae_Endemicas'
  # 
  # dir_output <- 'WS_Rubiaceae_Endemicas'
  # 
  # dir_output <- 'WS_Samambaias_e_Licofitas_Endemicas'
  
  print(dir_output)
}


# 1. Carregar Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA - CNCFlora/JBRJ ####
#' @section Carregar dados, mapas, e aplicativo
{
  
  # 1.1. Preparar ambiente R ####
  #' @section Preparar ambiente R
  {
    #' @section Preparar R
    { 
      # rm(list = ls())
      # 
      # # temp dir R
      # if(!dir.exists('C:\\temps')){dir.create('C:\\temps')}
      # tempdir <- function() "C:\\temps"
      # assignInNamespace("tempdir", tempdir, ns="base", envir=baseenv())
      # # assign("tempdir", tempdir, baseenv())
      # lockBinding("tempdir", baseenv())
      # tempdir()
      # 
      # memory.limit (9999999999)
      # 
      #' # 1.1. Instalar pacotes ####
      #' #' @section 1.1. Instalar pacotes
      #' {
      #'   install.packages('shiny', dependencies = TRUE)
      #'   install.packages('DT', dependencies = TRUE)
      #'   install.packages('kableExtra', dependencies = TRUE)
      #'   install.packages('readr', dependencies = TRUE)
      #'   install.packages('dplyr', dependencies = TRUE)
      #'   install.packages('plyr', dependencies = TRUE)
      #'   install.packages('stringr', dependencies = TRUE)
      #'   install.packages('lubridate', dependencies = TRUE)
      #'   install.packages('CoordinateCleaner', dependencies = TRUE)
      #'   install.packages('rnaturalearthdata', dependencies = TRUE)
      #'   install.packages('monographaR', dependencies = TRUE)
      #'   install.packages('stringr', dependencies = TRUE)
      #'   install.packages('jsonlite', dependencies = TRUE)
      #'   install.packages('sqldf', dependencies = TRUE)
      #'   install.packages('RCurl', dependencies = TRUE)
      #'   install.packages('shinydashboard', dependencies = TRUE)
      #'   install.packages('leaflet', dependencies = TRUE)
      #'   
      #'   install.packages('rhandsontable', dependencies = TRUE)
      #'   install.packages('dygraphs', dependencies = TRUE)
      #'   install.packages('shinyWidgets', dependencies = TRUE)
      #'   install.packages('shinythemes', dependencies = TRUE)
      #'   install.packages('sf', dependencies = TRUE)
      #'   install.packages('shinydashboard', dependencies = TRUE)
      #'   install.packages('leaflegend', dependencies = TRUE)
      #'   install.packages('stringi', dependencies = TRUE)
      #'   install.packages('shinyjs', dependencies = TRUE)
      #'   install.packages('redlistr', dependencies = TRUE)
      #'   
      #'   
      #' 
      #' }
      
      library(shiny)
      library(DT)
      library(kableExtra)
      
      # carregar pacotes
      library(readr)
      library(dplyr)
      library(plyr)
      library(stringr)
      library(lubridate)
      library(CoordinateCleaner)
      library(rnaturalearthdata)
      library(raster)
      # library(geobr)
      library(monographaR)
      library(stringr)
      library(jsonlite)
      library(sqldf)
      library(RCurl)
      library(shinydashboard)
      library(leaflet)
      
      # install.packages('dygraphs')
      library(dygraphs)
      
      
      library(rhandsontable) # tabela editavel
      library(shinyWidgets) # botoes
      
      library(shinyjs)
      library(shinythemes)
      library(sf)
      
      
      library(dismo) #dismo::circles()
      
      library(shinydashboard)
      library(leaflegend)
      
      library(stringi)
      
      
      # source('./functions/export_CSV_v3.R', encoding = "UTF-8")
      # source('./functions/grafia_UF.R', encoding = "UTF-8")
      # source('./functions/FB2020_IPT_Use_v2.R', encoding = "UTF-8")
      
      source('C:\\BiodiversityDataGateway\\functions\\FB2020_IPT_Use_v2_ws.R', encoding = "UTF-8")
      colnames(FloraBrasil2020) <- paste0(colnames(FloraBrasil2020),'_FB2020')
      
      
      source('C:\\BiodiversityDataGateway\\functions\\export_CSV_v3.R', encoding = "UTF-8")
      source('C:\\BiodiversityDataGateway\\functions\\grafia_UF.R', encoding = "UTF-8")
      
      
      # source('./functions/FB2020_IPT_Use_v2.R', encoding = "UTF-8")
      # colnames(FloraBrasil2020) <- paste0(colnames(FloraBrasil2020),'_FB2020')
      
      source('C:\\BiodiversityDataGateway\\functions\\vegetationType_FB2020_x_IUCN_ws.R', encoding = "UTF-8")
      
      source('C:\\BiodiversityDataGateway\\functions\\IUCNRedList_Check_Specie.R', encoding = "UTF-8")
      # iucn.file <- paste0("./",dir_output,"/results/iucn_status.csv")
      
      source('C:\\BiodiversityDataGateway\\functions\\BGCI_Commercial_Timber_Check_Specie.R', encoding = "UTF-8")
      
      
    }
    
    
    #' @section Preparar mapas
    {
      
      # biomas 
      shape_bioma.path <- "C:\\BiodiversityDataGateway\\Shapefiles\\Biomas_250mil"
      shape_bioma.file <- "lm_bioma_250"
      bioma_br <- rgdal::readOGR(dsn=shape_bioma.path,
                                 layer=shape_bioma.file,
                                 verbose=FALSE,
                                 stringsAsFactors=FALSE,
                                 encoding = 'UTF-8', #SHAPE_ENCODING 
                                 use_iconv =TRUE)
      proj4string(bioma_br) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
      
      # ucs BR
      # http:://
      shape_uc.path <- "C:\\BiodiversityDataGateway\\Shapefiles\\UCs_WGS84"
      shape_uc.file <- "UCs_wgs84"
      ucs_br <- rgdal::readOGR(dsn=shape_uc.path,
                               layer=shape_uc.file,
                               verbose=FALSE,
                               stringsAsFactors=FALSE,
                               encoding = 'UTF-8', #SHAPE_ENCODING
                               use_iconv =TRUE)
      proj4string(ucs_br) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
      
      # limite_utm <- rnaturalearth::ne_countries(continent = c('south america'), returnclass = "sp")
      # # https://epsg.io/29193
      crs_utm <- "+init=epsg:29193"
      crs_utm <- "+proj=utm +zone=23 +south +datum=WGS84 +units=m +no_defs"
      # limite_utm <- spTransform(limite_utm, CRS(crs_utm))
      
      
      
      # Mapas para operação off line ####
      
      
      shape_br.path <- "C:\\BiodiversityDataGateway\\Shapefiles\\BR"
      shape_br.file <- "BR"
      BR_IBGE <- rgdal::readOGR(dsn=shape_br.path,
                                layer=shape_br.file,
                                verbose=FALSE,
                                stringsAsFactors=FALSE,
                                encoding = 'UTF-8', #SHAPE_ENCODING
                                use_iconv =TRUE)
      proj4string(BR_IBGE) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
      
      shape_uf.path <- "C:\\BiodiversityDataGateway\\Shapefiles\\BR_UF_2020"
      shape_uf.file <- "BR_UF_2020"
      Estados_IBGE <- rgdal::readOGR(dsn=shape_uf.path,
                                     layer=shape_uf.file,
                                     verbose=FALSE,
                                     stringsAsFactors=FALSE,
                                     encoding = 'UTF-8', #SHAPE_ENCODING
                                     use_iconv =TRUE)
      proj4string(Estados_IBGE) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
      
      shape_mun.path <- "C:\\BiodiversityDataGateway\\Shapefiles\\BR_Municipios_2020"
      shape_mun.file <- "BR_Municipios_2020"
      Municipios_IBGE <- rgdal::readOGR(dsn=shape_mun.path,
                                        layer=shape_mun.file,
                                        verbose=FALSE,
                                        stringsAsFactors=FALSE,
                                        encoding = 'UTF-8', #SHAPE_ENCODING
                                        use_iconv =TRUE)
      Municipios_IBGE$Mun_ES <- paste0(Municipios_IBGE$NM_MUN, " (", Municipios_IBGE$SIGLA_UF,")")
      proj4string(Municipios_IBGE) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
      
      # mapas base leaflet
      {
        iconSet <- awesomeIconList(
          `Vértice EOO Dentro UC` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'darkblue',
            iconRotate = 30
          ),
          `Vértice EOO Fora UC` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'blue',
            iconRotate = 30
          ),
          `Validado Dentro UC` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'darkgreen',
            iconRotate = 30
          ),
          `Validado Fora UC` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'lightgreen',
            iconRotate = 30
          ),
          `Invalidado Dentro UC` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'darkred',
            iconRotate = 30
          ),
          `Invalidado Fora UC` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'lightred',
            iconRotate = 30
          ),
          `Fora Brasil` = makeAwesomeIcon(
            icon = 'whatever',
            library = 'ion',
            iconColor = 'black',
            markerColor = 'black',
            iconRotate = 90
          )
          
        )
        
        # 
        # pal <- colorNumeric(legenda$cor, domain=NULL)
        
        m_map_on <- leaflet( width = '800px', height = '800px') %>%
          addProviderTiles("OpenStreetMap.Mapnik", group = "Mapnik") %>%
          addProviderTiles("Esri.WorldImagery", group = 'WorldImagery') %>%
          addProviderTiles("Stamen.Terrain", group = 'Terrain') %>%
          addLayersControl(
            overlayGroups = c("Vértice EOO", "Validados", "Invalidados"), 
            baseGroups = c("Mapnik", "WorldImagery", "Terrain")) 
        
        
        m_map_off <- leaflet( width = '800px', height = '800px') %>%
          addLayersControl(
            overlayGroups = c("Vértice EOO", "Validados", "Invalidados")) 
        # %>%
        #    setView(lat = -18.10, lng = -44.38, zoom = 3) 
        
        m_map_off_br <- leaflet( width = '800px', height = '800px') %>%
          addLayersControl(
            overlayGroups = c("Vértice EOO", "Validados", "Invalidados")) %>%
          # setView(lat = -18.10, lng = -44.38, zoom = 4) %>%
          addPolygons(data = BR_IBGE,
                      fillOpacity = 0,
                      weight = 2,
                      color = "black") 
      }   
      
      
    }
    
    
    #' @section Carregar funções APP
    {
      #' @section Camamada de cálculos
      {# dt <- occ_tmp
        dados_ <-function(input, dt)
        {
          sp_sel <- spp[spp$FB2020_AcceptedNameUsage==input$sp,]
          # sp_sel <- spp[spp$FB2020_AcceptedNameUsage==spp$FB2020_AcceptedNameUsage[1],]
          # dt <- occ_in
          
          
          # dt <- dt %>% 
          #    dplyr::mutate(emUso = (Identificação == TRUE) & (Localização == TRUE))
          
          occ_in_sel = dt %>%
            dplyr::filter(preValidacao=='in') %>% 
            dplyr::mutate(emUso = (Identificação == TRUE) & (Localização == TRUE))
          
          occ_global_sel = dt %>%
            dplyr::filter(preValidacao=='global') %>% 
            dplyr::mutate(emUso = (Identificação == TRUE) & (Localização == TRUE))
          print(NROW(occ_global_sel))
          
          occ_out_to_recover_sel = dt %>%
            dplyr::filter(preValidacao=='out_to_recover') %>% 
            dplyr::mutate(emUso = (Identificação == TRUE) & (Localização == TRUE))
          
          occ_out = dt %>%
            dplyr::filter(preValidacao=='out')
          
          EOO <- NA
          EOO_area <- 0
          EOO_vertices <- NA
          AOO2 <- 0
          red_AOO2 <- 0
          
          locations_number <- 0
          locations_number2000 <- 0
          locations_number50000 <- 0
          
          pts.foraBR_utm <- NA
          
          totalRegistros_in <- 0
          totalRegistros_invalidados <- 0
          
          totalRegistros_in_geral <- 0
          
          
          totalRegistros_global <- 0
          totalRegistros_out_to_recover <- 0
          emUC_US <- FALSE
          cronologia_coletas <- ''
          
          serie_coleta <- NA
          
          pts.foraBR_utm <- NA
          
          Municipios_IBGE_sel <- NA
          Estados_IBGE_sel <- NA
          
          n_biomas <- 0
          biomas_names <- NA
          
          regions <- 0
          regions_names <- NA
          
          n_estados <- 0
          estados_names <- NA
          
          nUC_PI <- 0
          uc_names_PI  <- NA
          nreg_emUC_PI <- 0
          
          nUC_US <- 0
          uc_names_US <- NA
          nreg_emUC_US <- 0
          
          if (NROW(occ_global_sel)>0)
          {
            pts.foraBR_utm <- sp::SpatialPointsDataFrame(occ_global_sel %>%
                                                           dplyr::select(Longitude,
                                                                         Latitude),
                                                         data.frame(occ_global_sel))
            proj4string(pts.foraBR_utm) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
            pts.foraBR_utm <- sp::spTransform(pts.foraBR_utm, CRS(crs_utm))
          }
          
          
          if (sum(occ_in_sel$emUso) > 0)
          {
            points_for_locations <-  sp::SpatialPointsDataFrame(occ_in_sel[occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                                data.frame(occ_in_sel[occ_in_sel$emUso==T,]))
            
            proj4string(points_for_locations) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
            
            locations_number <- dismo::circles(points_for_locations, d=input$locations_distance*1000, lonlat=T)
            # locations_number <- dismo::circles(points_for_locations, d=2*1000, lonlat=T)
            locations_number <- length(locations_number@polygons@polygons[[1]]@plotOrder)
            
            locations_number2000 <- dismo::circles(points_for_locations, d=2000, lonlat=T)
            locations_number2000 <- length(locations_number2000@polygons@polygons[[1]]@plotOrder)
            
            
            locations_number50000 <- dismo::circles(points_for_locations, d=50000, lonlat=T)
            locations_number50000 <- length(locations_number50000@polygons@polygons[[1]]@plotOrder)
            
          }
          
          
          pts.utm <- NA
          # if(sum(occ_in_sel$emUso) >=3 )
          if(locations_number2000 >=3 )
          {
            occ.pto_in <- sp::SpatialPointsDataFrame(occ_in_sel[occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                     data.frame(occ_in_sel[occ_in_sel$emUso==T,]))
            
            proj4string(occ.pto_in) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
            # # https://epsg.io/29193
            pts.utm <- sp::spTransform(occ.pto_in, CRS(crs_utm))
            
            
            EOO <- redlistr::makeEOO(pts.utm)
            proj4string(EOO) <- sp::CRS(crs_utm)
            EOO_area <- round(redlistr::getAreaEOO(EOO), digits = 0)
            
            # EOO_geo_vetor <- sf::st_as_sf(EOO, fill = TRUE, group = TRUE)
            EOO_pontos <- sf::st_as_sf(pts.utm, fill = TRUE, group = TRUE)
            
            ## Minimo polígono convexo
            EOO_pontos_convexo <- EOO_pontos %>%
              sf::st_union() %>%
              sf::st_convex_hull()
            ## Vertices
            EOO_vertices <- sf::st_cast(EOO_pontos_convexo, "POINT")
            EOO_vertices
            
            occ_in_sel$verticeEOO[occ_in_sel$emUso==T] <- ifelse(EOO_pontos$geometry %in% EOO_vertices,TRUE,FALSE)
            occ_in$verticeEOO[occ_in$emUso==T][occ_in$Ctrl_scientificNameReference[occ_in$emUso==T] %in% input$show_sp] <- ifelse(EOO_pontos$geometry %in% EOO_vertices, TRUE, FALSE)
            
            # flag T para vertices
            # occ_in_sel$Verificar_Vertice_EOO <- occ_in_sel$verticeEOO 
            # occ_in$Verificar_Vertice_EOO[occ_in$Ctrl_scientificNameReference %in% input$show_sp] <- occ_in$verticeEOO[occ_in$Ctrl_scientificNameReference %in% input$show_sp]
            
            AOO2 <- redlistr::getAOO(pts.utm, 2000) * 4
            
            # red_AOO2 <- round(red::aoo(pts.utm@coords), digits = 0)
            
            
            # AOO_grid <- makeAOOGrid(pts.utm, 2000, min.percent.rule = TRUE, percent = 1)
            
          }else
          {
            
            # definir regras com DUDU AOO e EOO
            # EOO <- NA
            EOO_area <- 4*locations_number2000
            AOO2 <- 4*locations_number2000
            red_AOO2 <- 4*locations_number2000
            
          }
          
          if (NROW(occ_in_sel) > 0)
          {
            
            # série de coletas
            serie_coleta <- sqldf::sqldf("SELECT DISTINCT Ctrl_year, COUNT(Ctrl_year)
                              FROM occ_in_sel
                              WHERE emUso = TRUE
                              GROUP BY Ctrl_year
                              ORDER BY Ctrl_year ASC") %>%
              na.omit() %>%
              dplyr::filter(Ctrl_year>1800)
            cronologia_coletas <- paste0(min(serie_coleta$Ctrl_year),' - ',max(serie_coleta$Ctrl_year))
            
            
            occ_in_sel <- occ_in_sel %>%
              dplyr::arrange_at(c('verticeEOO', 'Latitude', 'Longitude'), desc)
            
            occ.pto <- sp::SpatialPointsDataFrame(cbind.data.frame(occ_in_sel$Longitude,
                                                                   occ_in_sel$Latitude),
                                                  data.frame(occ_in_sel %>% dplyr::select()))
            proj4string(occ.pto) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
            
            # ocorre em ucs?
            {
              
              index_ucs <- ! occ_in_sel$autoGeoNotes %in% "Coordenada centróide de município"
              index_ucs_in <- ! occ_in$autoGeoNotes %in% "Coordenada centróide de município"
              
              occ.pto_ucs <- sp::SpatialPointsDataFrame(cbind.data.frame(occ_in_sel$Longitude[index_ucs==TRUE],
                                                                         occ_in_sel$Latitude[index_ucs==TRUE]),
                                                        data.frame(occ_in_sel[index_ucs==TRUE,] %>% dplyr::select()))
              proj4string(occ.pto_ucs) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
              
              
              x <- over(occ.pto_ucs, ucs_br)
              
              if(NROW(x)>0)
              {
                occ_in_sel$nomeUC[index_ucs==TRUE] <- x$NOME_UC1
                occ_in$nomeUC[index_ucs_in==TRUE][occ_in$Ctrl_scientificNameReference[index_ucs_in==TRUE] %in% input$show_sp] <- ifelse(!is.na(x$NOME_UC1),x$NOME_UC1,NA)
                
                occ_in_sel$emUC[index_ucs==TRUE] <- ifelse(!is.na(x$NOME_UC1),TRUE,FALSE)
                occ_in$emUC[index_ucs_in==TRUE][occ_in$Ctrl_scientificNameReference[index_ucs_in==TRUE] %in% input$show_sp] <- ifelse(!is.na(x$NOME_UC1),TRUE,FALSE)
                
                occ_in_sel$tipoUC[index_ucs==TRUE] <- x$GRUPO4
                occ_in$tipoUC[index_ucs_in==TRUE][occ_in$Ctrl_scientificNameReference[index_ucs_in==TRUE] %in% input$show_sp] <- ifelse(!is.na(x$GRUPO4),x$GRUPO4,NA)
              }
              
              
            }
          }
          
          
          # biomas, ufs, municipios
          if (sum(occ_in_sel$emUso) > 0)
          {
            
            occ.pto_bioma <- sp::SpatialPointsDataFrame(occ_in_sel[occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                        data.frame(occ_in_sel[occ_in_sel$emUso==T,]))
            
            proj4string(occ.pto_bioma) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
            
            
            #biomas
            {
              x <- over(occ.pto_bioma, bioma_br)
              
              if(NROW(x)>0)
              {
                occ_in_sel$bioma[occ_in_sel$emUso==T] <- x$Bioma
                occ_in$bioma[occ_in$Ctrl_scientificNameReference %in% input$show_sp & occ_in$emUso==T] <- ifelse(!is.na(x$Bioma),x$Bioma,NA)
              }
            }
            
            # biomas
            n_biomas <- sqldf::sqldf("SELECT COUNT( DISTINCT bioma)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND bioma != ''") %>% as.numeric()
            
            biomas_names <- sqldf::sqldf("SELECT DISTINCT bioma, 
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND bioma != ''
                           GROUP BY bioma
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") 
            # %>%
            #    dplyr::mutate(`emFB2020?`=FALSE)
            
            colnames(biomas_names) <- c('Biome', 'numberRecords')
            
            if (NROW(biomas_names)>0)
            {
              
              biomas_names$emFB2020 <- FALSE
              
              for (i in 1:nrow(biomas_names))
              {
                biomas_names$emFB2020[i] <- grepl(biomas_names$Biome[i],
                                                  sp_sel$occurrenceRemarks_FB2020,
                                                  ignore.case = TRUE)
              }
              colnames(biomas_names) <- c('Biome', 'numberRecords', 'inFB2020?')
              
            }
            
            # avaliar aqui
            # estados
            
            n_estados <- occ_in_sel %>%
              dplyr::filter(emUso==T) %>%
              # dplyr::select(stateProvince_check) %>%
              dplyr::select(Ctrl_stateProvince_standardized) %>%
              unique() %>%
              na.omit() %>%
              NROW()
            
            
            # estados_names <- sqldf::sqldf("SELECT DISTINCT Ctrl_stateProvince_standardized, stateProvince_check,
            estados_names <- sqldf::sqldf("SELECT DISTINCT stateProvince_check,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE 
                           GROUP BY stateProvince_check
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") 
            # %>%
            #    dplyr::mutate(`emFB2020?`=FALSE)
            
            colnames(estados_names) <- c('StateProvince', 'numberRecords')
            # colnames(estados_names) <- c('StateProvince','StateProvinceCode', 'numberRecords', 'inFB2020?')
            
            if (NROW(estados_names)>0)
            {
              estados_names$emFB2020 <- FALSE
              
              for (i in 1:nrow(estados_names))
              {
                # estados_names$emFB2020[i] <- grepl(estados_names$StateProvince[i],
                estados_names$emFB2020[i] <- grepl(estados_names$StateProvince[i], 
                                                   sp_sel$location_FB2020, 
                                                   ignore.case = TRUE)
              }
              colnames(estados_names) <- c('StateProvince', 'numberRecords', 'inFB2020?')
            }
            
            # municipios
            regions <- occ_in_sel %>%
              dplyr::filter(emUso==T) %>%
              # dplyr::select(Ctrl_municipality_standardized, Ctrl_stateProvince_standardized) %>% 
              dplyr::select(municipality_stateProvince_check) %>%
              unique() %>%
              na.omit() %>%
              NROW()
            
            # municipios
            regions_names <- sqldf::sqldf("SELECT DISTINCT municipality_stateProvince_check, 
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND municipality_stateProvince_check != ''
                           GROUP BY municipality_stateProvince_check
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC")
            colnames(regions_names) <- c('municipalityStateProvince', 'numberRecords')
            
            
            # Sys.Date() %>% lubridate::year() -50
            # ucs
            uc_names_PI <- sqldf::sqldf("SELECT DISTINCT nomeUC,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND tipoUC = 'PI' AND Ctrl_year >= 1972
                           GROUP BY nomeUC, tipoUC
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") %>% na.omit()
            
            colnames(uc_names_PI) <- c('nameUC_PI', 'numberRecords')
            
            uc_names_US <- sqldf::sqldf("SELECT DISTINCT nomeUC,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND tipoUC = 'US' AND Ctrl_year >= 1972
                           GROUP BY nomeUC, tipoUC
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC")
            colnames(uc_names_US) <- c('nameUC_US', 'numberRecords')
            
            
            # nreg_emUC_PI <- sum(occ_in_sel$emUC[occ_in_sel$emUso==T & occ_in_sel$tipoUC=='PI']==TRUE)
            # nreg_emUC_US <- sum(occ_in_sel$emUC[occ_in_sel$emUso==T & occ_in_sel$tipoUC=='US']==TRUE)
            
            nreg_emUC_PI <- sqldf::sqldf("SELECT COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND emUC = TRUE AND tipoUC = 'PI'  AND Ctrl_year >= 1972") %>% as.numeric()
            
            nreg_emUC_US <- sqldf::sqldf("SELECT COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel
                           WHERE emUso = TRUE AND emUC = TRUE AND tipoUC = 'US'  AND Ctrl_year >= 1972") %>% as.numeric()
            
            # nUC <- occ_in_sel$nomeUC[occ_in_sel$emUso==T] %>% unique() 
            
            nUC_PI <- occ_in_sel %>%
              dplyr::filter(emUso==T & tipoUC=='PI' & Ctrl_year >= 1972) %>%
              dplyr::select(nomeUC) %>% 
              unique() %>% 
              na.omit() %>% 
              as.data.frame() %>% NROW()
            
            nUC_US <- occ_in_sel %>%
              dplyr::filter(emUso==T & tipoUC=='US' & Ctrl_year >= 1972) %>%
              dplyr::select(nomeUC) %>% 
              unique() %>% 
              na.omit() %>% 
              as.data.frame() %>% NROW()
            
            
          }
          
          
          totalRegistros_in <- NROW(occ_in_sel %>%
                                      dplyr::filter(emUso==T))
          
          totalRegistros_invalidados <- NROW(occ_in_sel %>%
                                               dplyr::filter(emUso==F))
          
          totalRegistros_in_geral <- NROW(occ_in_sel)
          
          totalRegistros_global <- NROW(occ_global_sel)
          totalRegistros_out_to_recover <- NROW(occ_out_to_recover_sel)
          
          occ_in_sel <- occ_in_sel %>%
            dplyr::mutate(cor=ifelse(occ_in_sel$verticeEOO==TRUE, ifelse(occ_in_sel$emUC==TRUE,'darkblue','blue'), 
                                     ifelse(occ_in_sel$emUC==TRUE, ifelse(occ_in_sel$emUso==TRUE,'darkgreen','darkred'), 
                                            ifelse(occ_in_sel$emUso==TRUE,'lightgreen','lightred'))))
          
          
          occ <- rbind(occ_out_to_recover,
                       occ_in,
                       occ_global)
          
          # occ_formatada <- formatar_dados(occ)
          
          occ_formatada <- formatar_dados(occ_in_sel)
          
          etiquetaCompleta <- occ_in_sel %>%
            dplyr::select(Ctrl_occurrenceID,
                          Ctrl_key_family_recordedBy_recordNumber,
                          Ctrl_thereAreDuplicates,
                          Ctrl_numberRecordsOfSample,
                          temAnoColeta,
                          temCodigoInstituicao,
                          temNumeroCatalogo,
                          temColetor,
                          temNumeroColeta,
                          temPais,
                          temUF,
                          temMunicipio,
                          temLocalidade,
                          temIdentificador,
                          temDataIdentificacao)
          
          
          # eoo e aoo e situaçoes de ameaça
          # categoria_LC <- ((EOO_area > input$eoo_limit) & (AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((EOO_area > input$eoo_limit) & (AOO2 < input$aoo_limit) & (locations_number > input$locations_min_number))
          
          # eoo e situaçoes de ameaça
          categoria_LC <- ((EOO_area > input$eoo_limit)  & (locations_number > input$locations_min_number))
          
          return(
            list(categoria_LC = categoria_LC,
                  occ = occ,
                  
                  occ_formatada = occ_formatada,
                  
                  occ_out = occ_out,
                  # $occ,
                  # occ_formatada_v = occ_formatada$occ_v,
                  # occ_formatada_detalhes = occ_formatada$occ_d
                  # occ_comparar = occ_formatada$occ_comparar,
                  
                  occ_in_sel=occ_in_sel,
                  occ_global_sel=occ_global_sel,
                  occ_out_to_recover_sel=occ_out_to_recover_sel,
                  pts_utm=pts.utm,
                  pts_foraBR_utm=pts.foraBR_utm,
                  EOO=EOO,
                  EOO_area=EOO_area,
                  EOO_vertices=EOO_vertices,
                  AOO2=AOO2,
                  red_AOO2=red_AOO2,
                  
                  serie_coleta = serie_coleta,
                  cronologia_coletas = cronologia_coletas,
                  
                  totalRegistros_in = totalRegistros_in,
                  totalRegistros_invalidados = totalRegistros_invalidados,
                  
                  totalRegistros_in_geral = totalRegistros_in_geral,
                  
                  totalRegistros_global = totalRegistros_global,
                  totalRegistros_out_to_recover = totalRegistros_out_to_recover,
                  
                  # nreg_emUC = nreg_emUC,
                  # nUC = nUC,
                  
                  nreg_emUC_PI = nreg_emUC_PI,
                  nreg_emUC_US =nreg_emUC_US,
                  
                  nUC_PI = nUC_PI,
                  
                  nUC_US =nUC_US,
                  
                  uc_names_PI = uc_names_PI,
                  uc_names_US = uc_names_US,
                  
                  
                  # nreg_emUC <- 1,
                  # nUC <- 1,
                  # nomes_UCs <- 'lala',
                  
                  etiquetaCompleta=etiquetaCompleta,
                  sp_sel=sp_sel,
                  
                  n_biomas = n_biomas,
                  biomas_names = biomas_names,
                  
                  n_estados = n_estados,
                  estados_names = estados_names,
                  
                  regions = regions,
                  regions_names = regions_names,
                  
                  # Municipios_IBGE_sel=Municipios_IBGE_sel,
                  # Estados_IBGE_sel=Estados_IBGE_sel
                  
                  locations_number = locations_number,
                  locations_number2000 = locations_number2000,
                  locations_number50000 = locations_number50000
                  
            ))
          
        }
        
        # xx <- dados_('input',occ_csv)
      }
    
      
      #' @section links com coleçoes get_link_source_record
      {
        # # reflora e jabot com barcode
        # i<-1
        # 
        # # jabot
        # i<-54572
        # i<-13802
        # 
        # # gbif
        # i<- 17448
        # 
        # occurrenceID <- occ_in$Ctrl_occurrenceID[i]
        # bibliographicCitation <- occ_in$Ctrl_bibliographicCitation[i] %>% tolower()
        # scientificNameReference <- occ_in$Ctrl_scientificNameReference[i]
        # 
        # # occ_in %>% dplyr::select(Ctrl_bibliographicCitation, Ctrl_occurrenceID) %>% View()
        
        get_link_source_record <- function(occurrenceID,
                                           bibliographicCitation,
                                           scientificNameReference)
        {
          
          bibliographicCitation <- bibliographicCitation %>% tolower()
          
          if (bibliographicCitation == "reflora")
          {
            barcode <- gsub(paste0(tolower(bibliographicCitation),"=" ), '',occurrenceID )
            
            base_url <- "http://reflora.jbrj.gov.br/reflora/herbarioVirtual/ConsultaPublicoHVUC/BemVindoConsultaPublicaHVConsultar.do?modoConsulta=LISTAGEM&quantidadeResultado=20&codigoBarra=%s"
            url <- sprintf(base_url, barcode)
            url
            
            link <- paste0("<a href='", url, "'target='_blank'>", occurrenceID,"</a>")
            
            link
          }
          
          
          # jabot
          if (bibliographicCitation == "jabot")
          {
            barcode <- gsub(paste0(tolower(bibliographicCitation),"=" ), '',occurrenceID )
            
            col <- stringr::str_extract_all(barcode, "[A-Z]+", simplify = TRUE)
            
            cat <- stringr::str_extract_all(barcode, "[0-9]+", simplify = TRUE)
            
            
            base_url <- "http://rb.jbrj.gov.br/v2/regua/visualizador.php?r=true&colbot=%s&codtestemunho=%s"
            url_img <- sprintf(base_url,col %>% tolower(), cat)
            url_img
            
            link_img <- paste0("<a href='", url_img, "' target='_blank'> Imagem: ", occurrenceID,"</a>")
            link_img
            
            base_url <- "http://jabot.jbrj.gov.br/v3/ficha.php?chtestemunho=%s&sigla=%s"
            url_ficha <- sprintf(base_url,cat, col)
            url_ficha
            
            link_ficha <- paste0("<a href='", url_ficha, "'target='_blank'> Ficha: ", occurrenceID,"</a>")
            link_ficha
            
            link <- paste0(link_img, '; ', link_ficha)
          }
          
          
          
          
          if (bibliographicCitation=='splink')
          {
            
            # com barcode
            
            if (!is.na(str_locate(occurrenceID,':')[[1]]))
            {
              
              # occurrenceID_tmp <- gsub(paste0(tolower(bibliographicCitation),"=" ), '',occurrenceID )
              # occurrenceID_tmp <- str_split(occurrenceID_tmp,':')
              # 
              # col <- occurrenceID_tmp[[1]][1]
              # cat <- occurrenceID_tmp[[1]][2]
              
              # base_url <- "https://specieslink.net/search/records/col/%s"
              # url <- sprintf(base_url,col %>% tolower(), cat)
              url <- 'https://specieslink.net/search/'
              url
              
              link <- paste0("<a href='", url, "'target='_blank'>", occurrenceID,"</a>")
              link
            }else  
            {
              barcode <- gsub(paste0(tolower(bibliographicCitation),"=" ), '',occurrenceID )
              
              base_url <- "https://specieslink.net/search/records/barcode/%s"
              url <- sprintf(base_url, barcode)
              url
              
              link <- paste0("<a href='", url, "'target='_blank'>", occurrenceID,"</a>")
              link
            }
            
            
            
          }
          
          
          
          if (bibliographicCitation=='gbif')
          {
            
            occurrenceID_tmp <- gsub(paste0(tolower(bibliographicCitation),"=" ), '',occurrenceID )
            occurrenceID_tmp <- str_split(occurrenceID_tmp,':')
            
            col <- occurrenceID_tmp[[1]][1]
            cat <- occurrenceID_tmp[[1]][2]
            
            base_url <- "https://www.gbif.org/occurrence/search?catalog_number=%s&collection_code=%s&occurrence_status=present"
            url <- sprintf(base_url,cat, col)
            url
            
            link <- paste0("<a href='", url, "'target='_blank'>", occurrenceID,"</a>")
            link
            
            # gbif
            # gbif=RB:RB01460567
            # link https://www.gbif.org/occurrence/search?catalog_number=RB01460567&collection_code=RB&occurrence_status=present
            
            
            # occ_source <- rgbif::occ_search(collectionCode =  'RB' ,
            #                                 catalogNumber = 'RB01460567',
            #                                 limit = 1,
            #                                 basisOfRecord = 'PRESERVED_SPECIMEN')
            
            
          }
          
          return(link)
          
        }
        
      }
      
      
      #' @section Camamada de formatação de dados
      {   
        # x_input <- occ
        formatar_dados <- function(x_input)
        {
          stateProvince_tmp <- grafia_UF(stateProvince_standardized = x_input$Ctrl_stateProvince_standardized)$stateProvince
          
          # conforme CSV sistema com pequenos ajustes
          {
            x <- x_input %>%
              dplyr::mutate(modified='') %>%
              dplyr::select(modified,
                            Ctrl_institutionCode,
                            Ctrl_collectionCode,
                            Ctrl_catalogNumber,
                            # Ctrl_scientificName,
                            Ctrl_scientificNameSearched, # Aqui SUBSPP no sistema
                            Ctrl_scientificNameReference,
                            Ctrl_identificationQualifier,
                            Ctrl_family,
                            Ctrl_genus,
                            Ctrl_specificEpithet,
                            Ctrl_infraspecificEpithet,
                            Ctrl_scientificNameAuthorship,
                            Ctrl_identifiedBy,
                            Ctrl_dateIdentified,
                            Ctrl_typeStatus,
                            Ctrl_recordNumber,
                            Ctrl_fieldNumber,
                            Ctrl_recordedBy,
                            Ctrl_year,
                            Ctrl_month,
                            Ctrl_day,
                            Ctrl_country,
                            # Ctrl_country_standardized,
                            
                            Ctrl_stateProvince_standardized,
                            
                            # 17-09-2021
                            Ctrl_municipality_standardized,
                            # Ctrl_municipality,
                            Ctrl_locality,
                            Ctrl_decimalLongitude,
                            Ctrl_decimalLatitude,
                            Ctrl_occurrenceRemarks,
                            Ctrl_acceptedNameUsage,
                            Ctrl_occurrenceID,
                            Ctrl_comments,
                            Ctrl_bibliographicCitation,
                            
                            codigofraseSaida,
                            
                            verbatimNotes,
                            autoGeoNotes,
                            autoGeoStatus,
                            # in_out_status,
                            
                            Ctrl_autoGeoLongitude,
                            Ctrl_autoGeoLatitude,
                            
                            Ctrl_key_family_recordedBy_recordNumber,
                            Ctrl_moreInformativeRecord,
                            Ctrl_selectedMoreInformativeRecord,
                            Ctrl_thereAreDuplicates,
                            
                            Ctrl_thereAreDuplicates,
                            
                            ID_PRV,
                            
                            emUso,
                            verticeEOO,
                            emUC,
                            tipoUC,
                            nomeUC
                            
              ) %>%
              
              #    duplicateGroupingkey = Ctrl_key_family_recordedBy_recordNumber,
              # duplicates = Ctrl_thereAreDuplicates,
              # dataColeta = paste0(na.omit(day),'/',na.omit(month),'/',na.omit(year)),
              # 15-04-2020
              dplyr::mutate(Ctrl_occurrenceRemarks = ifelse(is.na(Ctrl_comments), Ctrl_occurrenceRemarks, paste0(Ctrl_comments, Ctrl_occurrenceRemarks))) %>%
              dplyr::mutate(Ctrl_duplicateGroupingkey = Ctrl_key_family_recordedBy_recordNumber,
                            Ctrl_duplicates = Ctrl_thereAreDuplicates,
                            Ctrl_dataColeta = paste0(ifelse(is.na(Ctrl_day),'',Ctrl_day),'/',ifelse(is.na(Ctrl_month),'',Ctrl_month),'/',ifelse(is.na(Ctrl_year),'',Ctrl_year))) %>%
              # 
              dplyr::rename(institutionCode	 = Ctrl_institutionCode,
                            collectionCode = Ctrl_collectionCode,
                            catalogNumber = Ctrl_catalogNumber,	
                            
                            # scientificNameSource = Ctrl_scientificName,
                            
                            # no csv sai esse
                            scientificName = Ctrl_scientificNameSearched,
                            # scientificName = Ctrl_scientificNameReference,	
                            
                            identificationQualifier = Ctrl_identificationQualifier,	
                            family = Ctrl_family,	
                            genus = Ctrl_genus,
                            specificEpithet = Ctrl_specificEpithet,	
                            infraspecificEpithet = Ctrl_infraspecificEpithet,	
                            scientificNameAuthorship = Ctrl_scientificNameAuthorship,	
                            identifiedBy = Ctrl_identifiedBy,	
                            dateIdentified = Ctrl_dateIdentified,	
                            typeStatus = Ctrl_typeStatus,	
                            recordNumber = Ctrl_recordNumber,	
                            fieldNumber = Ctrl_fieldNumber,	
                            recordedBy = Ctrl_recordedBy,
                            
                            duplicateGroupingkey = Ctrl_duplicateGroupingkey,
                            
                            duplicates = Ctrl_duplicates,
                            dataColeta = Ctrl_dataColeta,
                            # year = Ctrl_year,	
                            # month = Ctrl_month,	
                            # day = Ctrl_day,
                            country = Ctrl_country,	
                            
                            stateProvince = Ctrl_stateProvince_standardized,
                            
                            # # 04-06-2020 grafia original do nome do municipio
                            # # municipality = Ctrl_municipality_standardized,	
                            # municipality = Ctrl_municipality,	
                            
                            # 17-09-2021 exportar corrigida do nome do municipio
                            # Acordado com Glaucia, Lucas Jordão e Duda
                            
                            municipality = Ctrl_municipality_standardized,	
                            # municipality = Ctrl_municipality,	
                            
                            locality = Ctrl_locality,	
                            
                            decimalLatitude = Ctrl_decimalLatitude,	
                            decimalLongitude = Ctrl_decimalLongitude,	
                            
                            occurrenceRemarks = Ctrl_occurrenceRemarks,
                            
                            acceptedNameUsage = Ctrl_acceptedNameUsage,	
                            occurrenceID = Ctrl_occurrenceID,	
                            comments = Ctrl_comments,	
                            # bibliographicCitation  = Ctrl_bibliographicCitation
                            
                            # resumo dos estados da planilha in stateProvinceConfirmedOccurrence = 
                            
              ) %>%
              dplyr::mutate(
                # modified	= '',
                #            institutionCode = '',
                #            fieldNumber = '',
                #            
                # 18-10-2021
                # occurrenceID = '',
                
                # 04-06-2020 ajustar grafia de UF
                stateProvince = stateProvince_tmp, 
                
                # ajustes finos 03-06-2020 - informação de typo nos comentários
                comments = toupper(typeStatus),
                comments = ifelse(is.na(comments)==TRUE, autoGeoNotes, paste0(comments,'; ',autoGeoNotes))
                
                # identificationQualifier  = ''
              ) %>%
              
              # erro em briofitas
              
              # dplyr::mutate(comments = dplyr::if_else( (Ctrl_thereAreDuplicates == TRUE & in_out_status == FALSE ),
              
              # aqui 11-05-22
              # dplyr::mutate(comments = dplyr::if_else( (Ctrl_thereAreDuplicates == TRUE & Ctrl_selectedMoreInformativeRecord == FALSE),
              #                                          paste0('Duplicata; ',comments),comments)) %>%
              
              dplyr::mutate(comments = ifelse( (Ctrl_thereAreDuplicates == TRUE & Ctrl_selectedMoreInformativeRecord == FALSE),
                                               paste0('Duplicata; ',comments),comments)) %>%
              
              
              
              dplyr::mutate(decimalLatitude = ifelse(is.na(Ctrl_autoGeoLatitude)==TRUE, decimalLatitude, Ctrl_autoGeoLatitude),
                            decimalLongitude = ifelse(is.na(Ctrl_autoGeoLongitude)==TRUE, decimalLongitude, Ctrl_autoGeoLongitude)) %>%
              # dplyr::mutate(comments = ifelse(verbatimNotes=='',comments ,
              #                                 paste0(comments, '; Sem informações de (',verbatimNotes,')') ))
              dplyr::mutate(comments = ifelse(is.na(verbatimNotes),comments ,
                                              paste0(comments, '; Sem informações de (',verbatimNotes,')') )) %>%
              
              
              # 18-10-20
              # memória de registro
              # comments = Ctrl_comments,
              dplyr::mutate(comments = paste0(comments, ' [occurrenceID : ',occurrenceID,']')) 
            
            x_v <- x %>%
              dplyr::select(institutionCode,
                            collectionCode,
                            catalogNumber,
                            
                            scientificName,
                            acceptedNameUsage,
                            
                            identificationQualifier,
                            family,
                            identifiedBy,
                            dateIdentified,
                            typeStatus,
                            recordNumber,
                            fieldNumber,
                            recordedBy,
                            duplicateGroupingkey,
                            duplicates,
                            dataColeta,
                            
                            country,	
                            
                            stateProvince,
                            
                            # # 04-06-2020 grafia original do nome do municipio
                            # # municipality = Ctrl_municipality_standardized,	
                            # municipality = Ctrl_municipality,	
                            
                            # 17-09-2021 exportar corrigida do nome do municipio
                            # Acordado com Glaucia, Lucas Jordão e Duda
                            
                            municipality,
                            # municipality = Ctrl_municipality,	
                            
                            locality,
                            
                            decimalLatitude,
                            decimalLongitude,
                            
                            occurrenceRemarks,
                            
                            # occurrenceID,
                            comments,
                            # modified,
                            emUso,
                            verticeEOO,
                            emUC,
                            tipoUC,
                            nomeUC,
                            ID_PRV)
            
            # %>%
            #    dplyr::mutate(occurrenceID = '')   
            
            
            
            # dplyr::mutate(duplicateGroupingkey = Ctrl_key_family_recordedBy_recordNumber,
            #               duplicates = Ctrl_thereAreDuplicates,
            #               dataColeta = paste0(na.omit(day),'/',na.omit(month),'/',na.omit(year)),
            #               recordedBy = paste0(na.omit(recordedBy),' - ',na.omit(recordNumber),' (',na.omit(Ctrl_key_family_recordedBy_recordNumber),' )')) %>%
            
            
            # x_v <- x %>%
            #    dplyr::select(-Ctrl_day, -Ctrl_month, -Ctrl_year,
            #                  -codigofraseSaida,
            #                  -verbatimNotes,
            #                  -autoGeoNotes,
            #                  -autoGeoStatus,
            #                  # -in_out_status,
            #                  
            #                  -Ctrl_autoGeoLongitude,
            #                  -Ctrl_autoGeoLatitude,
            #                  
            #                  -Ctrl_key_family_recordedBy_recordNumber,
            #                  -Ctrl_moreInformativeRecord,
            #                  -Ctrl_selectedMoreInformativeRecord,
            #                  -Ctrl_thereAreDuplicates,
            #                  -Ctrl_scientificNameReference,
            #                  
            #                  -modified,
            #                  -institutionCode,
            #                  -fieldNumber
            #                  
            #    )
          }
          
          
          
          # # conforme CSV sistema com pequenos ajustes
          # {
          #    x_comparar <- x_input %>%
          #       # 15-04-2020
          #       dplyr::mutate(Ctrl_occurrenceRemarks = ifelse(is.na(Ctrl_comments), Ctrl_occurrenceRemarks, paste0(Ctrl_comments, Ctrl_occurrenceRemarks))) %>%
          #       # 
          #       dplyr::rename(
          #                     
          #                     # institutionCode	 = Ctrl_institutionCode,
          #                     # collectionCode = Ctrl_collectionCode,
          #                     # catalogNumber = Ctrl_catalogNumber,	
          #                     
          #                     scientificNameSource = Ctrl_scientificName,
          #                     scientificNameSearch = Ctrl_scientificNameReference,	
          #                     
          #                     # identificationQualifier = Ctrl_identificationQualifier,	
          #                     # family = Ctrl_family,	
          #                     # genus = Ctrl_genus,
          #                     # specificEpithet = Ctrl_specificEpithet,	
          #                     # infraspecificEpithet = Ctrl_infraspecificEpithet,	
          #                     # scientificNameAuthorship = Ctrl_scientificNameAuthorship,	
          #                     # identifiedBy = Ctrl_identifiedBy,	
          #                     # dateIdentified = Ctrl_dateIdentified,	
          #                     typeStatus = Ctrl_typeStatus,
          #                     
          #                     
          #                     recordNumberSource = Ctrl_recordNumber,	
          #                     recordedBySource = Ctrl_recordedBy,	
          #                     
          #                     duplicateGroupingkey = Ctrl_key_family_recordedBy_recordNumber,
          #                     
          #                     
          #                     # year = Ctrl_year,	
          #                     # month = Ctrl_month,	
          #                     # day = Ctrl_day,
          #                     # country = Ctrl_country,	
          #                     
          #                     stateProvinceSource = Ctrl_stateProvince,
          #                     stateProvinceStandardized = Ctrl_stateProvince_standardized,
          #                     stateProvinceStandardized_check = Ctrl_stateProvince_standardized_check,
          #                     
          #                     # # 04-06-2020 grafia original do nome do municipio
          #                     # # municipality = Ctrl_municipality_standardized,	
          #                     # municipality = Ctrl_municipality,	
          #                     
          #                     # 17-09-2021 exportar corrigida do nome do municipio
          #                     # Acordado com Glaucia, Lucas Jordão e Duda
          #                     
          #                     municipalitySource = Ctrl_municipality,	
          #                     municipalityStandardized = Ctrl_municipality_standardized,	
          #                     municipalityStandardized_check = municipality_stateProvince_check,	
          #                     municipality_stateProvince_unique = municipality_stateProvince_unique,
          #                     
          #                     
          #                     # locality = Ctrl_locality,	
          #                     
          #                     decimalLatitudeSource = Ctrl_decimalLatitude,	
          #                     decimalLongitudeSource = Ctrl_decimalLongitude,	
          #                     
          #                     decimalLatitudeStandardized = Ctrl_autoGeoLatitude,	
          #                     decimalLongitudeStandardized = Ctrl_autoGeoLongitude,	
          #                     
          #                     
          #                     # occurrenceRemarks = Ctrl_occurrenceRemarks,
          #                     
          #                     # acceptedNameUsage = Ctrl_acceptedNameUsage,	
          #                     occurrenceID = Ctrl_occurrenceID,	
          #                     comments = Ctrl_comments,	
          #                     bibliographicCitation  = Ctrl_bibliographicCitation,
          #                     
          #                     
          #                     duplicates =Ctrl_thereAreDuplicates,
          #                     
          #                     dataFieldsNoInformation = verbatimNotes,
          #                     
          #                     geographicalCoordinateNotes = autoGeoNotes
          #                     
          #                     # resumo dos estados da planilha in stateProvinceConfirmedOccurrence = 
          #                     
          #       ) %>%
          #       dplyr::mutate(
          #                     # 04-06-2020 ajustar grafia de UF
          #                     stateProvince = stateProvince_tmp
          #                     
          #       ) 
          #    
          # 
          #    
          #    x_comparar <- x_comparar %>%
          #       dplyr::select(# institutionCode	 = Ctrl_institutionCode,
          #                     # collectionCode = Ctrl_collectionCode,
          #                     # catalogNumber = Ctrl_catalogNumber,	
          #          
          #          dataFieldsNoInformation,
          #          geographicalCoordinateNotes,
          #                     
          #                     scientificNameSource,
          #                     scientificNameSearch,
          #                     
          #                     # identificationQualifier = Ctrl_identificationQualifier,	
          #                     # family = Ctrl_family,	
          #                     # genus = Ctrl_genus,
          #                     # specificEpithet = Ctrl_specificEpithet,	
          #                     # infraspecificEpithet = Ctrl_infraspecificEpithet,	
          #                     # scientificNameAuthorship = Ctrl_scientificNameAuthorship,	
          #                     # identifiedBy = Ctrl_identifiedBy,	
          #                     # dateIdentified = Ctrl_dateIdentified,	
          #                     # typeStatus = Ctrl_typeStatus,	
          #                     
          #                     
          #                     recordNumberSource,
          #                     # fieldNumberSource,
          #                     recordedBySource,
          #                     
          #                     duplicateGroupingkey,
          #                     
          #                     
          #                     # year = Ctrl_year,	
          #                     # month = Ctrl_month,	
          #                     # day = Ctrl_day,
          #                     # country = Ctrl_country,	
          #                     stateProvince,
          #                     stateProvinceSource,
          #                     stateProvinceStandardized,
          #                     stateProvinceStandardized_check,
          #                     
          #                     # # 04-06-2020 grafia original do nome do municipio
          #                     # # municipality = Ctrl_municipality_standardized,	
          #                     # municipality = Ctrl_municipality,	
          #                     
          #                     # 17-09-2021 exportar corrigida do nome do municipio
          #                     # Acordado com Glaucia, Lucas Jordão e Duda
          #                     
          #                     municipalitySource,
          #                     municipalityStandardized,
          #                     municipalityStandardized_check,	
          #                     municipality_stateProvince_unique,
          #                     
          #                     
          #                     # locality = Ctrl_locality,	
          #                     
          #                     decimalLatitudeSource,
          #                     decimalLongitudeSource,
          #                     
          #                     decimalLatitudeStandardized,
          #                     decimalLongitudeStandardized,
          #                     
          #                     
          #                     # acceptedNameUsage = Ctrl_acceptedNameUsage,	
          #                     # occurrenceID,
          #                     # bibliographicCitation,
          #                     
          #                     ID_PRV
          #                     
          #       )
          # }
          
          x_d <- x %>%
            dplyr::mutate(
              # duplicateGroupingkey = Ctrl_key_family_recordedBy_recordNumber,
              #            duplicates = Ctrl_thereAreDuplicates,
              #            dataColeta = paste0(na.omit(day),'/',na.omit(month),'/',na.omit(year)),
              
              # recordedBy = paste0(na.omit(recordedBy),' - ',na.omit(recordNumber),' (',na.omit(Ctrl_key_family_recordedBy_recordNumber),')')) %>%
              recordedBy = paste0(ifelse(is.na(recordedBy),'',recordedBy),' - ',ifelse(is.na(recordNumber),'',recordNumber),' (',ifelse(is.na(Ctrl_key_family_recordedBy_recordNumber),'',Ctrl_key_family_recordedBy_recordNumber) ),')') %>%
            dplyr::select(
              # duplicateGroupingkey,
              comments,
              recordedBy,
              # recordNumber,
              dataColeta,
              stateProvince,
              municipality,
              locality,
              
              identifiedBy,
              dateIdentified,
              identificationQualifier,
              
              occurrenceRemarks,
              
              # comments,
              
              # emUC,
              tipoUC,
              nomeUC,
              
              verticeEOO,
              emUso,
              duplicates,
              
              # occurrenceID,
              
              ID_PRV
              
              
              # collectionCode,
              # catalogNumber,
              # # ID_PRV,
              
              # institutionCode,
              # collectionCode,
              # catalogNumber,
              # 
              # scientificName,
              # # scientificName = Ctrl_scientificNameReference,	
              # 
              # identificationQualifier,
              # family,
              # genus,
              # specificEpithet,
              # infraspecificEpithet,
              # scientificNameAuthorship,
              # identifiedBy,
              # dateIdentified,
              # typeStatus,
              # recordNumber,
              # recordedBy,
              # year,
              # month,
              # day,
              # country,
              # 
              # stateProvince,
              # 
              # # # 04-06-2020 grafia original do nome do municipio
              # # # municipality = Ctrl_municipality_standardized,	
              # # municipality = Ctrl_municipality,	
              # 
              # # 17-09-2021 exportar corrigida do nome do municipio
              # # Acordado com Glaucia, Lucas Jordão e Duda
              # 
              # municipality,
              # # municipality = Ctrl_municipality,	
              # 
              # locality,
              # 
              # decimalLatitude,
              # decimalLongitude,
              # 
              # occurrenceRemarks,
              # 
              # acceptedNameUsage,
              # occurrenceID,
              # comments,
              # bibliographicCitation
            )
          
          
          
                          
                          # Ctrl_bibliographicCitation              codigofraseSaida                       
                          # verbatimNotes                           autoGeoNotes                            autoGeoStatus                          
                          # Ctrl_autoGeoLongitude                   Ctrl_autoGeoLatitude                    Ctrl_key_family_recordedBy_recordNumber
                          # Ctrl_moreInformativeRecord              Ctrl_selectedMoreInformativeRecord      Ctrl_thereAreDuplicates                
                          # ID_PRV                                  emUso                                   verticeEOO                             
                          # emUC                                    tipoUC                                  nomeUC                                 
                          # duplicateGroupingkey                    duplicates                            
          return(list(occ = x,
                      occ_ficha = x_v,
                      occ_detalhe = x_d))
          # ,
          #             occ_comparar=x_comparar))
        }   
        
        # occ_f <- formatar_dados(occ)
      }
      
      #' @section retorna o ID_PRV do registro no Mapa
      {
        # mudar aqui para inseri municipio e uf
        ID <- function(input)
        {
          linha <- input$hot_select$select$r
          rr <- hot_to_r(input$hot)
          
          if ( is.null(linha))
          {
            return(rr[1,6])
          }
          
          if ( linha>NROW(rr))
          {
            return(rr[1,6])
          }else
          {
            return(rr[linha,6])
          }
        }
      }
      
    }
    
  }
  
  
  
  # 1.2. Preparar dados ####
  #' @section Preparar dados
  {
    
    #' @section Preparar estrutura de pastas
    { 
      path_app <- 'C:\\BiodiversityDataGateway'
      
      path_dataset <- paste0(path_app,'\\',dir_output)
      path_results <- paste0(path_app,'\\',dir_output,'\\results')
      path_results_pre_processamento <- paste0(path_app,'\\',dir_output,'\\results_pre_processamento')
      path_data <- paste0(path_app,'\\',dir_output,'\\data')
      path_bgci <- paste0(path_app,'\\data\\BGCI-Commercial-Timber-List-2014')
      path_TiposVegetacaoFB2020_IUCN <- paste0(path_app,'\\data\\TiposVegetacaoFB2020_IUCN')
      path_avaliacoes <- paste0(path_app,'\\',dir_output,'\\assessments')
      path_occ_avaliacoes <- paste0(path_app,'\\',dir_output,'\\occ_assessments')
      path_workshop <- paste0(path_app,'\\',dir_output,'\\Workshop')
      
      
      
      if(!dir.exists(path_app)){dir.create(path_app)}
      if(!dir.exists(path_dataset)){dir.create(path_dataset)}
      if(!dir.exists(path_results)){dir.create(path_results)}
      if(!dir.exists(path_results_pre_processamento)){dir.create(path_results_pre_processamento)}
      if(!dir.exists(path_data)){dir.create(path_data)}
      if(!dir.exists(path_avaliacoes)){dir.create(path_avaliacoes)}
      if(!dir.exists(path_occ_avaliacoes)){dir.create(path_occ_avaliacoes)}
      if(!dir.exists(path_workshop)){dir.create(path_workshop)}
      
      
    }
    
    #' @section Carregar lista de espécies
    {
      # nome_arquivo <- paste0("./",dir_output,"/results/planilha_acompanhamento_padrao.csv")
      nome_arquivo <- paste0(path_results_pre_processamento,"\\planilha_acompanhamento_padrao.csv")
      spp <- read.csv(nome_arquivo,
                      fileEncoding = "UTF-8") %>%
        dplyr::mutate(NameFB_semAutor = gsub('   ', ' ',NameFB_semAutor)) %>%
        arrange_at(c('FB2020_Family','FB2020_AcceptedNameUsage'))
      # arrange_at(c('FB2020_AcceptedNameUsage'))
      
      
      index <- spp$FB2020_AcceptedNameUsage==''
      sum(index!=TRUE)
      
      spp <- spp[index!=TRUE,]
      
      # ajustar no pre-processamento para ja vir assim
      spp$CITES <- ifelse(is.na(spp$CITES),'',spp$CITES)
      spp$use <- ifelse(is.na(spp$use),'',spp$use)
      
    }
    
    #' @section Buscar informações em FB2020 via IPT
    {
      
      spp <- left_join(spp %>%
                         dplyr::mutate(sppx=FB2020_AcceptedNameUsage),
                       FloraBrasil2020 %>%
                         dplyr::mutate(sppx=scientificName_FB2020),
                       by = 'sppx') %>%
        dplyr::select(-sppx)
      
      
      index <- spp$taxonRank_FB2020 %in% 'ESPECIE'
      spp <- spp[index==TRUE,]
      nrow(spp)
      
      
      familias <- spp$family_FB2020 %>% as.character()
      especies <- spp$scientificNamewithoutAuthorship_FB2020 %>% as.character()
      acceptedName <-spp$scientificName_FB2020 %>% as.character()
      
      #' @details processar nomes conforme backbone taxonômico: FB2020
      {   
        index <- acceptedName %in% FloraBrasil2020$scientificName_FB2020
        sum(index)
        print(paste0('Number of taxa: ',length(acceptedName)))
        
        synonym.file <- paste0(path_results_pre_processamento,"\\synonym.csv") 
        infrataxa.file <- paste0(path_results_pre_processamento,"\\infrataxa.csv")
        lista_especies.file <- paste0(path_results_pre_processamento,"\\lista_especies.csv")
        
        if((!file.exists(synonym.file) | !file.exists(infrataxa.file)) | overwrite==TRUE)
        {
          
          synonym <- FloraBrasil2020 %>% 
            dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                            taxonomicStatus_FB2020 == 'SINONIMO') %>%
            dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                          synonym = scientificName_FB2020) %>%
            dplyr::select(acceptedName,
                          synonym)
          
          infrataxa <- FloraBrasil2020 %>% 
            dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                            !is.na(infraspecificEpithet_FB2020)) %>%
            dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                          infrataxa = scientificName_FB2020) %>%
            dplyr::select(acceptedName,
                          infrataxa)
          
          
          synonym_withoutAuthorship <- FloraBrasil2020 %>% 
            dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                            taxonomicStatus_FB2020 == 'SINONIMO') %>%
            dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                          synonym = scientificNamewithoutAuthorship_FB2020) %>%
            dplyr::select(acceptedName,
                          synonym)
          
          infrataxa_withoutAuthorship <- FloraBrasil2020 %>% 
            dplyr::filter(acceptedNameUsage_FB2020 %in% acceptedName &
                            !is.na(infraspecificEpithet_FB2020)) %>%
            dplyr::mutate(acceptedName = acceptedNameUsage_FB2020,
                          infrataxa = scientificNamewithoutAuthorship_FB2020) %>%
            dplyr::select(acceptedName,
                          infrataxa)
          
          write.csv(synonym, synonym.file, fileEncoding = "UTF-8", na = "",
                    row.names = FALSE)
          
          write.csv(infrataxa, infrataxa.file, fileEncoding = "UTF-8", na = "",
                    row.names = FALSE)
          
          write.csv(spp, lista_especies.file, fileEncoding = "UTF-8", na = "",
                    row.names = FALSE)
        }else
        {
          synonym <- readr::read_csv(synonym.file,
                                     locale = locale(encoding = "UTF-8"),
                                     show_col_types = FALSE)
          
          infrataxa <- readr::read_csv(infrataxa.file,
                                       locale = locale(encoding = "UTF-8"),
                                       show_col_types = FALSE)
        }
      }
    }
    
    #' @section Selecionar Possíveis Lcs
    {
      
      eoo_limit_LC <- 30000
      aoo_limit_LC <- 3000
      locations_min_number_LC <- 10
      
      # ifelse( ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number)), 
      #         'Possivelmente Menos preocupante (LC)', 'Possivelmente ameaça ou dados insuficientes '), 
      
      # index <- ( ( spp$eoo > eoo_limit_LC) & ( (spp$aoo2*4) > aoo_limit_LC) & (TRUE==TRUE) )  | 
      #          ( ( spp$eoo > eoo_limit_LC) & ( (spp$aoo2*4) > aoo_limit_LC) & (spp$nusado > locations_min_number_LC) )
      
      index <- ( ( spp$eoo > eoo_limit_LC) & (spp$nusado > locations_min_number_LC) )
      
      sum(index==TRUE)
      
      spp <- spp[index==TRUE,]
      
      nrow(spp)
    }
    
    #' @section Buscar informações sobre avaliaçõe em IUCN via API
    {
      iucn.file <- paste0(path_results_pre_processamento,"\\iucn_status.csv")
      
      if((!file.exists(iucn.file)) | overwrite==TRUE)
      {
        IUCN <- {}
        restart <- 0
        i<- 1
        
        for (i in 1:NROW(spp))
        {
          
          if (i < restart) 
          { 
            print(i) 
            next
          }
          
          x <- spp$NameFB_semAutor[i] #spp$FB2020_AcceptedNameUsage[i]
          
          print( paste0(i, ' : ', x))
          if (i>restart)
          {
            IUCN <- rbind(IUCN, IUCNRedList_Check_Specie(x)$IUCNData)
          } else {
            IUCN[i,] <- IUCNRedList_Check_Specie(x)$IUCNData
          }
          
          if (!is.na(IUCN[NROW(IUCN),]$category)==TRUE) {  print(paste0('IUCN: ', IUCN[NROW(IUCN),c('category', 'criteria')]))}
        }
        
        IUCN$acceptedNameSearch <- spp$FB2020_AcceptedNameUsage
        
        # gravar dados iucn
        write.csv(IUCN, iucn.file, fileEncoding = "UTF-8", na = "",
                  row.names = FALSE)
        
      }else
      {
        IUCN <- readr::read_csv(iucn.file,
                                locale = locale(encoding = "UTF-8"),
                                show_col_types = FALSE)
      }
      
    }
    
    #' @section Buscar informações sobre uso madeireiro - BGCI-Commercial-Timber-List-2014
    {
      
      BGCI_CommercialTimber.file <- paste0(path_results_pre_processamento,"\\bgci_commercial_timber_status.csv")
      
      if((!file.exists(BGCI_CommercialTimber.file)) | overwrite==TRUE)
      {
        
        bgci_CommercialTimber <- BGCI_Commercial_Timber_Check_Specie(acceptedNameSearch=spp$scientificName_FB2020,
                                                                     path_bgci=path_bgci)
        
        # bgci_CommercialTimber <- BGCI_Commercial_Timber_Check_Specie(acceptedNameSearch=rep('Morus alba',NROW(spp)),
        #                                                              path_bgci=path_bgci)
        
        # gravar dados bgci
        write.csv(bgci_CommercialTimber$sourceResult, BGCI_CommercialTimber.file, fileEncoding = "UTF-8", na = "",
                  row.names = FALSE)
        
        write.csv(bgci_CommercialTimber$rawResult, paste0(path_results_pre_processamento,"\\bgci_commercial_timber_raw.csv"), fileEncoding = "UTF-8", na = "",
                  row.names = FALSE)
        
        bgci_CommercialTimber <- bgci_CommercialTimber$sourceResult
        
      }else
      {
        bgci_CommercialTimber <- readr::read_csv(BGCI_CommercialTimber.file,
                                                 locale = locale(encoding = "UTF-8"),
                                                 show_col_types = FALSE)
      }
    }
    
    #' @section IUCN Vegetation Type x FB2020 IPT Vegetation Type
    {
      
      #' @details Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv
      name.file <- paste0(path_TiposVegetacaoFB2020_IUCN,"\\Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv")
      TiposVegetacaoFB2020_IUCN <- readr::read_csv(name.file,
                                                   locale = locale(encoding = "UTF-8"),
                                                   show_col_types = FALSE) %>%
        dplyr::arrange_at('IUCN_HABITATS_CLASSIFICATION_SCHEME_CODE')
      
      
      #' @details arquivo resultado com os tipos de vegetacao da espécie
      vegetationType_FB2020_x_IUCN.file <- paste0(path_results_pre_processamento,"\\vegetationType_FB2020_x_IUCN.csv")
      
      
      if((!file.exists(vegetationType_FB2020_x_IUCN.file)) | overwrite==TRUE)
      {
        # source('./functions/vegetationType_FB2020_x_IUCN.R', encoding = "UTF-8")
        
        vegetationType_FB2020_x_IUCN <- get_vegetationType_FB2020_x_IUCN(acceptedNameSearch = spp$FB2020_AcceptedNameUsage,
                                                                         vegetationType_FB2020 = spp$vegetationType_FB2020,
                                                                         vegetationType.IUCN_CNCFlora_FB2020=vegetationType.IUCN_CNCFlora_FB2020,
                                                                         path.vegetationType.IUCN_CNCFlora_FB2020 = paste0(path_TiposVegetacaoFB2020_IUCN,"\\Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv"))#'./data/Tabela comparativa - Tipos de vegetacao IUCN e Flora do Brasil-30-05-2020.csv')
        
        # gravar dados bgci
        write.csv(vegetationType_FB2020_x_IUCN, vegetationType_FB2020_x_IUCN.file, fileEncoding = "UTF-8", na = "",
                  row.names = FALSE)
        
      }else
      {
        vegetationType_FB2020_x_IUCN <- readr::read_csv(vegetationType_FB2020_x_IUCN.file,
                                                        locale = locale(encoding = "UTF-8"),
                                                        show_col_types = FALSE)
      }
      
      
    }
    
    #' @section Preparar CSV base para cada espécie
    {
      
      # name.file <- paste0("./",dir_output,"/results/5_occ_selectMoreInformativeRecord.csv")
      name.file <- paste0(path_results_pre_processamento,"\\5_occ_selectMoreInformativeRecord.csv")
      
      occ_csv <- readr::read_csv(name.file,
                                 locale = locale(encoding = "UTF-8"),
                                 show_col_types = FALSE) %>%
        dplyr::mutate(Identificação=FALSE,
                      Localização=FALSE,
                      verticeEOO=FALSE,
                      # Verificar_Vertice_EOO=FALSE,
                      preValidacao='',
                      emUC=FALSE,
                      tipoUC=NA,
                      nomeUC=NA,
                      emJB=FALSE,
                      
                      # outros flags
                      Duplicação=FALSE,
                      bioma='',
                      
                      
                      .before = 1)
      
      #  ID geral
      occ_csv <- occ_csv %>%
        dplyr::mutate(ID_PRV= paste0(dir_output,'_',1:NROW(occ_csv)),
                      emUso=FALSE)
      
      
      occ_in <- in_out_cncflora(occ_csv)$occ_in %>%
        dplyr::mutate(Longitude = Ctrl_autoGeoLongitude,
                      Latitude = Ctrl_autoGeoLatitude,
                      preValidacao='in',
                      
                      Identificação=TRUE,
                      Localização=TRUE,
                      
                      emUso=TRUE)
      
      occ_out_to_recover <- in_out_cncflora(occ_csv)$occ_out_to_recover %>%
        dplyr::mutate(Longitude = Ctrl_decimalLongitude,
                      Latitude = Ctrl_decimalLatitude,
                      preValidacao='out_to_recover',
                      
                      Identificação=TRUE,
                      Localização=FALSE,
                      
                      emUso=FALSE)
      
      occ_global <- in_out_cncflora(occ_csv)$occ_global %>%
        dplyr::mutate(Longitude = Ctrl_decimalLongitude,
                      Latitude = Ctrl_decimalLatitude,
                      preValidacao='global')
      
      occ_global <- anti_join(occ_global,
                              rbind(occ_in,
                                    occ_out_to_recover),
                              by = 'ID_PRV') %>%
        dplyr::mutate(Identificação=TRUE,
                      Localização=TRUE,
                      emUso=TRUE)
      
      
      occ_out <- in_out_cncflora(occ_csv)$occ_out %>%
        dplyr::mutate(Longitude = Ctrl_decimalLongitude,
                      Latitude = Ctrl_decimalLatitude,
                      preValidacao='out',
                      emUso=FALSE)
      
      occ <- rbind(occ_out_to_recover,
                   occ_in,
                   occ_global,
                   occ_out)
      
      # preparação ou manutanção do conjutno de dados
      
      if (overwrite==TRUE)
      { file.remove(list.files(path_data, full.names = TRUE))}
      
      
      # 11-05-2022 nomo sem autor
      # path_file_csv <- paste0(path_data,'/',dir_output,' ',spp$FB2020_AcceptedNameUsage,'.csv')
      path_file_csv <- paste0(path_data,'/',dir_output,' ',spp$NameFB_semAutor,'.csv')
      
      path_file_csv <- gsub(' ', '_', path_file_csv)
      
      i=1
      for (i in 1:NROW(spp))
      {
        
        
        occ_tmp <- occ[occ$Ctrl_scientificNameReference %in% spp$FB2020_AcceptedNameUsage[i],]
        # occ_tmp <- occ %>% 
        #    dplyr::filter(Ctrl_scientificNameReference == spp$FB2020_AcceptedNameUsage[i])
        
        
        tot <- NROW(occ_tmp)
        print(paste0(path_file_csv[i], ' ',tot))
        
        if (tot>0)
        {
          if (!file.exists(path_file_csv[i]) | overwrite==TRUE)
          {
            write.csv(occ_tmp, path_file_csv[i], fileEncoding = "UTF-8", na = "", row.names = FALSE)
            print('novo conjunto de dados criado')
            
          }else
          {
            print('conjunto de dados antigo mantido')
          }   
        }
        
        
      }   
    }
    
    #' @section Preparar CSV lista de espécies e ocorrências PLC para pre-validacao de especialistas
    {
      # tabelas para pre-validacao de especialistas
      path_file_csv_especilista <- paste0(path_results_pre_processamento,'/',dir_output,' Lista especies PLC Especialistas.csv')
      write.csv(spp, path_file_csv_especilista, fileEncoding = "UTF-8", na = "", row.names = FALSE)
      
      path_file_csv_especilista <- paste0(path_results_pre_processamento,'/',dir_output,' Ocorrencias PLC Especialistas.csv')
      write.csv(occ_in, path_file_csv_especilista, fileEncoding = "UTF-8", na = "", row.names = FALSE)
    }
    
  }
  
  
  
  # 1.3. Criar tabela para salvar resultados das avaliações de risco de extinção ####
  #' @section Criar tabela para salvar resultados das avaliações de risco de extinção
  {
    
    tag.file <- paste0(path_results_pre_processamento,"\\sp_tag.csv") 
    
    file.remove(tag.file)
    
    if(!file.exists(tag.file))
    {   
      #' @details Criar tag modelo
      {
        sp_tag_tmp <- data.frame(acceptedNameSearch='',
                                 tag='',
                                 code='',
                                 label='',
                                 valueLogical=FALSE,
                                 valueNumeric=0,
                                 valueText='',
                                 valueDate='')[-1,]
        
        # TiposVegetacaoFB2020_IUCN
        {
          iv<-1
          for(iv in 1:NROW(TiposVegetacaoFB2020_IUCN))
          {
            
            
            sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch='',
                                                        tag='TiposVegetacaoFB2020_IUCN',
                                                        code=as.character(TiposVegetacaoFB2020_IUCN$IUCN_HABITATS_CLASSIFICATION_SCHEME_CODE[iv]), 
                                                        label=TiposVegetacaoFB2020_IUCN$`IUCN HABITATS CLASSIFICATION SCHEME - Version 3.1`[iv], 
                                                        
                                                        valueLogical=FALSE, 
                                                        
                                                        valueNumeric=NA, 
                                                        valueText=TiposVegetacaoFB2020_IUCN$FB_POR[iv], 
                                                        valueDate=NA)
          }
        }
        
        # plant grow forms IUCN - desligado nesta versão 16-06-2022
        {
          
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='A', 
          #                                             label='Annual', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='B', 
          #                                             label='Moss', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='C', 
          #                                             label='Cycad', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='E', 
          #                                             label='Epiphyte', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='F', 
          #                                             label='Forb or Herb', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='G', 
          #                                             label='Geophyte', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='GR', 
          #                                             label='Graminoid', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='H', 
          #                                             label='Hydrophyte', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='L', 
          #                                             label='Lithophyte', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='LC', 
          #                                             label='Lichen', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='M', 
          #                                             label='Fungus', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='P', 
          #                                             label='Parasite', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='PT', 
          #                                             label='Fern', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='S', 
          #                                             label='Shrub - size unknown', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='SA', 
          #                                             label='Succulent - annual', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='SC', 
          #                                             label='Succulent - form unknown', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='SF', 
          #                                             label='Succulent - shrub', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='SL', 
          #                                             label='Shrub - large', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='SS', 
          #                                             label='Shrub - small', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='ST', 
          #                                             label='Succulent - tree', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='T', 
          #                                             label='Tree - size unknown', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='TL', 
          #                                             label='Tree - large', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='TS', 
          #                                             label='Tree - small', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='plant_grow_forms',
          #                                             code='V', 
          #                                             label='Vines', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
        }
        
        # usos IUCN
        {

          # tipos uso iucn - desligado nesta versão 16-06-2022
          {
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='1', 
            #                                             label='Food - human', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='2', 
            #                                             label='Food - animal', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='3', 
            #                                             label='Medicine - human & veterinary', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='4', 
            #                                             label='Poisons', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='5', 
            #                                             label='Manufacturing chemicals', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='6', 
            #                                             label='Other chemicals', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='7', 
            #                                             label='Fuels', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='8', 
            #                                             label='Fibre', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='9', 
            #                                             label='Construction or structural materials', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='10', 
            #                                             label='Wearing apparel, accessories', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='11', 
            #                                             label='Other household goods', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='12', 
            #                                             label='Handicrafts, jewellery, etc.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='13', 
            #                                             label='Pets/display animals, horticulture', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='14', 
            #                                             label='Research', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='15', 
            #                                             label='Sport hunting/specimen collecting', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='16', 
            #                                             label='Establishing ex-situ production', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='17', 
            #                                             label='Other (free text)', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
            # 
            # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
            #                                             tag='iucn_use',
            #                                             code='18', 
            #                                             label='Unknown', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          }
          

          # descrição do uso geral
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='description_use',
                                                      code='', 
                                                      label='Uso', valueLogical=FALSE, valueNumeric=NA, 
                                                      valueText='', 
                                                      valueDate=NA)
          
          
          # 
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='fern_use',
                                                      code='', 
                                                      label='A espécie apresenta usos efetivos (Fern, K., 2019), contudo não atestam reduções populacionais neste momento.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # 
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='bgci_CommercialTimber_use',
                                                      code='', 
                                                      label='A madeira da espécie é usada comercialmente (Mark, et al., 2014), contudo não atesta reduções populacionais neste momento.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # 
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='cites_use',
                                                      code='', 
                                                      label='A espécie é usada comercialmente (CITES, 2019), contudo não atesta reduções populacionais neste momento.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # sem uso
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='no_use',
                                                      code='', 
                                                      label='Não existem dados sobre usos que tem o potencial de provocar redução populacional.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
        }
        
        # dados populacionais
        {
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='no_population_data',
                                                      code='', 
                                                      label='Não existem dados populacionais que atestem reduções para a espécie.', 
                                                      valueLogical=TRUE, valueNumeric=NA, valueText=NA, valueDate=NA)
        }
        
        # especificidade de habitat
        {
          # especificidade de habitat
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='habitat_specificity',
                                                      code='', 
                                                      label='A espécie possui especificidade de habitat.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
        }
        
        # possivelmente_LC
        {
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO',
                                                      code='', 
                                                      label='Valores de EOO e AOO excedem os limiares para categorias ameaçadas e não existem dados populacionais que atestem reduções para a espécie.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='possivelmente_LC_EOO_SITUACAO_AMEACA', 
                                                      code='', 
                                                      label='Valores de EOO e número de situações de ameaças excedem os limiares para categorias ameaçadas', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='categoria_LC',
                                                      code='', 
                                                      label='A espécie categorizada como LC? ', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
        }
        
        # possivelmente ameaçada
        {
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='possivelmente_ameacada',
                                                      code='', 
                                                      label='A espécie apresenta valores limítrofes para a inclusão em uma categoria de ameaça ou dados insuficientes.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          
        }
        
        # "a espécie apresenta valores limítrofes para a inclusão em uma categoria de ameaça ou dados insuficientes"
        # 'e será avaliada no fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.'
        
        # Verificação UFs mapas
        # Texto padrão e texto editável. Salvar ambos!
        
        # Flag Possivelmente Ameaçada
        # Justificativa de Possivelmente Ameaçada
        
        
        # Flag Fluxo integral 
        # Justificativa fluxo integral
        
        # Reunião alinhamento
        # checar se ha THREAT
        
        # possivelmente dd taxonomia
        # Flag potncialmente DD. Informações taxonômicas são inconclusivas para categorização de ameaça de risco de extinção!
        # Justificativa de DD
        {
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='possivelmente_dd',
                                                      code='', 
                                                      label='Possivelmente deficiente de dados (DD) - Informações taxonômicas são inconclusivas para categorização de risco de extinção.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='possivelmente_dd_justificativa',
                                                      code='', 
                                                      label='Justificativa possivelmente DD.', valueLogical=FALSE, valueNumeric=NA, 
                                                      valueText='', valueDate=NA)
          
          
          
        }
        
        
        # Flag Submeter espécie ao fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.
        # justificativa
        {
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='avaliacao_fluxo_integral',
                                                      code='', 
                                                      label='Submeter espécie ao fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
        }
        
        # sobre a espécie
        {
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                     tag='about_sp',
          #                                     code='', 
          #                                     label='A espécie sofrerá alterações taxonômincas no futuro próximo?', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='endemism_FB2020',
                                                      code='', 
                                                      label='A espécie é endêmica do Brasil.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                     tag='about_sp',
          #                                     code='', 
          #                                     label='As informações de nome popular estão corretas?', valueLogical=TRUE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                     tag='update_nome_popular_endemism_FB2020',
          #                                     code='', 
          #                                     label='Caso as informações de nome popular não estejam, e se tem algo à acrescentar, comente por favor', 
          #                                     valueLogical=NA, valueNumeric=NA, 
          #                                     valueText='', valueDate=NA)
          
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                     tag='about_sp',
          #                                     code='', 
          #                                     label='As informações sobre forma de vida estão corretas?', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          # 
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                     tag='update_forma_de_vida_endemism_FB2020',
          #                                     code='', 
          #                                     label='Caso as informações sobre forma de vida não estejam corretas e se tem algo à acrescentar, comente por favor', 
          #                                     valueLogical=NA, valueNumeric=NA, 
          #                                     valueText='', valueDate=NA)
        }
        
        # Considerações:
        #    Conhecimento da área de distribuição:
        # sua área de ocorrência relativamente bem amostrada
        {
          
          # hot_consideracoes_bem_amostrada
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='consideracoes_bem_amostrada',
                                                      code='', 
                                                      label='Sua área de ocorrência relativamente bem amostrada.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # hot_consideracoes_mal_amostrada
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='consideracoes_mal_amostrada',
                                                      code='', 
                                                      label='Sua distribuição em região pouco estudada, onde esforços de coleta ainda são necessários.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # hot_consideracoes_distribuicao_ampla
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='consideracoes_distribuicao_ampla',
                                                      code='', 
                                                      label='Sua ampla distribuição. (EOO > 30.000 km²)', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # hot_consideracoes_distribuicao_restrita
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='consideracoes_distribuicao_restrita',
                                                      code='',
                                                      label='Sua distribuição restrita. (EOO < 100 km²)', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
        }
        
        # Recomendações:
        #    Recomenda-se estudos populacionais e monitoramento da espécie para averiguar possíveis declínios e reduções.
        {
          # AVALIAR E EXCLUIR
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='recomendacoes',
          #                                             code='', 
          #                                             label='Recomenda-se estudos populacionais e monitoramento da espécie para averiguar possíveis declínios e reduções.', valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          
          # (se não tiver dados populacionais)
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='recomendacoes_acoes_de_pesquisa',
                                                      code='', 
                                                      label='Ações de pesquisa, abrangendo, busca por novas áreas de ocorrência, censo e tendências populacionais e estudos de viabilidade populacional.', 
                                                      valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # (se não ocorre em uc)
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='recomendacoes_acoes_de_conservacao',
                                                      code='', 
                                                      label='Ações de conservação in situ e ex situ.', 
                                                      valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          
          # (se ocorre em uc)
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='recomendacoes_efetividade_conservacao',
                                                      code='', 
                                                      label='Ações para cumprimento da efetividade da conservação da espécie em Unidades de Conservação e em conservação ex situ.', 
                                                      valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
          # # (complemento) # se houver recomendações
          # sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
          #                                             tag='recomendacoes_complemento',
          #                                             code='', 
          #                                             label='a fim de se garantir sua perpetuação na natureza, pois as pressões verificadas ao longo de sua distribuição podem ampliar seu risco de extinção.', 
          #                                             valueLogical=FALSE, valueNumeric=NA, valueText=NA, valueDate=NA)
          
        }
        
        
        # Avaliação
        {
          # locations e distância
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='locations',
                                                      code='', 
                                                      label='Situações de ameaças.', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='locations_distance',
                                                      code='', 
                                                      label='Distância mínima para contagem de locais (km).', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          

          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='locations2000',
                                                      code='', 
                                                      label='Situações de ameaças distantes 2 km', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)

          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='locations50000',
                                                      code='', 
                                                      label='Situações de ameaças distantes 50 km', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          
          
          
          
          # Extent of Occurrence (EOO) - Area of occupancy (AOO)
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='eoo',
                                                      code='', 
                                                      label='Extent of Occurrence (EOO)', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='aoo',
                                                      code='', 
                                                      label='Area of occupancy (AOO)', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
        }
        
        #' @details aba resultados
        {                       
          # totalUC_PI
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalUC_PI',
                                                      code='', 
                                                      label='Total de UCs PI com ocorrência da espécie', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalUC_US
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalUC_US',
                                                      code='', 
                                                      label='Total de UCs US com ocorrência da espécie', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalRegistros_emUC_PI
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalRegistros_emUC_PI',
                                                      code='', 
                                                      label='Total de registros em UCs PI', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          
          # totalRegistros_emUC_US
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalRegistros_emUC_US',
                                                      code='', 
                                                      label='Total de registros em UCs US', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          
          # totalRegistros_validados
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalRegistros_validados',
                                                      code='', 
                                                      label='Total de registros validados', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalRegistros_invalidados
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalRegistros_invalidados',
                                                      code='', 
                                                      label='Total de registros invalidados', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalRegistros_foraBrasil
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalRegistros_foraBrasil',
                                                      code='', 
                                                      label='Total de registros fora do Brasil', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalBiomasComOcorrencia
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalBiomasComOcorrencia',
                                                      code='', 
                                                      label='Total de biomas com ocorrência da espécie', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalMunicipiosComOcorrencia  
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalMunicipiosComOcorrencia',
                                                      code='', 
                                                      label='Total de municípios com ocorrência da espécie', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
          # totalEstadosComOcorrencia
          sp_tag_tmp <- sp_tag_tmp %>% dplyr::add_row(acceptedNameSearch="",
                                                      tag='totalEstadosComOcorrencia',
                                                      code='', 
                                                      label='Total de estados com ocorrência da espécie', 
                                                      valueLogical=FALSE, 
                                                      valueNumeric=0, valueText=NA, valueDate=NA)
          
        }
      }
      
      #' @details Replicar tag modelo para espécies e adicionar tipos de vegetação de cada uma
      i<-1
      sp_tag <<- {}
      for (i in 1:NROW(spp))
      {
        
        print(i)
        
        sp_tag_tmp_sp <- sp_tag_tmp
        
        sp_tag_tmp_sp$acceptedNameSearch <- spp$FB2020_AcceptedNameUsage[i]
        
        # TiposVegetacaoFB2020_IUCN
        {
          iucn_habitas_tmp <- vegetationType_FB2020_x_IUCN  %>%
            dplyr::filter(acceptedNameSearch %in% spp$FB2020_AcceptedNameUsage[i]) %>%
            dplyr::select(IUCN_Habitats_Classification_Scheme_Version_3.1,
                          vegetationType_FB2020)

          # ajuste tipo vegetação campo rupestre e area antropica 08-06-2022
          # index_tmp <- sp_tag_tmp_sp$acceptedNameSearch %in% spp$FB2020_AcceptedNameUsage[i] &
          #   sp_tag_tmp_sp$label %in% iucn_habitas_tmp$IUCN_Habitats_Classification_Scheme_Version_3.1 &
          #   sp_tag_tmp_sp$valueText %in% iucn_habitas_tmp$vegetationType_FB2020
          
          
          gsub(" ","",textclean::replace_non_ascii(toupper(vegetationType.IUCN_CNCFlora_FB2020$FB_POR)))
          index_tmp <- sp_tag_tmp_sp$acceptedNameSearch %in% spp$FB2020_AcceptedNameUsage[i] &
            gsub(" ","",textclean::replace_non_ascii(toupper(sp_tag_tmp_sp$label))) %in% gsub(" ","",textclean::replace_non_ascii(toupper(iucn_habitas_tmp$IUCN_Habitats_Classification_Scheme_Version_3.1))) &
            gsub(" ","",textclean::replace_non_ascii(toupper(sp_tag_tmp_sp$valueText))) %in% gsub(" ","",textclean::replace_non_ascii(toupper(iucn_habitas_tmp$vegetationType_FB2020)))
          
          sp_tag_tmp_sp$valueLogical[index_tmp==TRUE] <- TRUE
          
          # iv<-1
          # for(iv in 1:NROW(TiposVegetacaoFB2020_IUCN))
          # {
          #    
          #    
          #    sp_tag_tmp_sp <- sp_tag_tmp_sp %>% dplyr::add_row(acceptedNameSearch=spp$FB2020_AcceptedNameUsage[i],
          #                                                      tag='TiposVegetacaoFB2020_IUCN',
          #                                                      code=as.character(TiposVegetacaoFB2020_IUCN$IUCN_HABITATS_CLASSIFICATION_SCHEME_CODE[iv]), 
          #                                                      label=TiposVegetacaoFB2020_IUCN$`IUCN HABITATS CLASSIFICATION SCHEME - Version 3.1`[iv], 
          #                                                      
          #                                                      valueLogical=NROW(vegetationType_FB2020_x_IUCN %>%
          #                                                                           dplyr::filter(acceptedNameSearch %in% spp$FB2020_AcceptedNameUsage[i] &
          #                                                                                            IUCN_Habitats_Classification_Scheme_Version_3.1 %in% TiposVegetacaoFB2020_IUCN$`IUCN HABITATS CLASSIFICATION SCHEME - Version 3.1`[iv] &
          #                                                                                            vegetationType_FB2020_x_IUCN$vegetationType_FB2020 %in% TiposVegetacaoFB2020_IUCN$FB_POR[iv]))>0, 
          #                                                      
          #                                                      valueNumeric=NA, 
          #                                                      valueText=TiposVegetacaoFB2020_IUCN$FB_POR[iv], 
          #                                                      valueDate=NA)
          # }
          
          
        }
        
        sp_tag <<- rbind(sp_tag, sp_tag_tmp_sp)
        
        
      }
      
      write.csv(sp_tag, tag.file, fileEncoding = "UTF-8", na = "",
                row.names = FALSE)
      
    }else
    {
      sp_tag <<- read.csv(tag.file,
                          fileEncoding = "UTF-8") 
    }
    
  }
  

  
  # 1.4. Criar estrutura do aplicativo ####
  #' @section Criar estrutura do aplicativo
  {
    #' @details Criar variáveis globais
    ultima_linha <<- 0
    # sp_selected <<- ""
    textoUso <<-"texto uso"
    textoDescricaoEspecie <<- 'texto avaliação'
    textoPossivelmente_dd_justificativa <<- ''
    status_avalacaoSalvar <<- FALSE
    # status_avaliacao_csv <<- {}
    
    #' @section Tela APP
    ui <- {dashboardPage(
      dashboardHeader(title = "CNCFlora/JBRJ"),
      dashboardSidebar(width = 350,
                       
                       box(status = "primary", width = 12,
                           title = 'Lista de espécies', background = 'navy', # red, yellow, aqua, blue, light-blue, green, navy, teal, olive, lime, orange, fuchsia, purple, maroon, black.
                           selectInput("sp", label = 'Selecione uma espécie:',choices = spp$FB2020_AcceptedNameUsage),
                           actionButton("selectBtn", "Selecionar espécie", icon = icon("play")),
                       ),
                       
                       box(status = "primary", width = 12, background = 'navy', 
                           title = 'Conectividade com internet',
                           
                           selectInput("onlineBtn", 
                                       label = 'Utilizar conexão com a internet ? ',
                                       choices = c('Sim','Não'), 
                                       selected = 'Sim'),
                           
                           selectInput('viewLimitsOff', 
                                       label = 'Quando sem conexão com  a internet, exibir: ',
                                       choices = c('Somente pontos e EOO',
                                                   'Brasil',
                                                   'Estados',
                                                   'Municípios'), 
                                       selected = 'Brasil')
                       )
      ),
      
      dashboardBody(
        # shinyUI({
        # fluidPage(
        #    theme = shinytheme('cerulean'),
        #           
        # titlePanel("PRC - Plant Records Checker"),
        navbarPage("Biodiversity Data Gateway - FERRAMENTA DE PROCESSAMENTO E GERAÇÃO DE DADOS PARA O SISTEMA PROFLORA",
                   
                   # home
                   tabPanel(icon("leaf"), 
                            box(title = "Informações sobre a espécie",
                                status = "primary",
                                width = 12,
                                
                                fluidPage(
                                  
                                  # wellPanel(
                                  #   fluidRow(
                                  #     # helpText('Estado da avaliação'),
                                  #     column(width = 12,
                                  #            valueBoxOutput("status_avalacaoBox", width = 12), 
                                  #     ))),
                                  
                                  tags$a('Conforme ',href="http://floradobrasil.jbrj.gov.br/reflora/listaBrasil/ConsultaPublicaUC/ConsultaPublicaUC.do#CondicaoTaxonCP", #href="http://floradobrasil.jbrj.gov.br/", 
                                         "Flora e Funga do Brasil. Jardim Botânico do Rio de Janeiro."),
                                  
                                  wellPanel(
                                    
                                    fluidRow(
                                      column(width = 3,
                                             valueBoxOutput("id_FB2020Box",
                                                            width = 12)), 
                                      
                                      column(width = 9,
                                             valueBoxOutput("scientificName_FB2020Box",
                                                            width = 12))
                                      
                                    ),
                                    fluidRow(
                                      
                                      column(width = 12,
                                             valueBoxOutput("group_FB2020Box",
                                                            width = 12)), 
                                      column(width = 12,
                                             valueBoxOutput("family_FB2020Box",
                                                            width = 12)), 
                                      column(width = 12,
                                             valueBoxOutput("taxonRank_FB2020Box",
                                                            width = 12)), 
                                      column(width = 12,
                                             valueBoxOutput("taxonomicStatus_FB2020Box",
                                                            width = 12)), 
                                      column(width = 12,
                                             valueBoxOutput("nomenclaturalStatus_FB2020Box",
                                                            width = 12)), 
                                      column(width = 6,
                                             valueBoxOutput("establishmentMeans_FB2020Box",
                                                            width = 12)),
                                      column(width = 6,
                                             valueBoxOutput("endemism_FB2020Box",
                                                            width = 12)),
                                      
                                      column(width = 12,
                                             valueBoxOutput("lifeForm_FB2020Box",
                                                            width = 12)), 
                                      
                                      column(width = 12,
                                             valueBoxOutput("habitat_FB2020Box",
                                                            width = 12))),
                                    
                                    helpText('Infrataxas e Sinônimos'),
                                    wellPanel(
                                      fluidRow(  
                                        column(width = 6,
                                               DT::dataTableOutput("table_infrataxa")),
                                        column(width = 6,
                                               DT::dataTableOutput("table_synonym")))),
                                    
                                    helpText('Estado da última avaliação em IUCN'),
                                    wellPanel(
                                      fluidRow(
                                        column(width = 12, 
                                               DT::dataTableOutput("table_IUCN")
                                               # DT::dataTableOutput("table_bgci_CommercialTimber"),
                                        ))),
                                    
                                    
                                  )))),
                   
                   # mapa
                   tabPanel(icon("map"), 
                            box(title = "Mapa para validação de registros de ocorrência da espécie",
                                status = "primary",
                                width = 12,
                                
                                # fluidRow(column(width = 12,
                                #                 helpText(sp_selected))),
                                
                                fluidRow(
                                  column(width = 8,
                                         
                                         # helpText("Mapa geral"),
                                         leafletOutput("map", width = "100%", height = "550px"),
                                         br(),
                                         wellPanel(
                                           rHandsontableOutput("hot_reg"),
                                           # verbatimTextOutput('mapBtn'),
                                           br(),
                                           actionButton("saveBtn_map", "Salvar alterações", icon = icon("database")), 
                                           actionButton("updateBtn", "Recalcular", onclick = 'Shiny.onInputChange(\"selectBtn\",  Math.random())',
                                                        icon = icon("calculator")))),
                                  
                                  column(width = 4,
                                         
                                         helpText("Informações sobre o registro selecionado"),
                                         tabsetPanel(
                                           tabPanel("Detalhes", DT::dataTableOutput("table_selected_map_detalhe")),
                                           tabPanel("Ficha Herbário", DT::dataTableOutput("table_selected_map")),
                                           # tabPanel("Informação Interpretada", DT::dataTableOutput("table_selected_map_comparar")),
                                           tabPanel("Duplicatas", DT::dataTableOutput("table_selected_map_duplicate"))#DT::dataTableOutput("table_selected_map_comparar")),
                                         ))),
                                
                                helpText("Categorização de ameaça:"),
                                wellPanel(
                                  fluidRow(
                                    column(width = 6,
                                           valueBoxOutput("locations_map_Box", width = 12)),
                                    
                                    column(width = 6,
                                           valueBoxOutput("eoo_map_Box", width = 12))))
                                
                            )),

                   
                   # tabela
                   
                   tabPanel(icon("list-alt"), 
                            box(title = "Tabela para validação de registros de ocorrência da espécie",
                                status = "primary",
                                width = 12,
                                
                                # fluidRow(column(width = 12, helpText(sp_selected))),
                                
                                fluidRow(
                                  column(width = 4,
                                         helpText("Tabela para seleção/validação de registro"),
                                         rHandsontableOutput("hot"),
                                         br(),
                                         wellPanel(
                                           actionButton("saveBtn", "Salvar alterações", icon = icon("database")), 
                                           actionButton("updateBtn", "Recalcular", onclick = 'Shiny.onInputChange(\"selectBtn\",  Math.random())',
                                                        icon = icon("calculator"))
                                           ),
                                         
                                         br(),
                                         verbatimTextOutput('selected')
                                         ),
                                  
                                  column(width = 4,
                                         helpText("Mapa de localização do registro selecionado"),
                                         div(leafletOutput("map_reg", width = "100%", height = "500px")),
                                         br(),
                                         sliderInput("zoom_map", "Fixar Zoom em:",
                                                     1, 16, 6, step = 1,
                                                     width = 200)),
                                  
                                  column(width = 4,
                                         helpText("Informações sobre o registro selecionado"),
                                         tabsetPanel(
                                           tabPanel("Detalhes", DT::dataTableOutput("table_selected_detalhe")),
                                           tabPanel("Ficha Herbário", DT::dataTableOutput("table_selected")),
                                           tabPanel("Duplicatas", DT::dataTableOutput("table_selected_duplicate"))))),
                                
                                helpText("Categorização de ameaça:"),
                                wellPanel(
                                fluidRow(
                                  column(width = 6,
                                         valueBoxOutput("locations_tab_Box", width = 12)),
                                  
                                  column(width = 6,
                                         valueBoxOutput("eoo_tab_Box", width = 12))))
                                
                                )),
                   
                   
                   # resultados
                   
                   tabPanel(icon('bar-chart-o'), 
                            box(title = "Resultados da verificação de registros de ocorrência",
                                status = "primary",
                                width = 12,
                                
                                fluidPage(
                                  
                                  # fluidRow(column(width = 12, helpText(sp_selected))),
                                  
                                  helpText("Número de amostras coletadas por ano"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12, align="center",
                                             plotOutput("serie_coleta")))),
                                  
                                  helpText("Número de registros"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 4,
                                             valueBoxOutput("nregBox", width = 12),
                                             br(),
                                             sliderInput("nreg_limit", "", 0, 1000, 30, step = 1)), # Number of records < 30
                                      
                                      column(width = 4, 
                                             valueBoxOutput("nreg_invalidadosBox", width = 12)),
                                      
                                      column(width = 4, 
                                             valueBoxOutput("nreg_globalBox", width = 12)))),
                                  
                                  # hábitats
                                  helpText("Número de amostras por Bioma no Brasil e comparação com informações da Flora do Brasil"),
                                  # biomas
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12,
                                             valueBoxOutput("biomeBox", width = 12))),
                                    
                                    fluidRow(
                                      column(width = 12,
                                             DT::dataTableOutput("table_bioma"))),
                                    
                                    fluidRow(
                                      column(width = 12,
                                             br(),
                                             br(),
                                             valueBoxOutput('biomeFB2020Box', width = 12)))),
                                  
                                  helpText('Tipos de vegetação documentados na Flora do Brasil e sua correspondência em IUCN habitats classification scheme - Version 3.1'),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12, 
                                             # DT::dataTableOutput("table_IUCN"),
                                             # DT::dataTableOutput("table_bgci_CommercialTimber"),
                                             DT::dataTableOutput("table_vegetationType_FB2020_x_IUCN")
                                      )))),
                                
                                helpText("Número de amostras em Unidades de Conservação no Brasil (excluindo pontos sobre centroides e coletas anteriores à 1972)"),
                                wellPanel(
                                  fluidRow(
                                    column(width = 6,
                                           helpText("Uniade de Proteção Integral"),
                                           valueBoxOutput("nreg_emUC_PIBox", width = 12),
                                           valueBoxOutput("nUC_PIBox", width = 12)), 
                                    
                                    column(width = 6,
                                           helpText("Uniade de Uso Sustentável"),
                                           valueBoxOutput("nreg_emUC_USBox", width = 12),
                                           valueBoxOutput("nUC_USBox", width = 12))),
                                  
                                  fluidRow(
                                    column(width = 6,
                                           DT::dataTableOutput("table_uc_PI")),
                                    column(width = 6,
                                           DT::dataTableOutput("table_uc_US")))),
                                
                                
                                # UFs e municipios
                                helpText("Número de amostras por Estados e Municípios no Brasil e comparação com informações da Flora do Brasil"),
                                wellPanel(
                                  fluidRow(
                                    column(width = 6,
                                           helpText("Estados"),
                                           valueBoxOutput("estadoBox", width = 12),
                                    ), 
                                    column(width = 6,
                                           helpText("Municípios"),
                                           valueBoxOutput("regionsBox", width = 12))),
                                  
                                  
                                  fluidRow(  
                                    column(width = 6,
                                           DT::dataTableOutput("table_estado")), 
                                    
                                    column(width = 6,
                                           DT::dataTableOutput("table_municipio"))),
                                  
                                  fluidRow(
                                    column(width = 12,
                                           br(),
                                           br(),
                                           valueBoxOutput('estadoFB2020Box', width = 12))))
                                
                            )),
                   
                   
                   # avaliação
                   
                   tabPanel(icon("clipboard-check" ),#"check-double"), 
                            box(title = "Painel para avaliação de risco de extinção para espécies possivelmente em categoria Menos Preocupante (LC)",
                                status = "primary",
                                width = 12,
                                fluidPage(
                                  
                                  helpText("Extent of Occurrence (EOO) - Area of occupancy (AOO)"),
                                  wellPanel(
                                    fluidRow(
                                      
                                      # Extent of Occurrence (EOO) < 30000 # Espécies amazônicas, 20000 
                                      helpText("Brasil"),
                                      column(width = 6,
                                             valueBoxOutput("eooBox", width = 12),
                                             br(),
                                             sliderInput("eoo_limit", "", 0, 100000, 30000, step = 100)), 
                                      
                                      # Area of occupancy (AOO) < 3000
                                      column(width = 6,
                                             valueBoxOutput("aooBox", width = 12),
                                             br(),
                                             sliderInput("aoo_limit", "", 0, 10000, 3000, step = 100)),
                                      
                                    )),
                                  
                                  
                                  
                                  helpText("Situações de ameaças"),
                                  wellPanel(
                                    
                                    fluidRow(
                                      
                                      column(width = 3,
                                             box(status = "primary", width = 12,
                                                 # title = 'Distância mínima para contagem de locais (km)',
                                                 sliderInput("locations_distance", "Distância mínima para contagem de locations (km)", 1, 50, 20, step = 1), # escolher a distância entre locations
                                                 actionButton("updateBtn", "Recalcular número de locations", onclick = 'Shiny.onInputChange(\"selectBtn\",  Math.random())',
                                                              icon = icon("calculator")),
                                             ),
                                      ),
                                      
                                      column(width = 3,
                                             valueBoxOutput("locationsBox", width = 12),
                                             br(),
                                             sliderInput("locations_min_number", "Número mínimo de locations para LC: ", 1, 100, 10, step = 1)),
                                      
                                      column(width = 3,
                                             valueBoxOutput("locations2000Box", width = 12)),
                                      
                                      column(width = 3,
                                             valueBoxOutput("locations50000Box", width = 12)),
                                      
                                      
                                    )),
                                  
                                  
                                  
                                  helpText("Especificidade de habitat:"),
                                  wellPanel(
                                    fluidRow(
                                      # helpText("No Use"),
                                      column(width = 12,
                                             rHandsontableOutput("hot_habitat_specificity")) 
                                    )),
                                  
                                  
                                  
                                  wellPanel(   
                                    fluidRow(
                                      column(width = 12,
                                             textAreaInput("texto_iucn_description_use", "Descrição uso", textoUso,#textoUso,
                                                           width = "100%",
                                                           height = '50px')),
                                      actionButton("textoUsoBtn", "Montar texto sobre usos", icon = icon("list-alt")),
                                      verbatimTextOutput("text_uso")    
                                    )),
                                  
                                  
                                  
                                  helpText("Endemismo no Brasil:"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12,
                                             rHandsontableOutput("hot_endemism_FB2020"))
                                  )),
                                  
                                  
                                  helpText("Conhecimento da área de distribuição:"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12,
                                             rHandsontableOutput("hot_consideracoes_bem_amostrada"), 
                                             
                                             helpText("ou"),
                                             
                                             rHandsontableOutput("hot_consideracoes_mal_amostrada"))
                                    )),
                                  
                                  
                                  
                                  wellPanel(
                                    helpText("Recomendações:"),
                                    fluidRow(
                                      column(width = 12,
                                             rHandsontableOutput("hot_recomendacoes_acoes_de_pesquisa")),
                                      
                                      column(width = 12,
                                             rHandsontableOutput("hot_recomendacoes_acoes_de_conservacao")),
                                      
                                      column(width = 12,
                                             rHandsontableOutput("hot_recomendacoes_efetividade_conservacao"))
                                      
                                      # column(width = 12,
                                      #        rHandsontableOutput("hot_recomendacoes_complemento"))
                                      
                                    )
                                  ),
                                  
                                  
                                  helpText("Texto resumo sobre a espécie"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12,
                                             
                                             helpText("Texto modelo para avaliação de risco de extinção"),
                                             invisible(verbatimTextOutput("text_DescricaoEspecie")),
                                             # verbatimTextOutput("text_DescricaoEspecie"),
                                             
                                             textAreaInput("texto_DescricaoEspecie", "Avaliação de risco de extinção:", textoDescricaoEspecie,#textoUso,
                                                           width = "100%",
                                                           height = '200px'),
                                             actionButton("textoDescricaoEspecieBtn", "Atualizar texto avaliação de risco de extinção", icon = icon("list-alt")),
                                      )
                                      
                                    )),
                                  
                                  
                                  
                                  helpText("Fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12,
                                             rHandsontableOutput("hot_avaliacao_fluxo_integral")       
                                      ))),
                                  
                                  
                                  helpText("Salvar avaliação"),
                                  wellPanel(
                                    fluidRow(
                                      column(width = 12,
                                             actionButton("salvarAvaliacaoEspecieBtn", "Salvar avaliação", icon = icon("save")
                                             ))),
                                    
                                    br(),
                                    br(),
                                    
                                    fluidRow(
                                      column(width = 12,
                                             valueBoxOutput("possivelmente_LCBox", width = 12))
                                    ),
                                    
                                  ),
                                  

                                  box(title='Detalhamento de informações:',
                                      collapsible = TRUE,
                                      collapsed = FALSE,
                                      width = 12,
                                      
                                      
                                      
                                      wellPanel(
                                        helpText("Categorização de ameaça:"),
                                        helpText("EOO, dados populacionais, situações de ameaças"), #( sem AOO)
                                        fluidRow(
                                          column(width = 12,
                                                 rHandsontableOutput("hot_possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO"),
                                                 rHandsontableOutput("hot_possivelmente_LC_EOO_SITUACAO_AMEACA"),
                                                 rHandsontableOutput("hot_possivelmente_ameacada"))
                                        )),
                                      
                                      

                                      
                                      helpText("Dados populacionais:"),
                                      wellPanel(
                                        fluidRow(
                                          column(width = 12,
                                                 rHandsontableOutput("hot_no_population_data")
                                          ))
                                      ),
                                      
                                      
                                      
                                      
                                      helpText("Amplitude de distribuição:"),
                                      wellPanel(
                                        fluidRow(
                                          column(width = 12,
                                                 rHandsontableOutput("hot_consideracoes_distribuicao_ampla"))
                                        ),
                                        fluidRow(
                                          column(width = 12,
                                                 helpText("ou"))
                                        ),
                                        
                                        fluidRow(
                                          column(width = 12,
                                                 rHandsontableOutput("hot_consideracoes_distribuicao_restrita"))
                                        ),
                                        
                                      ),
                                      
                                      
                                      
                                      
                                      helpText("Tipos de vegetação documentados na Flora do Brasil e sua correspondência em IUCN habitats classification scheme - Version 3.1:"),
                                      wellPanel(
                                        
                                        fluidRow(
                                          column(width = 12,
                                                 rHandsontableOutput("hot_TiposVegetacaoFB2020_IUCN"))
                                        )
                                      ),
                                      
                                      # desligado nesta versão 16-06-2022
                                      
                                      # helpText("Formas de crescimento para CSV IUCN - "),
                                      # wellPanel(
                                      #   
                                      #   fluidRow(
                                      #     column(width = 12,
                                      #            rHandsontableOutput("hot_plant_grow_forms"))
                                      #   )
                                      # ),
                                      
                                      
                                  ),
                                  
                                  box(title='Usos:',
                                      collapsible = TRUE,
                                      collapsed = FALSE,
                                      width = 12,
                                      
                                      wellPanel(
                                        fluidRow(
                                          helpText("Sem uso:"),
                                          column(width = 12,
                                                 # valueBoxOutput("no_useBox", width = 12),
                                                 rHandsontableOutput("hot_no_use"))
                                        )),
                                      
                                      wellPanel(
                                        fluidRow(
                                          helpText("Informações em Useful Tropical Plants Database:"),
                                          
                                          column(width = 12,
                                                 valueBoxOutput("useBox", width = 12),
                                                 rHandsontableOutput("hot_fern_use"))
                                        )),
                                      
                                      wellPanel(
                                        fluidRow(
                                          column(width = 12,
                                                 helpText('Informações em The International Timber Trade: A Working List of Commercial Timber Tree Species:'),
                                                 # DT::dataTableOutput("table_bgci_CommercialTimber"),
                                                 valueBoxOutput("bgci_CommercialTimberBox", width = 12),
                                                 
                                                 rHandsontableOutput("hot_bgci_CommercialTimber"))
                                        )),
                                      
                                      wellPanel(
                                        fluidRow(
                                          helpText("Informações em Convention on International Trade in Endangered Species of Wild Fauna and Flora:"),
                                          column(width = 12,
                                                 valueBoxOutput("cites_anexoIIBox", width = 12),
                                                 rHandsontableOutput("hot_cites_use"))
                                        ))
                                      
                                      # desligado nesta versão 16-06-2022
                                      
                                      # wellPanel(
                                      #   fluidRow(
                                      #     helpText("Usos para CSV IUCN - General Use and Trade Classification Scheme"),
                                      #     
                                      #     column(width = 12,
                                      #            rHandsontableOutput("hot_iucn_use"))
                                      #   ))
                                      
                                  ),
                                  
                                  
                                  box(title='Possivelmente DD - informações taxonômicas inconclusivas:',
                                      collapsible = TRUE,
                                      collapsed = FALSE,
                                      width = 12,
                                      
                                      wellPanel(
                                        fluidRow(
                                          column(width = 12,
                                                 rHandsontableOutput("hot_possivelmente_dd"),
                                                 
                                                 helpText("Justificativa:"),
                                                 
                                                 textAreaInput("texto_possivelmente_dd_justificativa", "Texto justificativa possivelmente DD:", textoPossivelmente_dd_justificativa,#textoUso,
                                                               width = "100%",
                                                               height = '50px')
                                          ))),
                                  ),
                                )))
        ))
      # }
    )}
    
    #' @section Servidor APP
    server <- function(input, output, session){
      
      # status avaliação
      status_avalacao <- function()
      {
        binomio <- paste0(word(input$sp,1), '_',word(input$sp,2))
        
        fil <- list.files(path_avaliacoes, full.names = TRUE)
        # index_f <- grep(gsub(' ', '_', 'Andira cordata'),fil)
        
        index_f <- grep(gsub(' ', '_', binomio),fil)               
        # csv_result <- NULL
        
        if(NROW(index_f)>0)
        {
          # fil.inf <- file.info(fil[index_f])
          # index <- fil.inf$mtime == max(fil.inf$mtime)
          # 
          # # index_remove <- fil.inf$mtime != max(fil.inf$mtime)
          # # file.remove(fil[index_f][index_remove==TRUE])
          # 
          # csv_result <- fil[index_f][index==TRUE]
          # 
          # status_avaliacao_csv <<- list(status_avaliacao=TRUE,
          #                               file_info=file.info(csv_result))
          
          # updateSelectInput(session = session, inputId = "sp", selected = sp_selected)
          
          return(TRUE)
          
        }else{
          # status_avaliacao_csv <<- list(status_avaliacao=FALSE,
          #                               file_info=NA)
          # updateSelectInput(session = session, inputId = "sp", selected = sp_selected)
          
          return(FALSE)
        }
        
        
      }
      
      
      # calculos
      data_sel <- eventReactive(input$selectBtn, 
                                {
                                  
                                  # status_avalacaoSalvar <<- status_avalacao()
                                  

                                  # input$hot_fern_use$valueLogical[1] <- FALSE
                                  # input$hot_bgci_CommercialTimber$valueLogical[1] <- FALSE
                                  # 
                                  # input$hot_cites_use$valueLogical[1] <- FALSE
                                  # 
                                  # input$hot_no_use$valueLogical[1] <- FALSE
                                  
                                  # # sp_tag$valueText[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='description_use'] <- monta_texto_uso(input)
                                  
                                  # atualizar aqui se necessário
                                  textoUso <<- ""
                                  
                                  updateTextAreaInput(session, "texto_iucn_description_use", value = textoUso)
                                  
                                  # atualizar aqui se necessário
                                  textoDescricaoEspecie <<- ""
                                  updateTextAreaInput(session, "texto_DescricaoEspecie", value = textoDescricaoEspecie)
                                  
                                  
                                  data_of_click$clickedMarker <- NULL
                                  
                                  # sp_selected <<- input$sp

                                  
                                  binomio <- paste0(word(input$sp,1), '_',word(input$sp,2))
                                  # binomio <- "Adesmia_araujoi"

                                  # tmp_file <- "C:\\BiodiversityDataGateway\\Pentaphylacaceae\\data\\Pentaphylacaceae_Freziera_atlantica_Zorzan._&_Amorim.csv"
                                  tmp_file <- paste0(path_data,'\\',dir_output,'_',gsub(' ', '_', binomio),'.csv')
                                  print(tmp_file)
                                  occ_tmp <- read_csv(tmp_file, locale = locale(encoding = "UTF-8"), na = '')
                                  
                                  occ_tmp <- occ_tmp %>%
                                    dplyr::arrange_at('ID_PRV')
                                  
                                  
                                  # nome arquivo csv de ocorrencias
                                  fil <- list.files(path_results,full.names = TRUE)
                                  # index_f <- grep('Freziera_atlantica_Zorzan._&_Amorim',fil)
                                  
                                  index_f <- grep(gsub(' ', '_', binomio),fil)               
                                  csv_result <- NULL
                                  
                                  if (NROW(index_f)>0)
                                  {
                                    fil.inf <- file.info(fil[index_f])
                                    index <- fil.inf$mtime == max(fil.inf$mtime)
                                    
                                    index_remove <- fil.inf$mtime != max(fil.inf$mtime)
                                    file.remove(fil[index_f][index_remove==TRUE])
                                    
                                    csv_result <- fil[index_f][index==TRUE]
                                    x <- read_csv(csv_result, locale = locale(encoding = "UTF-8"), na = '')
                                    x <- x %>%
                                      dplyr::arrange_at('ID_PRV')
                                    
                                    occ_tmp$Identificação[occ_tmp$preValidacao %in% c('in')] <- x$Identificação
                                    occ_tmp$Localização[occ_tmp$preValidacao %in% c('in')] <- x$Localização
                                    # occ_tmp$Verificar_Vertice_EOO[occ_tmp$preValidacao %in% c('in')] <- x$Verificar_Vertice_EOO
                                    occ_tmp$Latitude[occ_tmp$preValidacao %in% c('in')] <- x$Latitude
                                    occ_tmp$Longitude[occ_tmp$preValidacao %in% c('in')] <- x$Longitude
                                  }
                                  
                                  
                                  if (status_avalacao()==TRUE)
                                  {
                                    showModal(modalDialog(
                                      title = "ALERTA",
                                      paste0('Espécie já avaliada!'),
                                      easyClose = TRUE,
                                      footer = NULL
                                    ))
                                  }
                                  
                                  
                                  return(dados_(input, occ_tmp))
                                }, ignoreNULL = FALSE)
      
      
      
      observeEvent(input$salvarAvaliacaoEspecieBtn,
                   {
                     
                     #' @details  recupera dados
                     dt <- data_sel()
                     
                     # sp_selected <- "Algernonia gibbosa (Pax & K.Hoffm.) Emmerich"
                     sp_selected <- input$sp
                     
                     #' @details  gerar nome arquivo csv de avaliacao
                     binomio <- paste0(word(sp_selected,1), '_',word(sp_selected,2))
                     
                     # binomio <- 'Adesmia_araujoi' 
                     # salvar copia de csv de ocorrencias
                     {
                       fil <- list.files(path_results,full.names = TRUE)
                       fil.name <- list.files(path_results,full.names = FALSE)
                       # index_f <- grep(gsub(' ', '_', binomio),fil)               
                       index_f <- grep(binomio,fil)               
                       if (NROW(index_f)>0)
                       {
                         fil.inf <- file.info(fil[index_f])
                         index <- fil.inf$mtime == max(fil.inf$mtime)
                         csv_result <- fil[index_f][index==TRUE]
                         csv_result_file <- fil.name[index_f][index==TRUE]
                         
                         csv_result_avaliacao <- paste0(path_occ_avaliacoes,'\\',fil.name[index_f][index==TRUE])
                         file.copy(csv_result, csv_result_avaliacao, overwrite=TRUE)
                         
                         #' @details ocorrencias completo processado pelo app
                         
                         csv_occ_in <- paste0(path_occ_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_occ_in.csv')
                         write.csv(dt$occ_in_sel,
                                   csv_occ_in,
                                   fileEncoding = "UTF-8",
                                   na = "",
                                   row.names = FALSE)
                         
                         
                         csv_occ_global <- paste0(path_occ_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_occ_foraBR.csv')
                         write.csv(dt$occ_global_sel,
                                   csv_occ_global,
                                   fileEncoding = "UTF-8",
                                   na = "",
                                   row.names = FALSE)
                         
                         
                         csv_occ_out_to_recover <- paste0(path_occ_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_occ_out_to_recover.csv')
                         write.csv(dt$occ_out_to_recover_sel,
                                   csv_occ_out_to_recover,
                                   fileEncoding = "UTF-8",
                                   na = "",
                                   row.names = FALSE)
                         
                         # aquivo para sumario
                         # 09-06-22
                         # Fabaceae - Mimosa scabrella.txt
                         {
                           familia <- spp$family_FB2020[spp$FB2020_AcceptedNameUsage == sp_selected] %>% as.character()
                           
                           # file.summary <- paste0(path_workshop, '\\',familia, ' - ',word(sp_selected,1), ' ',word(sp_selected,2), '.txt' )
                           file.summary <- paste0(path_workshop, '\\',familia, ' - ', binomio, '.txt' )
                           
                           
                           # print(file.summary)
                           
                           # file.summary <- paste0(path_workshop, '\\', 'aaa - teste.txt' )
                           
                           write.csv({},
                                     file.summary)
                         }
                         
                         
                       }else{
                         showModal(modalDialog(
                           title = "Alerta",
                           'A avaliação ainda não pode ser salva!
               Por favor, utilize o botão "Salvar alterações" na aba 3, ao menos uma vez, para salvar o conjunto de ocorrências validadas antes de salvar a avaliação!',
                           easyClose = TRUE,
                           footer = NULL
                         ))
                         return()
                       }
                       
                       
                     }
                     
                     
                     #' @details  dados sp para colsultas sql
                     occ_in_sel_tmp <- dt$occ_in_sel
                     
                     index_sp <- sp_tag$acceptedNameSearch %in% sp_selected 
                    
                     #' @details atualizar aba resultados
                     {
                       
                       
                       #' @details Extent of Occurrence (EOO)
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalRegistros_validados'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$totalRegistros_in
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalRegistros_invalidados'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$totalRegistros_invalidados
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalRegistros_foraBrasil'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$totalRegistros_global
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalBiomasComOcorrencia'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$n_biomas
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalMunicipiosComOcorrencia'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$regions
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalEstadosComOcorrencia'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$n_estados

                                              
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalRegistros_emUC_PI'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$nreg_emUC_PI

                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalRegistros_emUC_US'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$nreg_emUC_US
                       

                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalUC_PI'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$nUC_PI
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='totalUC_US'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$nUC_US
                       
                       # salvar tabelas
                       #' @details table_bioma
                       csv_biomas <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_biomas.csv')
                       write.csv(dt$biomas_names,
                                 csv_biomas,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       
                       #' @details table_municipio
                       csv_municipios <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_municipios.csv')
                       write.csv(dt$regions_names,
                                 csv_municipios,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       
                       #' @details table_estado
                       csv_estadas <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_estados.csv')
                       write.csv(dt$estados_names,
                                 csv_estadas,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       #' @details table_uc_PI
                       csv_uc_PI <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_uc_PI.csv')
                       write.csv(dt$uc_names_PI,
                                 csv_uc_PI,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       
                       #' @details table_uc_US
                       csv_uc_US <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_uc_US.csv')
                       write.csv(dt$uc_names_US,
                                 csv_uc_US,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       
                       #' @details serie_coleta
                       csv_uc_US <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_serie_coleta.csv')
                       write.csv(dt$serie_coleta,
                                 csv_uc_US,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       
                   }
                     
                     
                     #' @details atualizar tags avaliação
                     {
                       
                       #' @details Extent of Occurrence (EOO)
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='eoo'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$EOO_area
                       
                       
                       #' @details Area of occupancy (AOO)
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='aoo'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$AOO2
                       
                       
                       #' @details Situações de ameaça
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='locations'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$locations_number
                       
                       
                       #' @details Distância entre situações de ameaça
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='locations_distance'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- input$locations_distance
                       
                       
                       #' @details Distância entre situações de ameaça 2 km
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='locations2000'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$locations_number2000
                       
                       
                       #' @details Distância entre situações de ameaça 50 km
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='locations50000'
                       sp_tag$valueNumeric[index_tag==TRUE] <<- dt$locations_number50000
                       
                       
                       #' @details habitat_specificity
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='habitat_specificity'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_habitat_specificity)$valueLogical
                       
                       
                       #' @details description_use
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='description_use'
                       sp_tag$valueText[index_tag==TRUE] <<- input$texto_iucn_description_use
                       
                       
                       #' @details fern_use
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='fern_use'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_fern_use)$valueLogical
                       
                       
                       #' @details bgci_CommercialTimber_use
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='bgci_CommercialTimber_use'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_bgci_CommercialTimber)$valueLogical
                       
                       
                       #' @details cites_use
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='cites_use'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_cites_use)$valueLogical
                       
                       
                       #' @details no_use
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='no_use'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_no_use)$valueLogical
                       
                       
                       #' @description endemism_FB2020
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='endemism_FB2020'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_endemism_FB2020)$valueLogical
                       
                       
                       #' @description Conhecimento da área de distribuição
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='consideracoes_bem_amostrada'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_consideracoes_bem_amostrada)$valueLogical
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='consideracoes_mal_amostrada'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_consideracoes_mal_amostrada)$valueLogical
                       
                       
                       #' @details Recomendações
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='recomendacoes_acoes_de_pesquisa'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_recomendacoes_acoes_de_pesquisa)$valueLogical
                       
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='recomendacoes_acoes_de_conservacao'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_recomendacoes_acoes_de_conservacao)$valueLogical
                       
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='recomendacoes_efetividade_conservacao'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_recomendacoes_efetividade_conservacao)$valueLogical
                       
                       
                       #' @details hot_avaliacao_fluxo_integral
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='avaliacao_fluxo_integral'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_avaliacao_fluxo_integral)$valueLogical
                       
                       
                       #' @details Categorização de ameaça
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO)$valueLogical
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='possivelmente_LC_EOO_SITUACAO_AMEACA'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_possivelmente_LC_EOO_SITUACAO_AMEACA)$valueLogical
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='possivelmente_ameacada'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_possivelmente_ameacada)$valueLogical
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='categoria_LC'
                       sp_tag$valueLogical[index_tag==TRUE] <<- dt$categoria_LC
                       
                       
                       #' @details Dados populacionais
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='no_population_data'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_no_population_data)$valueLogical %>% as.logical()
                       
                       
                       #' @details Amplitude de distribuição
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='consideracoes_distribuicao_ampla'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_consideracoes_distribuicao_ampla)$valueLogical
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='consideracoes_distribuicao_restrita'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_consideracoes_distribuicao_restrita)$valueLogical

                       
                       #' @details hot_TiposVegetacaoFB2020_IUCN
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='TiposVegetacaoFB2020_IUCN'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_TiposVegetacaoFB2020_IUCN)$valueLogical
                       

                       #' @details hot_possivelmente_dd
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='possivelmente_dd'
                       sp_tag$valueLogical[index_tag==TRUE] <<- hot_to_r(input$hot_possivelmente_dd)$valueLogical
                       
                       index_tag <<- sp_tag$acceptedNameSearch %in% sp_selected & sp_tag$tag=='possivelmente_dd_justificativa'
                       sp_tag$valueText[index_tag==TRUE] <<- input$texto_possivelmente_dd_justificativa

                     }
                     
                     
                     #' @details Salvar texto avaliação de risco de extinção
                     {
                       csv_texto_avaliacao <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'_texto_avaliacao.txt')
                       
                       # textoDescricaoEspecie_tmp <<- input$texto_DescricaoEspecie #input$textoDescricaoEspecie
                       
                       write_file(input$texto_DescricaoEspecie, #textoDescricaoEspecie_tmp,
                                  csv_texto_avaliacao)
                     }
                     
                     
                     #' @details Salvar arquivos CSV com informações sobre avaliação de risco de extinção
                     {
                       csv_avaliacao <- paste0(path_avaliacoes,'\\',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'.csv')
                       csv_avaliacao_file <- paste0(dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'.csv')
                       
                       write.csv(sp_tag[index_sp==TRUE,],
                                 csv_avaliacao,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       #  para contabilizar progresso
                       csv_avaliacao_todas <- paste0(path_avaliacoes,'\\',dir_output,'_','avaliacoes',gsub(':|-|','', Sys.time()),'.csv')
                       
                       write.csv(sp_tag,
                                 csv_avaliacao_todas,
                                 fileEncoding = "UTF-8",
                                 na = "",
                                 row.names = FALSE)
                       
                       # status_avalacaoSalvar <<- TRUE
                       # status_avalacaoSalvar <<- status_avalacao()
                     }
                     
                     showModal(modalDialog(
                       title = "Aviso",
                       paste0('Arquivos com avaliação (', csv_avaliacao_file, ') e pontos de ocorrência (', csv_result_file, ') salvos com sucesso!'),
                       easyClose = TRUE,
                       footer = NULL
                     ))
                     
                     
                     
                   })
      
      
      
      # montgem de textos
      {
        
        montarDescriaoEspecie <- eventReactive(
          input$textoDescricaoEspecieBtn,
          {
            
            dt <- data_sel()
            
            # aqui quando sem registros
            if(dt$totalRegistros_in < 1 )
            {
              Texto <- paste0("A espécie não possui ocorrências válidas e assim apresenta valores limítrofes para a inclusão em uma categoria de ameaça ou dados insuficientes, portanto,  será avaliada no fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.")
            }else{

              # HABITO<- spp$lifeForm_FB2020[spp$acceptedNameUsage_FB2020==sp_selected] %>% dplyr::filter(str_detect(data, "Resumo\\:\\s(Árvore|Arbusto|Subarbusto|Palmeira|Liana|Trepadeira).*"))
              # HABITO<- spp$lifeForm_FB2020[4]
              HABITO <- dt$sp_sel$lifeForm_FB2020

              occ_in_sel_tmp <- dt$occ_in_sel

              # uc_names_PI US c('nameUC_US', 'numberRecords')
              UCs <- c(dt$uc_names_PI$nameUC_PI,
                       dt$uc_names_US$nameUC_US)

              UCs_n <- NROW(UCs)

              # colnames(biomas_names) <- c('Biome', 'numberRecords', 'inFB2020?')
              BIOMAS <- dt$biomas_names$Biome
              BIOMAS_n<- dt$n_biomas

              {
                # origem do tipo de vegetacao no texto
                # de fb2020
                # VEGETACOES <- vegetationType_FB2020_x_IUCN$vegetationType_FB2020[vegetationType_FB2020_x_IUCN$acceptedNameSearch == input$sp] %>% unique()


                VEGETACOES <- hot_to_r(input$hot_TiposVegetacaoFB2020_IUCN) %>%
                  dplyr::filter(valueLogical==TRUE) %>%
                  dplyr::select(valueText) %>%
                  dplyr::distinct_all()

                VEGETACOES <- VEGETACOES$valueText
              }

              VEGETACOES<-sub("Floresta Ombrófila \\(= Floresta Pluvial\\)", "floresta ombrófila densa", VEGETACOES) #
              VEGETACOES<-sub("Floresta Ombrófila (= Floresta Pluvial)", "floresta ombrófila densa", VEGETACOES) #
              {# VEGETACOES<-sub("Área Antrópica", "área antrópica", VEGETACOES) #
                # VEGETACOES<-sub("Caatinga (stricto sensu)", "caatinga (stricto sensu)", VEGETACOES) #
                # VEGETACOES<-sub("Campinarana", "campinarana", VEGETACOES) #
                # VEGETACOES<-sub("Campo de Altitude", "campos de altitude", VEGETACOES)#
                # VEGETACOES<-sub("Campo de Várzea", "campos de várzea", VEGETACOES)#
                # VEGETACOES<-sub("Campo Limpo", "campo limpo", VEGETACOES)#
                # VEGETACOES<-sub("Campo Rupestre|Campo Rupestre", "campos rupestres", VEGETACOES)#
                # VEGETACOES<-sub("Carrasco", "carrasco", VEGETACOES)#
                # VEGETACOES<-sub("Cerrado (lato sensu)", "cerrado (lato sensu)", VEGETACOES)#
                # VEGETACOES<-sub("Floresta Ciliar ou Galeria", "floresta ciliar e/ou galeria", VEGETACOES)#
                # VEGETACOES<-sub("Floresta de Igapó", "floresta de igapó", VEGETACOES) #
                # VEGETACOES<-sub("Floresta de Terra Firme", "floresta de terra-firme", VEGETACOES)#
                # VEGETACOES<-sub("Floresta de Várzea", "floresta de várzea", VEGETACOES) #
                # VEGETACOES<-sub("Floresta Estacional Decidual", "floresta estacional decidual", VEGETACOES) #
                # VEGETACOES<-sub("Floresta Estacional Perenifólia", "floresta estacional perenifólia", VEGETACOES) #
                # VEGETACOES<-sub("Floresta Estacional Semidecidual", "floresta estacional semidecidual", VEGETACOES) #

                # VEGETACOES<-sub("Floresta Ombrófila Mista", "floresta ombrófila mista", VEGETACOES)#
                # VEGETACOES<-sub("Manguezal", "manguezal", VEGETACOES)
                # VEGETACOES<-sub("Palmeiral", "palmeiral", VEGETACOES)#
                # VEGETACOES<-sub("Restinga", "restinga", VEGETACOES) #
                # VEGETACOES<-sub("Savana Amazônica", "savana amazônica", VEGETACOES) #
                # VEGETACOES<-sub("Vegetação Aquática", "vegetação aquática", VEGETACOES)#
                # VEGETACOES<-sub("Vegetação Sobre Afloramentos Rochosos", "vegetação sobre afloramentos rochosos", VEGETACOES) #
              }

              VEGETACOES <- tolower(VEGETACOES)
              ENDEMICA_BRASIL <- hot_to_r(input$hot_endemism_FB2020)$valueLogical

              DADOS_POPULACIONAIS <- hot_to_r(input$hot_no_population_data)$valueLogical %>% as.logical()

              consideracoes_bem_amostrada <- hot_to_r(input$hot_consideracoes_bem_amostrada)$valueLogical
              consideracoes_mal_amostrada <- hot_to_r(input$hot_consideracoes_mal_amostrada)$valueLogical


              consideracoes_distribuicao_ampla <- hot_to_r(input$hot_consideracoes_distribuicao_ampla)$valueLogical
              consideracoes_distribuicao_restrita <- hot_to_r(input$hot_consideracoes_distribuicao_restrita)$valueLogical

              # teste $valueLogical
              possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO <- hot_to_r(input$hot_possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO)$valueLogical
              possivelmente_LC_EOO_SITUACAO_AMEACA <- hot_to_r(input$hot_possivelmente_LC_EOO_SITUACAO_AMEACA)$valueLogical
              possivelmente_ameacada <- hot_to_r(input$hot_possivelmente_ameacada)$valueLogical
              # fim teste

              avaliacao_fluxo_integral <- hot_to_r(input$hot_avaliacao_fluxo_integral)$valueLogical

              habitat_specificity <- hot_to_r(input$hot_habitat_specificity)$valueLogical

              # LC <- ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))
              LC <- dt$categoria_LC
              DD <- hot_to_r(input$hot_possivelmente_dd)$valueLogical
              
              texto_AOO <- "apesar do valor da AOO poder categorizá-la como ameaçada, "
              
              texto_justificativa <- ""
              if(possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO==TRUE)
              {
                texto_justificativa <- "a espécie apresenta valores de EOO e AOO excedem os limiares para categorias ameaçadas e não existem dados populacionais que atestem reduções"
              }else if(possivelmente_LC_EOO_SITUACAO_AMEACA==TRUE){
                texto_justificativa <- paste0(ifelse( dt$AOO2 > input$aoo_limit, '', texto_AOO), "a espécie apresenta valores de EOO e número de situações de ameaças excedem os limiares para categorias ameaçadas")
              }else if(possivelmente_ameacada==TRUE){
                texto_justificativa <- "a espécie apresenta valores limítrofes para a inclusão em uma categoria de ameaça ou dados insuficientes"
              }


              
              texto_classificacao <- ifelse(LC==TRUE,
                                            ', portanto, é categorizada como Menos preocupante (LC).',
                                            ', portanto,  será avaliada no fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.')

              texto_classificacao <- ifelse(avaliacao_fluxo_integral==FALSE & habitat_specificity==TRUE,", possui especificidade de habitat, portanto, será avaliada no fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.",texto_classificacao)

              texto_classificacao <- ifelse(avaliacao_fluxo_integral==TRUE & habitat_specificity==FALSE, paste0(ifelse(LC==TRUE, ", contudo", ", e"), ", por recomendação dos especialistas botânicos, será avaliada no fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ."),texto_classificacao)

              texto_classificacao <- ifelse(avaliacao_fluxo_integral==TRUE & habitat_specificity==TRUE,", possui especificidade de habitat, e, por recomendação dos especialistas botânicos, será avaliada no fluxo integral de avaliação de risco de extinção CNCFlora/JBRJ.",texto_classificacao)
              
              
              texto_classificacao <- ifelse(DD==TRUE,
                                            ', contudo, as informações taxonômicas são inconclusivas para categorização de risco de extinção.',
                                            texto_classificacao)
              

              recomendacoes_acoes_de_pesquisa <- hot_to_r(input$hot_recomendacoes_acoes_de_pesquisa)
              recomendacoes_acoes_de_conservacao <- hot_to_r(input$hot_recomendacoes_acoes_de_conservacao)
              recomendacoes_efetividade_conservacao <- hot_to_r(input$hot_recomendacoes_efetividade_conservacao)
              # recomendacoes_complemento <- hot_to_r(input$hot_recomendacoes_complemento)
              
              # Apesar do valor da AOO poder categorizá-la como ameaçada, o valor da EOO e número de situações de ameaças excedem os limiares para categorias ameaçadas. 
              # Portanto, a espécie é considerada Menos Preocupante (LC)
              

              texto_recomendacao <- ""

              if(recomendacoes_acoes_de_pesquisa==TRUE)
              {
                texto_recomendacao <- 'Recomenda-se ações de pesquisa, abrangendo, busca por novas áreas de ocorrência, censo e tendências populacionais e estudos de viabilidade populacional'
              }

              if(recomendacoes_acoes_de_conservacao==TRUE)
              {
                texto_recomendacao <- 'Recomenda-se ações para conservação in situ e ex situ'
              }

              if(recomendacoes_efetividade_conservacao==TRUE)
              {
                texto_recomendacao <- 'Recomenda-se ações para cumprimento da efetividade da conservação da espécie em Unidades de Conservação e em conservação ex situ'
              }


              if(recomendacoes_acoes_de_pesquisa==TRUE & recomendacoes_acoes_de_conservacao==TRUE)
              {
                texto_recomendacao <- 'Recomenda-se ações de pesquisa, abrangendo, busca por novas áreas de ocorrência, censo e tendências populacionais e estudos de viabilidade populacional. Do mesmo modo, recomenda-se ações para conservação in situ e ex situ'
              }
              
              
              if(recomendacoes_acoes_de_pesquisa==TRUE & recomendacoes_efetividade_conservacao==TRUE)
              {
                texto_recomendacao <- 'Recomenda-se ações de pesquisa, abrangendo, busca por novas áreas de ocorrência, censo e tendências populacionais e estudos de viabilidade populacional. Do mesmo modo, recomenda-se ações para cumprimento da efetividade da conservação da espécie em Unidades de Conservação'
              }
              


              if (texto_recomendacao != "")
              {
                texto_recomendacao <- paste0(texto_recomendacao, ', a fim de se garantir sua perpetuação na natureza, pois as pressões verificadas ao longo de sua distribuição podem ampliar seu risco de extinção.')
              }


              DISTGEO_ES <- sqldf::sqldf("SELECT DISTINCT stateProvince_check,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel_tmp
                           WHERE emUso = TRUE AND stateProvince_check != ''
                           GROUP BY stateProvince_check
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") %>%
                dplyr::select(stateProvince_check)
              DISTGEO_ES <- DISTGEO_ES$stateProvince_check

              DISTGEO_ES<-sub("AC", "Acre",DISTGEO_ES)
              DISTGEO_ES<-sub("AL","Alagoas",DISTGEO_ES)
              DISTGEO_ES<-sub("AP","Amapá",DISTGEO_ES)
              DISTGEO_ES<-sub("AM","Amazonas",DISTGEO_ES)
              DISTGEO_ES<-sub("BA","Bahia",DISTGEO_ES)
              DISTGEO_ES<-sub("CE","Ceará",DISTGEO_ES)
              DISTGEO_ES<-sub("DF","Distrito Federal",DISTGEO_ES)
              DISTGEO_ES<-sub("ES","Espírito Santo",DISTGEO_ES)
              DISTGEO_ES<-sub("GO","Goiás",DISTGEO_ES)
              DISTGEO_ES<-sub("MA","Maranhão",DISTGEO_ES)
              DISTGEO_ES<-sub("MS","Mato Grosso do Sul",DISTGEO_ES)
              DISTGEO_ES<-sub("MT","Mato Grosso",DISTGEO_ES)
              DISTGEO_ES<-sub("MG","Minas Gerais",DISTGEO_ES)
              DISTGEO_ES<-sub("PA","Pará",DISTGEO_ES)
              DISTGEO_ES<-sub("PB","Paraíba",DISTGEO_ES)
              DISTGEO_ES<-sub("PR","Paraná",DISTGEO_ES)
              DISTGEO_ES<-sub("PE","Pernambuco",DISTGEO_ES)
              DISTGEO_ES<-sub("PI","Piauí",DISTGEO_ES)
              DISTGEO_ES<-sub("RJ","Rio de Janeiro",DISTGEO_ES)
              DISTGEO_ES<-sub("RN","Rio Grande do Norte",DISTGEO_ES)
              DISTGEO_ES<-sub("RS","Rio Grande do Sul",DISTGEO_ES)
              DISTGEO_ES<-sub("RO","Rondônia",DISTGEO_ES)
              DISTGEO_ES<-sub("RR","Roraima",DISTGEO_ES)
              DISTGEO_ES<-sub("SC","Santa Catarina",DISTGEO_ES)
              DISTGEO_ES<-sub("SP","São Paulo",DISTGEO_ES)
              DISTGEO_ES<-sub("SE","Sergipe",DISTGEO_ES)
              DISTGEO_ES<-sub("TO","Tocantins",DISTGEO_ES)

              DISTGEO_ES_n <- NROW(DISTGEO_ES)

              DISTGEO <- sqldf::sqldf("SELECT DISTINCT municipality_stateProvince_check,
                                                    COUNT(Ctrl_key_family_recordedBy_recordNumber)
                           FROM occ_in_sel_tmp
                           WHERE emUso = TRUE AND municipality_stateProvince_check != ''
                           GROUP BY municipality_stateProvince_check
                           ORDER BY COUNT(Ctrl_key_family_recordedBy_recordNumber) DESC") %>%
                dplyr::select(municipality_stateProvince_check)

              DISTGEO_n <- NROW(DISTGEO)
              DISTGEO <- DISTGEO$municipality_stateProvince_check


              ano_de_coleta <- sqldf::sqldf("SELECT DISTINCT Ctrl_year
                              FROM occ_in_sel_tmp
                              WHERE emUso = TRUE
                              ORDER BY Ctrl_year ASC") %>%
                na.omit() %>%
                dplyr::filter(Ctrl_year>1800) %>%
                dplyr::rename(ano_de_coleta=Ctrl_year)

              n_coletas <- dt$totalRegistros_in

              EOO <- dt$EOO_area
              AOO <- dt$AOO2


              if(AOO==EOO){
                AOO_EOO<-paste0("seu valor de AOO e EOO igual a ", AOO, " km²")
              } else{
                AOO_EOO<-paste0("seu valor de AOO igual a ", AOO, " km² e de EOO igual a ", EOO, " km²")
              }

              if(UCs_n > 5){
                UCs_texto<-"sua ocorrência em diversas Unidades de Conservação"
              } else{
                if(UCs_n <= 5 & UCs_n > 0 & UCs_n != 1){
                  UCs_texto<-"sua ocorrência em Unidades de Conservação"
                } else{
                  if(UCs_n == 1){
                    UCs_texto<-"sua ocorrência em Unidade de Conservação"
                  } else{
                    if(UCs_n == 0){
                      UCs_texto<-"que não é registrada em Unidades de Conservação"
                    }
                  }
                }
              }


              # repetido com o cabeçalho 08-06-22
              # if(n_coletas>8){
              #   Anos_decorridos_últimas_coletas<-
              #     paste0("que suas coletas foram realizadas entre ca. ",
              #            as.numeric(sub("\\-.*", "", Sys.Date()))-min(ano_de_coleta),
              #            " e ",
              #            as.numeric(sub("\\-.*", "", Sys.Date()))-max(ano_de_coleta),
              #            " ano", ifelse((Sys.Date()-max(ano_de_coleta))<2,"","s")," atrás"
              #     )
              # } else{
              #   if(length(ano_de_coleta$ano_de_coleta)==1){
              #     Anos_decorridos_últimas_coletas<-
              #       paste0("que sua última coleta foi realizada há ",
              #              stri_replace_last(capture.output(cat(as.numeric(sub("\\-.*", "", Sys.Date()))-ano_de_coleta$ano_de_coleta, sep=", ")), fixed = ",", " e"),
              #              " anos"
              #       )
              #   } else{
              #     Anos_decorridos_últimas_coletas<-
              #       paste0("que suas coletas foram realizadas há ",
              #              stri_replace_last(capture.output(cat(as.numeric(sub("\\-.*", "", Sys.Date()))-ano_de_coleta$ano_de_coleta, sep=", ")), fixed = ",", " e"),
              #              " anos"
              #       )
              #   }
              # }

              Texto<-paste0(HABITO, "; ",
                            "com ocorrência",
                            if(BIOMAS_n > 1){
                              " nos biomas "
                            } else{
                              " no bioma "
                            },

                            stringi::stri_replace_last(paste(BIOMAS, collapse = ', '), fixed = ",", " e"),

                            ", em ",
                            stringi::stri_replace_last(paste(VEGETACOES, collapse = ', '), fixed = ",", " e"),


                            ifelse(ENDEMICA_BRASIL==TRUE, "; endêmica do Brasil, com distribuição ",
                                   "; com distribuição fora do Brasil, inclusive no Brasil, onde é registrada "),
                            paste0(
                              if(DISTGEO_n > 8){
                                if(DISTGEO_ES_n > 6){
                                  "em diversos Estados"
                                } else{
                                  paste0("em diversos municípios dos Estados ",
                                         stringi::stri_replace_last(paste(DISTGEO_ES, collapse = ', '), fixed = ",", " e")
                                  )
                                }
                              } else{
                                if(DISTGEO_n<=1){
                                  paste0("no município ",
                                         DISTGEO)
                                } else{
                                  paste0("nos municípios ",
                                         stringi::stri_replace_last(paste(DISTGEO, collapse = ', '), fixed = ",", " e")
                                  )
                                }
                              }
                            ),


                            "; representada por ",
                            n_coletas,
                            " coletas ",
                            if(n_coletas>8){
                              paste0("entre os anos de ",
                                     min(ano_de_coleta),
                                     " e ",
                                     max(ano_de_coleta)
                              )
                            } else{
                              paste0("nos anos de ",
                                     stringi::stri_replace_last(paste(ano_de_coleta$ano_de_coleta, collapse = ', '), fixed = ",", " e")
                              )
                            },
                            ifelse(DADOS_POPULACIONAIS==FALSE, "; e com dados populacionais disponíveis. ",
                                   "; e sem dados populacionais disponíveis. "),
                            "Considerando: ",
                            
                            # repetido cabeçalho
                            # Anos_decorridos_últimas_coletas, ', ',

                            ifelse(consideracoes_distribuicao_ampla==TRUE,"sua ampla distribuição, ", ""),
                            ifelse(consideracoes_distribuicao_restrita==TRUE,"sua distribuição restrita, ", ""),

                            ifelse(consideracoes_mal_amostrada==TRUE,"sua distribuição em região pouco estudada, onde esforços de coleta ainda são necessários, ", ""),

                            ifelse(consideracoes_bem_amostrada==TRUE,"sua área de ocorrência relativamente bem amostrada, ", ""),
                            # # UCs_texto,'.')
                            input$texto_iucn_description_use,', ',


                            AOO_EOO, ', ', #05-06-2022

                            texto_justificativa,

                            texto_classificacao, ' ',

                            texto_recomendacao)




              # a espécie é categorizada com Menos preocupante (LC)


              # implementar
              # Considerações:
              #    Conhecimento da área de distribuição:
              # sua área de ocorrência relativamente bem amostrada

              # Recomendações:
              #    Recomendam-se populacionais e monitoramento da espécie para averiguar possíveis declínios e reduções.



              # a espécie é categorizada como

              # Categoria Final:
              # Criticamente em Perigo (CR)
              # Em Perigo (EN)
              # Vulnerável (VU)
              # Menos Preocupante (LC)
              # Quase Ameaçada (NT)
              # Dados Insuficientes (DD)


              # modelo ordem TELA Lucas
              # Considerações:
              #    Conhecimento da área de distribuição:
              #    sua área de ocorrência relativamente bem amostrada
              #
              # AOO e EOO:
              #    seu valor de AOO igual a 16 km² e de EOO igual a 269 km²
              #
              # Anos decorridos do intervalo de coletas:
              #
              # Presença em Unidades de Conservação:
              #
              # Considerações concessivas (Orações subord. concessivas):
              #
              # Recomendações:
              #
              # Recomendam-se populacionais e monitoramento da espécie para averiguar possíveis declínios e reduções.




              # Considerações<-data.frame(AOO_EOO=AOO_EOO, UCs=UCs_texto, Anos_decorridos_últimas_coletas=Anos_decorridos_últimas_coletas)


            }
            
            # textoDescricaoEspecie <<- Texto
            
            updateTextInput(session, "text_DescricaoEspecie", value = Texto)
            updateTextAreaInput(session, "texto_DescricaoEspecie", value = Texto)
            
            return(Texto)
            
            
            
          })
        
        output$text_DescricaoEspecie <- renderPrint({textoDescricaoEspecie <<- montarDescriaoEspecie()})    #

        montarTextoUso <- eventReactive(input$textoUsoBtn, 
                                        {
                                          textoUso_tmp <- ''
                                          fern <- bgci <- cites <- FALSE
                                          fern_manter_uso <- bgci_manter_uso <- cites_manter_uso <- FALSE
                                          
                                          hot_tmp_fern <- hot_to_r(input$hot_fern_use)
                                          if(NROW(hot_tmp_fern)>0){
                                            # if (hot_tmp$valueLogical==TRUE & spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use') #spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use' &
                                            if (hot_tmp_fern$valueLogical==TRUE & spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!="") #spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use' &
                                            {
                                              # textoUso_tmp <- hot_tmp$label
                                              textoUso_tmp <- 'a espécie apresenta usos efetivos (Fern, K., 2019), contudo não atestam reduções populacionais neste momento'
                                              fern <- TRUE
                                            }
                                            
                                            
                                            if (hot_tmp_fern$valueLogical==FALSE & spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!="") #spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use' &
                                            {
                                              # textoUso_tmp <- hot_tmp$label
                                              textoUso_tmp <- 'a espécie apresenta usos efetivos (Fern, K., 2019)'
                                              fern_manter_uso <- TRUE
                                            }
                                            
                                          }
                                          
                                          hot_tmp_bgci <- hot_to_r(input$hot_bgci_CommercialTimber)
                                          if(NROW(hot_tmp_bgci)>0){
                                            if (hot_tmp_bgci$valueLogical==TRUE & (!is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp]))) 
                                            {
                                              # textoUso_tmp <-ifelse(textoUso_tmp=='',hot_tmp$label, paste0(textoUso_tmp, hot_tmp$label)) 
                                              textoUso_tmp <- 'a madeira da espécie é usada comercialmente (Mark, et al., 2014), contudo não atesta reduções populacionais neste momento'
                                              bgci <- TRUE
                                            }
                                            
                                            
                                            if (hot_tmp_bgci$valueLogical==FALSE & (!is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp]))) 
                                            {
                                              # textoUso_tmp <-ifelse(textoUso_tmp=='',hot_tmp$label, paste0(textoUso_tmp, hot_tmp$label)) 
                                              textoUso_tmp <- 'a madeira da espécie é usada comercialmente (Mark, et al., 2014)'
                                              bgci_manter_uso <- TRUE
                                            }
                                            
                                          }
                                          
                                          hot_tmp_cites <- hot_to_r(input$hot_cites_use)
                                          if(NROW(hot_tmp_cites)>0){
                                            if (hot_tmp_cites$valueLogical==TRUE & (spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]!="")) 
                                            {
                                              # textoUso_tmp <-ifelse(textoUso_tmp=='',hot_tmp$label, paste0(textoUso_tmp, ', ', hot_tmp$label)) 
                                              textoUso_tmp <- 'a espécie é usada comercialmente (CITES, 2019), contudo não atesta reduções populacionais neste momento'
                                              cites <- TRUE
                                            }
                                            
                                            if (hot_tmp_cites$valueLogical==FALSE & (spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]!="")) 
                                            {
                                              # textoUso_tmp <-ifelse(textoUso_tmp=='',hot_tmp$label, paste0(textoUso_tmp, ', ', hot_tmp$label)) 
                                              textoUso_tmp <- 'a espécie é usada comercialmente (CITES, 2019)'
                                              cites_manter_uso <- TRUE
                                            }
                                            
                                          }
                                          
                                          hot_tmp_no_use <- hot_to_r(input$hot_no_use)
                                          if(NROW(hot_tmp_no_use)>0){
                                            # if (hot_tmp_no_use$valueLogical==TRUE & ((spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!='use') 
                                            
                                            # if (hot_tmp_no_use$valueLogical==TRUE & ( (is.na(spp$use[spp$FB2020_AcceptedNameUsage == input$sp])) 
                                            #                                   & (spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]=="") 
                                            #                                   & (is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp])))) 
                                            
                                            if (hot_tmp_no_use$valueLogical==TRUE & ( (spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=="") 
                                                                                      & (spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]=="") 
                                                                                      & (is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp])))) 
                                            {
                                              # textoUso_tmp <-ifelse(textoUso_tmp=='',hot_tmp$label, paste0(textoUso_tmp, hot_tmp$label)) 
                                              textoUso_tmp <- 'não existem dados sobre usos que tem o potencial de provocar redução populacional'
                                            }
                                          }
                                          
                                          
                                          if(fern_manter_uso == TRUE & bgci_manter_uso  == TRUE){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e sua madeira é usada comercialmente (Mark, et al., 2014)"}
                                          if(fern_manter_uso == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e é usada comercialmente (CITES, 2019)"}
                                          if(bgci_manter_uso == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "a madeira da espécie (Mark, et al., 2014) e a espécie (CITES, 2019) são usadas comercialmente"}
                                          if(fern_manter_uso == TRUE & bgci_manter_uso == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "A espécie apresenta usos efetivos (Fern, K., 2019), é usada comercialmente (CITES, 2019) e sua madeira é usada comercialmente (Mark, et al., 2014)"}
                                          
                                          
                                          if(fern == TRUE & bgci  == TRUE){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          if(fern == TRUE & cites == TRUE){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e é usada comercialmente (CITES, 2019), contudo não atestam reduções populacionais neste momento"}
                                          if(bgci == TRUE & cites == TRUE){textoUso_tmp <- "a madeira da espécie (Mark, et al., 2014) e a espécie (CITES, 2019) são usadas comercialmente, contudo não atestam reduções populacionais neste momento"}
                                          if(fern == TRUE & bgci == TRUE & cites == TRUE){textoUso_tmp <- "A espécie apresenta usos efetivos (Fern, K., 2019), é usada comercialmente (CITES, 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          
                                          
                                          # 
                                          if(fern == TRUE & bgci_manter_uso == TRUE  ){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          if(fern_manter_uso == TRUE & bgci == TRUE  ){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          
                                          
                                          if(fern == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e é usada comercialmente (CITES, 2019), contudo não atestam reduções populacionais neste momento"}
                                          if(fern_manter_uso == TRUE & cites == TRUE){textoUso_tmp <- "a espécie apresenta usos efetivos (Fern, K., 2019) e é usada comercialmente (CITES, 2019), contudo não atestam reduções populacionais neste momento"}
                                          
                                          
                                          if(bgci == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "a madeira da espécie (Mark, et al., 2014) e a espécie (CITES, 2019) são usadas comercialmente, contudo não atestam reduções populacionais neste momento"}
                                          if(bgci_manter_uso == TRUE & cites == TRUE){textoUso_tmp <- "a madeira da espécie (Mark, et al., 2014) e a espécie (CITES, 2019) são usadas comercialmente, contudo não atestam reduções populacionais neste momento"}
                                          
                                          
                                          if(fern == TRUE & bgci == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "A espécie apresenta usos efetivos (Fern, K., 2019), é usada comercialmente (CITES, 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          if(fern == TRUE & bgci_manter_uso == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "A espécie apresenta usos efetivos (Fern, K., 2019), é usada comercialmente (CITES, 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          if(fern_manter_uso == TRUE & bgci == TRUE & cites == TRUE){textoUso_tmp <- "A espécie apresenta usos efetivos (Fern, K., 2019), é usada comercialmente (CITES, 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          if(fern_manter_uso == TRUE & bgci == TRUE & cites_manter_uso == TRUE){textoUso_tmp <- "A espécie apresenta usos efetivos (Fern, K., 2019), é usada comercialmente (CITES, 2019) e sua madeira é usada comercialmente (Mark, et al., 2014), contudo não atestam reduções populacionais neste momento"}
                                          # 
                                          
                                          
                                          textoUso <<- textoUso_tmp
                                          
                                          updateTextAreaInput(session, "texto_iucn_description_use", value = textoUso_tmp)
                                          return(textoUso_tmp)
                                        })
        
        output$text_uso <- renderPrint({ textoUso <<- montarTextoUso() })    
        
      }
      
      
      
      # avaliações
      {
        locations_range <- eventReactive(input$locationsBtn, 
                                         {
                                           dt <- data_sel()
                                           locations <- data.frame(locations_distance = 1:50,
                                                                   locations_number = 0)
                                           
                                           if (sum(dt$occ_in_sel$emUso) > 0)
                                           {
                                             points_for_locations <-  sp::SpatialPointsDataFrame(dt$occ_in_sel[dt$occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                                                                 data.frame(dt$occ_in_sel[dt$occ_in_sel$emUso==T,]))
                                             
                                             proj4string(points_for_locations) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                                             
                                             for(i in 1:NROW(locations))
                                             {
                                               locations_number_tmp <- dismo::circles(points_for_locations, d=locations$locations_distance[i]*1000, lonlat=T)
                                               locations$locations_number[i] <- length(locations_number_tmp@polygons@polygons[[1]]@plotOrder)
                                             }
                                             print(locations$locations_number)
                                             
                                             
                                           }
                                           
                                           return(locations)
                                         }, ignoreNULL = FALSE)
        
        
        # output$sp_selected <- renderPrint({
        #   cat(input$sp)
        # })
        
        output$locations_reg <- renderPrint({
          locations <- locations_range()
          cat(paste0(locations$locations_distance, ' : ', locations$locations_number))
        })
        
        # hot_possivelmente_LC
        {
          
          output$hot_possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='possivelmente_LC_EOO_AOO_SEM_DADOS_POPOPUPACAO',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))) 
          })
          
          
          output$hot_possivelmente_LC_EOO_SITUACAO_AMEACA <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='possivelmente_LC_EOO_SITUACAO_AMEACA',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))) 
          })
          
          # (TRUE==TRUE)
          
          # A espécie apresenta valores limítrofes para a inclusão em uma categoria de ameaça ou dados insuficientes.
          # A espécie é categorizada como Menos preocupante (LC)
          
          # hot_avaliacao_fluxo_integral hot_consideracoes_distribuicao_restrita
          
          output$possivelmente_LCBox <- renderValueBox({
            valueBox(

              # ifelse( ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number)), 
              ifelse( data_sel()$categoria_LC==TRUE &  
                        hot_to_r(input$hot_avaliacao_fluxo_integral)$valueLogical == FALSE &
                        hot_to_r(input$hot_habitat_specificity)$valueLogical == FALSE &
                        hot_to_r(input$hot_possivelmente_dd)$valueLogical ==FALSE,
                      'Possivelmente Menos preocupante (LC)', 'Possivelmente ameaça ou dados insuficientes '), 
              "Possivelmente LC?", icon = icon("list"),
              
              # color = ifelse(((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number)),
              #                'green', 'red'))
              
              color = ifelse(data_sel()$categoria_LC==TRUE &  
                               hot_to_r(input$hot_avaliacao_fluxo_integral)$valueLogical == FALSE &
                               hot_to_r(input$hot_habitat_specificity)$valueLogical == FALSE  &
                               hot_to_r(input$hot_possivelmente_dd)$valueLogical ==FALSE,
                             'green', 'red'))              
          })
          
          # PA
          {
            # completo com AOO
          # output$hot_possivelmente_ameacada <- renderRHandsontable({
          #   
          #   data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='possivelmente_ameacada',] %>%
          #     dplyr::select(valueLogical,label)
          #   
          #   data_tmp$valueLogical <- !((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))
          #   
          #   rhandsontable(data_tmp,
          #                 selectionMode = 'single',
          #                 selectCallback = FALSE,
          #                 colHeaders = NULL, rowHeaders = NULL) %>%
          #     hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))) 
          # })
            
          # somente EOO e situações de ameaça
            output$hot_possivelmente_ameacada <- renderRHandsontable({
              
              data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='possivelmente_ameacada',] %>%
                dplyr::select(valueLogical,label)
              
              data_tmp$valueLogical <- ! data_sel()$categoria_LC 
              
              data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

              rhandsontable(data_tmp,
                            selectionMode = 'single',
                            selectCallback = FALSE,
                            colHeaders = NULL, rowHeaders = NULL) %>%
                hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = data_sel()$categoria_LC) 
            })
            
          }
          output$hot_possivelmente_dd <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='possivelmente_dd',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) #((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))) 
          })
          
          # avaliacao_fluxo_integral
          
          output$hot_avaliacao_fluxo_integral <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='avaliacao_fluxo_integral',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) #((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 > input$aoo_limit) & (TRUE==TRUE))  | ((data_sel()$EOO_area > input$eoo_limit) & (data_sel()$AOO2 < input$aoo_limit) & (data_sel()$locations_number > input$locations_min_number))) 
          })
          
          
        }
        
        # consideracoes
        {
          
          
          # hot_consideracoes_distribuicao_ampla
          output$hot_consideracoes_distribuicao_ampla <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='consideracoes_distribuicao_ampla',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- (data_sel()$EOO_area > 30000)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              # hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !AmplaDistribuicao) 
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = ! (data_sel()$EOO_area > 30000)) 
            
            
            
          })
          
          # hot_consideracoes_distribuicao_restrita
          output$hot_consideracoes_distribuicao_restrita <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='consideracoes_distribuicao_restrita',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- (data_sel()$EOO_area < 100)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              # hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !DistribuicaoRestrita) 
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = ! (data_sel()$EOO_area < 100)) 
            
          })
          
          
          
          output$hot_consideracoes_bem_amostrada <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='consideracoes_bem_amostrada',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          output$hot_consideracoes_mal_amostrada <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='consideracoes_mal_amostrada',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          
        }
        
        # recomendacoes
        {
          # recomendacoes_acoes_de_pesquisa # (se não tiver dados populacionais)
          output$hot_recomendacoes_acoes_de_pesquisa <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='recomendacoes_acoes_de_pesquisa',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- hot_to_r(input$hot_no_population_data)$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          # recomendacoes_acoes_de_conservacao # (se não ocorre em uc)
          output$hot_recomendacoes_acoes_de_conservacao <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='recomendacoes_acoes_de_conservacao',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- ((data_sel()$nreg_emUC_PI + data_sel()$nreg_emUC_US) < 1)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !((data_sel()$nreg_emUC_PI + data_sel()$nreg_emUC_US) < 1) ) 
          })
          
          # recomendacoes_efetividade_conservacao # (se ocorre em uc)
          output$hot_recomendacoes_efetividade_conservacao <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='recomendacoes_efetividade_conservacao',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- ((data_sel()$nreg_emUC_PI + data_sel()$nreg_emUC_US) > 0)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !((data_sel()$nreg_emUC_PI + data_sel()$nreg_emUC_US) > 0)) 
          })
          
          # # recomendacoes_complemento # se houver recomendações
          
          # avaliar aqui 16-06-2022
          # output$hot_recomendacoes_complemento <- renderRHandsontable({
          # 
          #    data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='recomendacoes_complemento',] %>%
          #       dplyr::select(valueLogical,label)
          # 
          #    rhandsontable(data_tmp,
          #                  selectionMode = 'single',
          #                  selectCallback = FALSE,
          #                  colHeaders = NULL, rowHeaders = NULL) %>%
          #       hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE )
          # })
          
          
          
          
          
          # (hot_to_r('recomendacoes_acoes_de_pesquisa')$valueLogical==TRUE |
          #       hot_to_r('recomendacoes_acoes_de_conservacao')$valueLogical==TRUE |
          #       hot_to_r('recomendacoes_efetividade_conservacao')$valueLogical==TRUE)
          
          
        }
        
        
        # usos iucn, fern
        {
          
          output$hot_plant_grow_forms <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='plant_grow_forms',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          output$hot_TiposVegetacaoFB2020_IUCN <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='TiposVegetacaoFB2020_IUCN',] %>%
              dplyr::select(valueLogical, code, label, valueText)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          
          output$hot_endemism_FB2020 <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='endemism_FB2020',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_sel()$sp_sel$endemism_FB2020=='Endêmica do Brasil' & data_sel()$totalRegistros_global < 1
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          
          output$hot_no_population_data <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='no_population_data',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          output$hot_habitat_specificity <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='habitat_specificity',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          output$hot_fern_use <- renderRHandsontable({
            # shiny::validate(
            #    need(spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use',  ""))
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='fern_use',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              # hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = !spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use') 
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=="")
            
          })
          
          output$useBox <- renderValueBox({
            valueBox(
              # ifelse(data_sel()$sp_sel$use=='use',paste0("<a href='", data_sel()$sp_sel$url, "' target='_blank'>","YES","</a>"), 'NO'), "Use", icon = icon("list"),
              ifelse(spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!="","YES", 'NO'), "Use", icon = icon("list"),
              # color = ifelse(spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use','red','green'),
              # href = ifelse(spp$use[spp$FB2020_AcceptedNameUsage == input$sp]=='use', data_sel()$sp_sel$url,'http://tropical.theferns.info/viewtropical.php'))
              color = ifelse(spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!="",'red','green'),
              href = ifelse(spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!="", data_sel()$sp_sel$url,'http://tropical.theferns.info/viewtropical.php'))
          })
          
          output$hot_bgci_CommercialTimber <- renderRHandsontable({
            # shiny::validate(
            #    need(!is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp]),  ""))
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='bgci_CommercialTimber_use',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = FALSE, highlightRow = FALSE, readOnly = is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp])) 
          })
          
          output$bgci_CommercialTimberBox <- renderValueBox({
            valueBox(
              ifelse(!is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp]), 'YES', 'NO'), 
              ifelse(!is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp]),bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp] , 'The International Timber Trade'), icon = icon("list"),
              color = ifelse(!is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp]),'red','green'))
          })
          
          
          output$hot_cites_use <- renderRHandsontable({
            # shiny::validate(
            #    need(!is.na(spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]),  ""))
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='cites_use',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = FALSE, highlightRow = FALSE, readOnly = spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]=="") 
          })
          
          output$cites_anexoIIBox <- renderValueBox({
            valueBox(
              
              ifelse(data_sel()$sp_sel$CITES != '' ,'YES','NO'), "CITES Append II", icon = icon("list"),
              color = ifelse(data_sel()$sp_sel$CITES != '','red','green'))
          })
          
          
          output$hot_no_use <- renderRHandsontable({
            # shiny::validate(
            #    need( (spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!='use') & 
            #             (is.na(spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp])) &
            #            (is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp])),  ""))
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='no_use',] %>%
              dplyr::select(valueLogical,label)
            
            data_tmp$valueLogical <- ((spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!='use') & 
                                        (spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]=="") &
                                        (is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp])))
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = FALSE, highlightRow = FALSE, readOnly = !((spp$use[spp$FB2020_AcceptedNameUsage == input$sp]!='use') & 
                                                                                   (spp$CITES[spp$FB2020_AcceptedNameUsage == input$sp]=="") &
                                                                                   (is.na(bgci_CommercialTimber$commercialTimberSource[bgci_CommercialTimber$acceptedNameSearch == input$sp])))) 
          })
          
          output$hot_iucn_use <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='iucn_use',] %>%
              dplyr::select(valueLogical,label, code)
            
            data_tmp$valueLogical <- data_tmp$valueLogical %>% as.logical()

            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
          output$hot_iucn_use_desc <- renderRHandsontable({
            
            data_tmp <- sp_tag[sp_tag$acceptedNameSearch == input$sp & sp_tag$tag=='description_use',] %>%
              dplyr::select(valueText)
            
            rhandsontable(data_tmp,
                          selectionMode = 'single',
                          selectCallback = FALSE,
                          colHeaders = NULL, rowHeaders = NULL) %>%
              hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = FALSE) 
          })
          
        }
        
        # dados fora do calculo (considerar migra FB2020 para esta camada)
        # IUCN, BGCI, Tipos Vegetação FB X IUCN
        {
          # IUCN %>% colnames()
          output$table_IUCN <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
              {
                shiny::validate(
                  need(!is.na(IUCN[IUCN$acceptedNameSearch == input$sp,'category']),  "Espécie sem avaliação em IUCN!"))
                
                t(IUCN[IUCN$acceptedNameSearch == input$sp, ] %>%
                    dplyr::select(-acceptedNameSearch) %>%
                    dplyr::select(published_year,
                                  assessment_date,
                                  category,
                                  criteria,
                                  population_trend,
                                  terrestrial_system,
                                  assessor, 
                                  reviewer, 
                                  aoo_km2,
                                  eoo_km2 ))
                
              }))
          
          # bgci_CommercialTimber %>% colnames()
          output$table_bgci_CommercialTimber <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
              {
                shiny::validate(
                  need(NROW(bgci_CommercialTimber[bgci_CommercialTimber$acceptedNameSearch == input$sp, ])>0,  "Espécie sem uso madeireiro documentado em BGCI!"))
                bgci_CommercialTimber[bgci_CommercialTimber$acceptedNameSearch == input$sp, ] %>% 
                  dplyr::select(-acceptedNameSearch)
                
                # bgci_CommercialTimber[bgci_CommercialTimber$acceptedNameSearch == input$sp, ] %>%
                #    dplyr::select(-acceptedNameSearch)
                
              }))
          
          # vegetationType_FB2020_x_IUCN %>% colnames()
          output$table_vegetationType_FB2020_x_IUCN <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
              {
                shiny::validate(
                  need(NROW(vegetationType_FB2020_x_IUCN[vegetationType_FB2020_x_IUCN$acceptedNameSearch == input$sp, ])>0,  "Espécie sem tipo de vegetação documentado em FB2020!"))
                
                vegetationType_FB2020_x_IUCN[vegetationType_FB2020_x_IUCN$acceptedNameSearch == input$sp, ] %>%
                  dplyr::select(-acceptedNameSearch)}))
          
          # synonym %>% colnames()
          output$table_synonym <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
              {
                shiny::validate(
                  need(NROW(synonym[synonym$acceptedName == input$sp, ])>0,  "Espécie sem sinônimo documentado em FB2020!"))
                
                synonym[synonym$acceptedName == input$sp, ] %>% 
                  dplyr::select(-acceptedName)}))
          
          # infrataxa %>% colnames()
          output$table_infrataxa <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
              {
                shiny::validate(
                  need(NROW(infrataxa[infrataxa$acceptedName == input$sp, ])>0,  "Espécie sem infrataxa documentado em FB2020!"))
                
                infrataxa[infrataxa$acceptedName == input$sp, ] %>%
                  dplyr::select(-acceptedName)}))
          
          
        }
      }
      
      
      
      # Validar no Mapa
      {
        data_of_click <- reactiveValues(clickedMarker=NULL)
        
        output$table_selected_map <- DT::renderDataTable(
          DT::datatable(
            options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              
              # aqui 11-05-2022
              shiny::validate(
                need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
              
              ID<-data_of_click$clickedMarker$id
              dt <- data_sel()
              x <- dt$occ_formatada$occ_ficha[dt$occ_formatada$occ_ficha$ID_PRV == ID,]
              if (NROW(x)>0)
              {
                
                x <- t(x) %>% as.data.frame()
                # print(colnames(x))
                colnames(x) <- c('Informação original')
                x
              }  
              
            }))
        
        output$table_selected_map_detalhe <- DT::renderDataTable(
          DT::datatable(
            options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              
              # aqui 11-05-2022
              shiny::validate(
                need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
              
              ID<-data_of_click$clickedMarker$id
              dt <- data_sel()
              x <- dt$occ_formatada$occ_detalhe[dt$occ_formatada$occ_detalhe$ID_PRV == ID,]
              
              if (NROW(x)>0)
              {
                x <- t(x) %>% as.data.frame()
                # print(colnames(x))
                colnames(x) <- c('Informações sobre o espécime')
                x
              }
            }))
        
        output$table_selected_map_duplicate <- DT::renderDataTable(
          DT::datatable(
            selection = 'single',
            # server=FALSE,
            options = list(scrollX = TRUE,
                           scrollCollapse=TRUE),
            # options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              # aqui 11-05-2022
              shiny::validate(
                need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
              
              
              ID<-data_of_click$clickedMarker$id
              dt <- data_sel()
              x1 <- dt$occ_formatada$occ_ficha[dt$occ_formatada$occ_ficha$ID_PRV == ID,]
              
              x <- dt$occ_out[dt$occ_out$Ctrl_key_family_recordedBy_recordNumber %in% x1$duplicateGroupingkey,] %>%
                data.frame()
              
              if (NROW(x)>0)
              {
                formatar_dados(x)$occ_ficha %>%
                  dplyr::select(comments,
                                
                                institutionCode,
                                collectionCode,
                                catalogNumber,
                                
                                recordedBy,
                                recordNumber,
                                
                                dataColeta,
                                
                                country,     
                                stateProvince,
                                municipality,                           
                                locality,
                                decimalLongitude,
                                decimalLatitude,
                                occurrenceRemarks,
                                
                                scientificName,
                                identificationQualifier,
                                identifiedBy,
                                dateIdentified,
                                typeStatus) %>% 
                  dplyr::arrange_at( c('collectionCode', 'catalogNumber', 'recordedBy', 'recordNumber' ))
              }
              
            }))
        
        observeEvent(input$saveBtn_map, {
          
          dt <- data_sel()
          df_reg <- hot_to_r(input$hot_reg)
          
          if (!is.null(df_reg))
          {
            
            dt$occ_in_sel[dt$occ_in_sel$ID_PRV == df_reg$ID_PRV,c('Identificação',
                                                                  'Localização',
                                                                  # Verificar_Vertice_EOO,
                                                                  'Latitude',
                                                                  'Longitude',
                                                                  'Ctrl_key_family_recordedBy_recordNumber',
                                                                  'ID_PRV')] <- df_reg
            
            # csv_result <- paste0(path_results,'/',dir_output,'_',gsub(' ', '_', input$sp),gsub(':|-|','', Sys.time()),'.csv')
            binomio <- paste0(word(input$sp,1), '_',word(input$sp,2))
            csv_result <- paste0(path_results,'/',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'.csv')
            csv_result_file <- paste0(dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'.csv')
            
            if (!is.null(dt$occ_in_sel))
            {
              write.csv(dt$occ_in_sel[, c('Identificação',
                                          'Localização',
                                          # Verificar_Vertice_EOO,
                                          'Latitude',
                                          'Longitude',
                                          'Ctrl_key_family_recordedBy_recordNumber',
                                          'ID_PRV')], 
                        csv_result,
                        fileEncoding = "UTF-8", 
                        na = "", 
                        row.names = FALSE)
              
              showModal(modalDialog(
                title = "Aviso", paste0('Arquivo com pontos de ocorrência (', csv_result_file, ') salvo com sucesso!'),
                easyClose = TRUE,
                footer = NULL
              ))
              
            }
          }
          
          
          
          
        })
        
        output$map <- renderLeaflet({
          
          dt <- data_sel()
          
          if (input$onlineBtn == 'Sim')
          { 
            
            m <- m_map_on
            
          }else{
            
            if (input$viewLimitsOff == 'Municípios' )#& (NROW(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0) )# & sum(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
            {
              
              if (NROW(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
              {
                
                occ.pto_adm <- sp::SpatialPointsDataFrame(dt$occ_in_sel[dt$occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                          data.frame(dt$occ_in_sel[dt$occ_in_sel$emUso==T,]))
                proj4string(occ.pto_adm) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                
                x <- over(occ.pto_adm, Estados_IBGE)
                index <- Estados_IBGE$SIGLA_UF %in% x$SIGLA_UF
                Estados_IBGE_sel <- Estados_IBGE[index==TRUE,]
                proj4string(Estados_IBGE_sel) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                
                x <- over(occ.pto_adm, Municipios_IBGE)
                index <- Municipios_IBGE$Mun_ES %in% x$Mun_ES
                Municipios_IBGE_sel <- Municipios_IBGE[index==TRUE,]
                proj4string(Municipios_IBGE_sel) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                
                
                m <- m_map_off_br %>%
                  addPolygons(data = Estados_IBGE_sel,
                              fillOpacity = 0,
                              weight = 2,
                              color = "black",
                              label = ~NM_UF) %>%
                  addPolygons(data = Municipios_IBGE_sel,
                              fillOpacity = 0,
                              weight = 2,
                              color = "purple",
                              label = ~Mun_ES)
              }else{
                m <- m_map_off_br
              }
              
            }else if (input$viewLimitsOff == 'Estados' )#& (NROW(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0))# & sum(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
            {   
              
              if (NROW(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
              {
                
                occ.pto_adm <- sp::SpatialPointsDataFrame(dt$occ_in_sel[dt$occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                          data.frame(dt$occ_in_sel[dt$occ_in_sel$emUso==T,]))
                proj4string(occ.pto_adm) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                
                x <- over(occ.pto_adm, Estados_IBGE)
                index <- Estados_IBGE$SIGLA_UF %in% x$SIGLA_UF
                Estados_IBGE_sel <- Estados_IBGE[index==TRUE,]
                proj4string(Estados_IBGE_sel) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                
                m <- m_map_off_br %>%
                  addPolygons(data = Estados_IBGE_sel,
                              fillOpacity = 0,
                              weight = 2,
                              color = "black",
                              label = ~NM_UF)
              }else{
                m <- m_map_off_br
              }
              
              
            }else if (input$viewLimitsOff == 'Brasil')
            {
              m <- m_map_off_br
              
            }else
            {
              m <- m_map_off
            }
            
          }
          
          
          if (NROW(dt$occ_in_sel) >0)
          {
            
            icons <- awesomeIcons(icon = "whatever",
                                  iconColor = "black",
                                  library = "ion",
                                  markerColor = dt$occ_in_sel$cor)
            
            etiquetaTexto <- paste0("ID na Fonte : <a href='", 
                                    # actionLink(inputId, label, icon = NULL, ...)
                                    "floradobrasil.jbrj.gov.br",
                                    "' target='_blank'>", dt$occ_in_sel$Ctrl_occurrenceID,"</a>",br(),
                                    
                                    ' Coleção: ', dt$occ_in_sel$Ctrl_collectionCode, ' ', dt$occ_in_sel$Ctrl_catalogNumber,br(),
                                    
                                    ' Coletor : ', dt$occ_in_sel$Ctrl_recordedBy,' ',dt$occ_in_sel$Ctrl_recordNumber, br(),
                                    dt$occ_in_sel$Ctrl_key_family_recordedBy_recordNumber,br(),
                                    
                                    # aqui 05-06-2022
                                    ' Data : ', dt$occ_in_sel$Ctrl_day, "/" , dt$occ_in_sel$Ctrl_month, "/" , dt$occ_in_sel$Ctrl_year, br(),
                                    # ' Data : ', dt$occ_in_sel$Ctrl_day, "/" , dt$occ_in_sel$Ctrl_month, "/" , dt$occ_in_sel$Ctrl_year, br(),
                                    
                                    ' Identificação: ', dt$occ_in_sel$Ctrl_identifiedBy, ' em ', dt$occ_in_sel$Ctrl_dateIdentified,' ', dt$occ_in_sel$Ctrl_identificationQualifier,br(),
                                    ' País: ', dt$occ_in_sel$Ctrl_country_standardized,br(),
                                    ' Estado : ', dt$occ_in_sel$Ctrl_stateProvince_standardized,br(),
                                    ' Município: ', dt$occ_in_sel$Ctrl_municipality_standardized,br(),
                                    ' Localidade: ', dt$occ_in_sel$Ctrl_locality_standardized,br(),
                                    ' Tipo: ', dt$occ_in_sel$Ctrl_typeStatus,br(),
                                    ' Notas de pré-validação geográfica: ',dt$occ_in_sel$autoGeoNotes,br(),
                                    ' Notas de chegagem de campo : ',dt$occ_in_sel$verbatimNotes,br())
            
            
            etiquetaTextoBtn <- paste("<b>", etiquetaTexto, "</b></br>",
                                      actionButton("selectlocation", 'Validar/Invalidar Identificação', onclick = 'Shiny.onInputChange(\"sp\",  Math.random())'),
                                      actionButton("selectlocation", 'Validar/Invalidar Localização Geográfica', onclick = 'Shiny.onInputChange(\"sp\",  Math.random())')
            )
            
            
            label <- paste0(dt$occ_in_sel$Ctrl_occurrenceID, ' - ', dt$occ_in_sel$Ctrl_key_family_recordedBy_recordNumber,
                            ' / ', dt$occ_in_sel$Ctrl_year, 
                            ' / ', dt$occ_in_sel$Ctrl_municipality_standardized, ' - ',dt$occ_in_sel$Ctrl_stateProvince_standardized, ' - ', dt$occ_in_sel$Ctrl_country_standardized,
                            ' / Ident.: ', dt$occ_in_sel$Ctrl_identifiedBy)
            
            popup_g <- etiquetaTexto
            
            
            # ifelse(dt$occ_in_sel$verticeEOO==TRUE,'Vértice EOO','Pré-valiados BR'),
            # grupo_camadas <- ifelse(dt$occ_in_sel$verticeEOO==TRUE,'Vértice EOO','Pré-valiados BR')
            
            # grupo_camadas <- ifelse(dt$occ_in_sel$verticeEOO==TRUE, 'Vértice EOO', 
            #                             ifelse(dt$occ_in_sel$emUC==TRUE, 'Dentro de Unidade de Conservação', 
            #                                    'Fora de Unidade de Conservação'))
            
            # ifelse(occ_in_sel$emUso==TRUE,'lightgreen','lightred'))))
            
            
            
            grupo_camadas <- ifelse(dt$occ_in_sel$verticeEOO==TRUE, 'Vértice EOO', 
                                    ifelse(dt$occ_in_sel$emUso==TRUE, 'Validados', 
                                           'Invalidados'))
            
            
            # cor_label <-rep('black',dt$totalRegistros_in)
            # cor_label <- ifelse(dt$occ_in_sel$verticeEOO==TRUE,
            #                     'red',cor_label)
            # cor_label <- ifelse(dt$occ_in_sel$verticeEOO==TRUE & dt$occ_in_sel$Verificar_Vertice_EOO==TRUE,
            #                     'green',cor_label)
            
            m <- addAwesomeMarkers(m,
                                   lat = dt$occ_in_sel$Latitude,
                                   lng = dt$occ_in_sel$Longitude,
                                   
                                   # aqui voltar
                                   label = label,
                                   
                                   # # labelOptions = labelOptions(style = list( "color" = ifelse(dt$occ_in_sel$verticeEOO==TRUE,"red","black"))),
                                   # labelOptions = labelOptions(style = list( "color" = cor_label)),
                                   # popup = etiquetaTextoBtn,
                                   icon =  icons,
                                   # group= ifelse(dt$occ_in_sel$verticeEOO==TRUE,'Vértice EOO','Pré-valiados BR'),
                                   group = grupo_camadas,
                                   layerId=dt$occ_in_sel$ID_PRV)
            
            
            # m <-  addCircleMarkers(m,
            #                        lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, 
            #                        label = dt$occ_in_sel$Ctrl_key_family_recordedBy_recordNumber,
            #                        popup = etiquetaTexto,
            #                        color = "red",
            #                        popupOptions = popupOptions(closeButton=F, closeOnClick=F))
            
            
            # m <- addMarkers(m,
            #                 # icon =  icons,
            #                 # group= ifelse(dt$occ_in_sel$verticeEOO==TRUE,'Vértice EOO','Pré-valiados BR'),
            #                 layerId=dt$occ_in_sel$ID_PRV,
            #                 lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, 
            #                 popup = paste("<b>", etiquetaTexto, "</b></br>", 
            #                               # actionButton("selectlocation", "Select this Location", onclick = 'Shiny.onInputChange(\"button_click\",  Math.random())')))
            #                               actionButton("selectlocation", "Select this Location", onclick = 'Shiny.onInputChange(\"sp\",  Math.random())')))
            
            # id2 <- eventReactive(input$button_click, {
            #    input$map_marker_click$id
            # })
            
          }
          
          if (NROW(dt$occ_global_sel) >0)
          {

            etiquetaTexto <- paste0('ID na Fonte :',dt$occ_global_sel$Ctrl_occurrenceID, br(),
                                    ' Coleção: ', dt$occ_global_sel$Ctrl_collectionCode, ' ', dt$occ_global_sel$Ctrl_catalogNumber,br(),

                                    ' Coletor : ', dt$occ_global_sel$Ctrl_recordedBy,' ',dt$occ_global_sel$Ctrl_recordNumber, br(),
                                    dt$occ_global_sel$Ctrl_key_family_recordedBy_recordNumber,br(),
                                    # aqui 05-06-2022
                                    ' Data : ', dt$occ_global_sel$Ctrl_day, "/" , dt$occ_global_sel$Ctrl_month, "/" , dt$occ_global_sel$Ctrl_year, br(),

                                    # ' Data : ', dt$occ_global_sel$Ctrl_day, "/" , dt$occ_global_sel$Ctrl_month, "/" , dt$occ_global_sel$Ctrl_year, br(),

                                    ' Identificação: ', dt$occ_global_sel$Ctrl_identifiedBy, ' em ', dt$occ_global_sel$Ctrl_dateIdentified,' ', dt$occ_global_sel$Ctrl_identificationQualifier,br(),
                                    ' País: ', dt$occ_global_sel$Ctrl_country_standardized,br(),
                                    ' Estado : ', dt$occ_global_sel$Ctrl_stateProvince_standardized,br(),
                                    ' Município: ', dt$occ_global_sel$Ctrl_municipality_standardized,br(),
                                    ' Localidade: ', dt$occ_global_sel$Ctrl_locality_standardized,br(),
                                    ' Tipo: ', dt$occ_global_sel$Ctrl_typeStatus,br(),
                                    ' Notas de pré-validação geográfica: ',dt$occ_global_sel$autoGeoNotes,br(),
                                    ' Notas de chegagem de campo : ',dt$occ_global_sel$verbatimNotes,br())

            label <- paste0(dt$occ_global_sel$Ctrl_occurrenceID, ' - ', dt$occ_global_sel$Ctrl_key_family_recordedBy_recordNumber,
                            ' / ', dt$occ_global_sel$Ctrl_year,
                            ' / ', dt$occ_global_sel$Ctrl_municipality_standardized, ' - ',dt$occ_global_sel$Ctrl_stateProvince_standardized, ' - ', dt$occ_global_sel$Ctrl_country_standardized,
                            ' / Ident.: ', dt$occ_global_sel$Ctrl_identifiedBy)


            m <- addAwesomeMarkers(m,
                                   lat = dt$occ_global_sel$Latitude,
                                   lng = dt$occ_global_sel$Longitude,

                                   # aqui voltar
                                   label = label,
                                   popup = etiquetaTexto,

                                   icon =    icons <- awesomeIcons(icon = "whatever",
                                                                   iconColor = "black",
                                                                   library = "ion",
                                                                   markerColor = 'black'),
                                   group='Fora BR',
                                   layerId=dt$occ_global_sel$ID_PRV
            )
          }
          
          if (!is.na(dt$EOO))
          {
            shp_sf <- sf::st_as_sf(dt$EOO) %>%
              sf::st_transform(4326)
            
            m <- m %>% addPolylines(data = shp_sf,
                                    smoothFactor = 0.5,
                                    fillOpacity = 0.5,
                                    weight = 0.5,
                                    color = 'red',
                                    opacity = 0.8)
          }
          
          m %>%
            addLegendAwesomeIcon(iconSet = iconSet,
                                 orientation = 'vertical',
                                 title = NULL,
                                 labelStyle = 'font-size: 10px;',
                                 position = 'bottomright',
                                 group = 'Legenda')
          
          # m             %>%  # add legend to the map
          #    addLegend(position = "bottomright", # position where the legend should appear
          #              pal = 'red', # pallete object where the color is defined
          #              values = cor_label, # column variable or values that were used to derive the color pallete object
          #              title = "Ocorrências", #itle of the legend
          #              opacity = 1 # Opacity of legend
          #    )
          
        })
        
        # store the click
        observeEvent(input$map_marker_click,{
          data_of_click$clickedMarker <- input$map_marker_click
        })
        
        output$hot_reg <- renderRHandsontable({
          
          # aqui 11-05-2022
          shiny::validate(
            need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
          
          
          ID<-data_of_click$clickedMarker$id  
          dt <- data_sel()
          dt$occ_in_sel <- dt$occ_in_sel[dt$occ_in_sel$ID_PRV == ID,]
          
          rhandsontable(dt$occ_in_sel %>%
                          # dplyr::filter(ID_PRV == ID) %>%
                          dplyr::select(Identificação,
                                        Localização,
                                        # Verificar_Vertice_EOO,
                                        Latitude,
                                        Longitude,
                                        Ctrl_key_family_recordedBy_recordNumber,
                                        ID_PRV),
                        # Verificar_Vertice_EOO = dt$occ_in_sel$Verificar_Vertice_EOO,
                        # width = 800, height = 100,
                        selectionMode = 'single',
                        selectCallback = FALSE) %>%
            
            # hot_cols(colWidths = 100)%>%
            # hot_rows(rowHeights=50)%>%
            
            hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = TRUE) %>%
            hot_col("Identificação", readOnly = FALSE, type='checkbox' ) %>%
            hot_col("Localização", readOnly = FALSE, type='checkbox') %>%
            # hot_col("Verificar_Vertice_EOO", readOnly = FALSE, type='checkbox') %>%
            hot_col("Latitude", readOnly = FALSE, type = 'numeric') %>%
            hot_col("Longitude", readOnly = FALSE, type = 'numeric') 
          
          
        })
        
      }
      
      
      
      # Validar na tabela registro por registro
      {
        observeEvent(input$saveBtn, {
          
          df<-hot_to_r(input$hot)
          
          # csv_result <- paste0(path_results,'/',dir_output,'_',gsub(' ', '_', input$sp),gsub(':|-|','', Sys.time()),'.csv')
          binomio <- paste0(word(input$sp,1), '_',word(input$sp,2))
          csv_result <- paste0(path_results,'/',dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'.csv')
          csv_result_file <- paste0(dir_output,'_',gsub(' ', '_', binomio),gsub(':|-|','', Sys.time()),'.csv')
          
          if (!is.null(df))
          {
            write.csv(df, 
                      csv_result,
                      fileEncoding = "UTF-8", 
                      na = "", 
                      row.names = FALSE)
            
            showModal(modalDialog(
              title = "Aviso",
              paste0('Aquivo com pontos de ocorrência (', csv_result_file, ') salvo com sucesso!'),
              easyClose = TRUE,
              footer = NULL
            ))
            
          }
          
        })
        # xi=input$table$changes$changes[[1]][[1]] # fetches the row index of the cell where change is made 
        # yi=input$table$changes$changes[[1]][[2]] # fetches the column index of the cell where change is made
        # old = input$table$changes$changes[[1]][[3]] # fecthes the old values of the cell
        # new = input$table$changes$changes[[1]][[4]] # fecthe
        
        output$hot <- renderRHandsontable({
          
          # # aqui 11-05-2022
          # retirei novamente em 05-06-2022
          # shiny::validate(
          #   need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
          
          dt <- data_sel()
          
          rhandsontable(dt$occ_in_sel %>%
                          dplyr::select(Identificação,
                                        Localização,
                                        # Verificar_Vertice_EOO,
                                        Latitude,
                                        Longitude,
                                        Ctrl_key_family_recordedBy_recordNumber,
                                        ID_PRV),
                        width = 500, height = 510,
                        selectionMode = 'single',
                        selectCallback = TRUE) %>%
            
            # hot_cols(colWidths = 100)%>%
            # hot_rows(rowHeights=50) %>%
            
            hot_table(highlightCol = TRUE, highlightRow = TRUE, readOnly = TRUE) %>%
            hot_col("Identificação", readOnly = FALSE, type='checkbox' ) %>%
            hot_col("Localização", readOnly = FALSE, type='checkbox') %>%
            # hot_col("Verificar_Vertice_EOO", readOnly = FALSE, type='checkbox') %>%
            hot_col("Latitude", readOnly = FALSE, type = 'numeric') %>%
            hot_col("Longitude", readOnly = FALSE, type = 'numeric')
          
          # %>%
          #    hot_cols(renderer = "
          #    function (instance, td, row, col, prop, value, cellProperties) {
          #    Handsontable.renderers.TextRenderer.apply(this, arguments);
          # 
          #    if( instance.getData()[row][1] == 'FALSE' & instance.getData()[row][2] == 'FALSE') {
          #    row.style.background = 'lightred';
          #    } else {
          #    row.style.background = 'lightblue'}
          # 
          #    }")
          
          # selected()
        })
        

        # mapa registro
        output$selected <- renderPrint({
          cat(paste0('Última linha selecionada na tabela: ', input$hot_select$select$r))
          # print(br())
          # print(paste0('Última linha selecionada na tabela: ', ultima_linha))
        })
        
        output$table_selected <- DT::renderDataTable(
          DT::datatable(
            # options = list(dom = 't'),
            options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              
              # aqui 11-05-2022
              shiny::validate(
                need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
              
              dt <- data_sel()
              x <- dt$occ_formatada$occ_ficha
              x <- x[x$ID_PRV == ID(input),]
              x <- t(x) %>% as.data.frame()
              colnames(x) <- c('Informação original')
              x
            }))
        
        output$table_selected_detalhe <- DT::renderDataTable(
          DT::datatable(
            options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              
              # aqui 11-05-2022
              shiny::validate(
                need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
              
              # link <- get_link_source_record(dt$occ_in_sel$Ctrl_occurrenceID,
              #                                dt$occ_in_sel$Ctrl_bibliographicCitation,
              #                                dt$occ_in_sel$Ctrl_scientificNameReference)
              
              
              dt <- data_sel()

              # x <- occ_in[1,]
              x <- dt$occ_formatada$occ_detalhe
              # x <- cbind(data.frame(link=link), x)
              x <- x[x$ID_PRV == ID(input),]
              x <- t(x) %>% as.data.frame()
              colnames(x) <- c('Informações sobre o espécime')
              x
              
            }))
        
        output$table_selected_duplicate <- DT::renderDataTable(
          DT::datatable(
            options = list(scrollX = TRUE,
                           scrollCollapse=TRUE),
            # options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              
              # aqui 11-05-2022
              shiny::validate(
                need(data_sel()$totalRegistros_in_geral>0,  "Espécie sem registros válidos!"))
              
              dt <- data_sel()
              x1 <- dt$occ_formatada$occ_ficha[dt$occ_formatada$occ_ficha$ID_PRV == ID(input),]
              
              x <- dt$occ_out[dt$occ_out$Ctrl_key_family_recordedBy_recordNumber %in% x1$duplicateGroupingkey,] %>%
                data.frame()
              
              # # x <- occ_out %>%
              #   data.frame()
              
              # x <- x %>%
              #   dplyr::mutate(occurrenceID= Ctrl_occurrenceID,
              #                 # scientificName=Ctrl_scientificNameSearched,
              #                 identifiedBy = paste0(ifelse(is.na(Ctrl_identifiedBy),'',Ctrl_identifiedBy), ' ', ifelse(is.na(Ctrl_dateIdentified),'',Ctrl_dateIdentified) )) %>%
              #   dplyr::select(
              #     occurrenceID,
              #     identifiedBy) %>%
              #   dplyr::arrange_at('occurrenceID')
              # x
              
              # formatar_dados(x)$occ_detalhe %>%
              #   dplyr::select(-tipoUC,
              #                 -nomeUC,
              #                 -verticeEOO,
              #                 -emUso,
              #                 -duplicates,
              #                 -ID_PRV)
              
              formatar_dados(x)$occ_ficha %>%
                dplyr::select(comments,
                              
                              institutionCode,
                              collectionCode,
                              catalogNumber,
                              
                              recordedBy,
                              recordNumber,
                              
                              dataColeta,
                              
                              country,     
                              stateProvince,
                              municipality,                           
                              locality,
                              decimalLongitude,
                              decimalLatitude,
                              occurrenceRemarks,
                              
                              scientificName,
                              identificationQualifier,
                              identifiedBy,
                              dateIdentified,
                              typeStatus) %>% 
                dplyr::arrange_at( c('collectionCode', 'catalogNumber', 'recordedBy', 'recordNumber' ))
              
            }))
        
        output$map_reg <- renderLeaflet({
          
          {
            linha <- input$hot_select$select$r
            
            if ( is.null(linha))
            {
              linha <- 1
            }
            
            mudou <- ultima_linha != linha
            
            if (mudou==T)
            {
              ultima_linha <<- linha
            }
          }
          
          dt <- data_sel()
          dt$occ_in_sel <- dt$occ_in_sel[dt$occ_in_sel$ID_PRV == ID(input),]
          
          if (NROW(dt$occ_in_sel)>0)
          {
            
            if (input$onlineBtn == 'Sim')
            { 
              
              m <- m_map_on %>%
                setView(lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, zoom = input$zoom_map) 
              
            }else{
              
              if (input$viewLimitsOff == 'Municípios')# & sum(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0 )
              {
                if (NROW(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
                {
                  occ.pto_adm <- sp::SpatialPointsDataFrame(dt$occ_in_sel[dt$occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                            data.frame(dt$occ_in_sel[dt$occ_in_sel$emUso==T,]))
                  proj4string(occ.pto_adm) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                  
                  x <- over(occ.pto_adm, Estados_IBGE)
                  index <- Estados_IBGE$SIGLA_UF %in% x$SIGLA_UF
                  Estados_IBGE_sel <- Estados_IBGE[index==TRUE,]
                  proj4string(Estados_IBGE_sel) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                  
                  x <- over(occ.pto_adm, Municipios_IBGE)
                  index <- Municipios_IBGE$Mun_ES %in% x$Mun_ES
                  Municipios_IBGE_sel <- Municipios_IBGE[index==TRUE,]
                  proj4string(Municipios_IBGE_sel) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                  
                  m <- m_map_off_br %>%
                    addPolygons(data = Estados_IBGE_sel,
                                fillOpacity = 0,
                                weight = 2,
                                color = "black",
                                label = ~NM_UF) %>%
                    addPolygons(data = Municipios_IBGE_sel,
                                fillOpacity = 0,
                                weight = 2,
                                color = "purple",
                                label = ~Mun_ES)  %>%
                    setView(lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, zoom = input$zoom_map)
                }else{
                  m <- m_map_off_br
                }
                
                
                
              }else if (input$viewLimitsOff == 'Estados')# & sum(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
              {   
                
                if (NROW(dt$occ_in_sel[dt$occ_in_sel$emUso==T,])>0)
                {
                  occ.pto_adm <- sp::SpatialPointsDataFrame(dt$occ_in_sel[dt$occ_in_sel$emUso==T, c('Longitude', 'Latitude') ] ,
                                                            data.frame(dt$occ_in_sel[dt$occ_in_sel$emUso==T,]))
                  proj4string(occ.pto_adm) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                  
                  x <- over(occ.pto_adm, Estados_IBGE)
                  index <- Estados_IBGE$SIGLA_UF %in% x$SIGLA_UF
                  Estados_IBGE_sel <- Estados_IBGE[index==TRUE,]
                  proj4string(Estados_IBGE_sel) <- rgdal::CRSargs(sp::CRS("+proj=longlat +datum=WGS84 +no_defs"))
                  
                  m <- m_map_off_br %>%
                    addPolygons(data = Estados_IBGE_sel,
                                # addPolygons(data = Municipios_IBGE,
                                fillOpacity = 0,
                                weight = 2,
                                color = "black",
                                label = ~NM_UF) %>%
                    setView(lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, zoom = input$zoom_map) 
                }else{
                  m <- m_map_off_br
                }
                
                
              }else if (input$viewLimitsOff == 'Brasil')
              {
                m <- m_map_off_br %>%
                  setView(lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, zoom = input$zoom_map) 
                
              }else
              {
                m <- m_map_off %>%
                  setView(lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, zoom = input$zoom_map) 
              }
              
            }
            
            if (!is.na(dt$EOO))
            {
              shp_sf <- sf::st_as_sf(dt$EOO) %>%
                sf::st_transform(4326)
              
              m <- m %>% addPolylines(data = shp_sf,
                                      smoothFactor = 0.5,
                                      fillOpacity = 0.5,
                                      weight = 0.5,
                                      color = 'red',
                                      opacity = 0.8)
            }
            
            if (NROW(dt$occ_in_sel) >0)
            {
              
              # dt$occ_in_sel <- dt$occ_in_sel %>%
              #    # dplyr::mutate(cor=ifelse(!is.na(occ_in_sel$nomeUC), 'green', 'red'))#darkgreen
              #    dplyr::mutate(cor=ifelse(dt$occ_in_sel$verticeEOO==TRUE, 'blue', ifelse(dt$occ_in_sel$emUC==TRUE, 'green', 'red')))#darkgreen
              
              icons <- awesomeIcons(icon = "whatever",
                                    iconColor = "black",
                                    library = "ion",
                                    markerColor = dt$occ_in_sel$cor)
              
              link <- get_link_source_record(dt$occ_in_sel$Ctrl_occurrenceID,
                                             dt$occ_in_sel$Ctrl_bibliographicCitation,
                                             dt$occ_in_sel$Ctrl_scientificNameReference)
              
              
              etiquetaTexto <- paste0("ID na Fonte : <a href='", 
                                      # actionLink(inputId, label, icon = NULL, ...)
                                      "floradobrasil.jbrj.gov.br",
                                      "' target='_blank'>", dt$occ_in_sel$Ctrl_occurrenceID,"</a>",br(),
                                      
                                      ' Coleção: ', dt$occ_in_sel$Ctrl_collectionCode, ' ', dt$occ_in_sel$Ctrl_catalogNumber,br(),
                                      
                                      ' Coletor : ', dt$occ_in_sel$Ctrl_recordedBy,' ',dt$occ_in_sel$Ctrl_recordNumber, br(),
                                      dt$occ_in_sel$Ctrl_key_family_recordedBy_recordNumber,br(),
                                      ' Data : ', dt$occ_in_sel$Ctrl_day, "/" , dt$occ_in_sel$Ctrl_month, "/" , dt$occ_in_sel$Ctrl_year, br(),
                                      
                                      ' Identificação: ', dt$occ_in_sel$Ctrl_identifiedBy, ' em ', dt$occ_in_sel$Ctrl_dateIdentified,' ', dt$occ_in_sel$Ctrl_identificationQualifier,br(),
                                      ' País: ', dt$occ_in_sel$Ctrl_country_standardized,br(),
                                      ' Estado : ', dt$occ_in_sel$Ctrl_stateProvince_standardized,br(),
                                      ' Município: ', dt$occ_in_sel$Ctrl_municipality_standardized,br(),
                                      ' Localidade: ', dt$occ_in_sel$Ctrl_locality_standardized,br(),
                                      ' Tipo: ', dt$occ_in_sel$Ctrl_typeStatus,br(),
                                      ' Notas de pré-validação geográfica: ',dt$occ_in_sel$autoGeoNotes,br(),
                                      ' Notas de chegagem de campo : ',dt$occ_in_sel$verbatimNotes,br())
              
              label <- paste0(dt$occ_in_sel$Ctrl_occurrenceID, ' - ', dt$occ_in_sel$Ctrl_key_family_recordedBy_recordNumber,
                              ' / ', dt$occ_in_sel$Ctrl_year, 
                              ' / ', dt$occ_in_sel$Ctrl_municipality_standardized, ' - ',dt$occ_in_sel$Ctrl_stateProvince_standardized, ' - ', dt$occ_in_sel$Ctrl_country_standardized,
                              ' / Ident.: ', dt$occ_in_sel$Ctrl_identifiedBy)
              
              # popup_g <- etiquetaTexto
              
              # cor_label <-rep('black',dt$totalRegistros_in)
              # cor_label <- ifelse(dt$occ_in_sel$verticeEOO==TRUE,
              #                     'red',cor_label)
              # cor_label <- ifelse(dt$occ_in_sel$verticeEOO==TRUE & dt$occ_in_sel$Verificar_Vertice_EOO==TRUE,
              #                     'green',cor_label)
              
              
              m <- addAwesomeMarkers(m,
                                     lat = dt$occ_in_sel$Latitude,
                                     lng = dt$occ_in_sel$Longitude,
                                     # label = label,
                                     # # labelOptions = labelOptions(style = list( "color" = ifelse(dt$occ_in_sel$verticeEOO==TRUE,"red","black"))),
                                     # labelOptions = labelOptions(style = list( "color" = cor_label)),
                                     popup = link,
                                     options = popupOptions(openPopup = TRUE),
                                     icon =  icons,
                                     # group= ifelse(dt$occ_in_sel$verticeEOO==TRUE,'Vértice EOO','Pré-valiados BR'),
                                     layerId=dt$occ_in_sel$ID_PRV)
              
              
              # m <-  addCircleMarkers(m,
              #                        lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, 
              #                        label = dt$occ_in_sel$Ctrl_key_family_recordedBy_recordNumber,
              #                        popup = etiquetaTexto,
              #                        color = "red",
              #                        popupOptions = popupOptions(closeButton=F, closeOnClick=F))
              
              
              # m <- addMarkers(m,
              #                 # icon =  icons,
              #                 # group= ifelse(dt$occ_in_sel$verticeEOO==TRUE,'Vértice EOO','Pré-valiados BR'),
              #                 layerId=dt$occ_in_sel$ID_PRV,
              #                 lat = dt$occ_in_sel$Latitude, lng = dt$occ_in_sel$Longitude, 
              #                 popup = paste("<b>", etiquetaTexto, "</b></br>", 
              #                               # actionButton("selectlocation", "Select this Location", onclick = 'Shiny.onInputChange(\"button_click\",  Math.random())')))
              #                               actionButton("selectlocation", "Select this Location", onclick = 'Shiny.onInputChange(\"sp\",  Math.random())')))
              
              # id2 <- eventReactive(input$button_click, {
              #    input$map_marker_click$id
              # })
              
            }
            
            # if (NROW(dt$occ_global_sel) >0)
            # {
            #   
            #   etiquetaTexto <- paste0('ID na Fonte :',dt$occ_global_sel$Ctrl_occurrenceID, br(),
            #                           ' Coleção: ', dt$occ_global_sel$Ctrl_collectionCode, ' ', dt$occ_global_sel$Ctrl_catalogNumber,br(),
            #                           
            #                           ' Coletor : ', dt$occ_global_sel$Ctrl_recordedBy,' ',dt$occ_global_sel$Ctrl_recordNumber, br(),
            #                           dt$occ_global_sel$Ctrl_key_family_recordedBy_recordNumber,br(),
            #                           ' Data : ', dt$occ_global_sel$Ctrl_day, "/" , dt$occ_global_sel$Ctrl_month, "/" , dt$occ_global_sel$Ctrl_year, br(),
            #                           
            #                           ' Identificação: ', dt$occ_global_sel$Ctrl_identifiedBy, ' em ', dt$occ_global_sel$Ctrl_dateIdentified,' ', dt$occ_global_sel$Ctrl_identificationQualifier,br(),
            #                           ' País: ', dt$occ_global_sel$Ctrl_country_standardized,br(),
            #                           ' Estado : ', dt$occ_global_sel$Ctrl_stateProvince_standardized,br(),
            #                           ' Município: ', dt$occ_global_sel$Ctrl_municipality_standardized,br(),
            #                           ' Localidade: ', dt$occ_global_sel$Ctrl_locality_standardized,br(),
            #                           ' Tipo: ', dt$occ_global_sel$Ctrl_typeStatus,br(),
            #                           ' Notas de pré-validação geográfica: ',dt$occ_global_sel$autoGeoNotes,br(),
            #                           ' Notas de chegagem de campo : ',dt$occ_global_sel$verbatimNotes,br())
            #   
            #   label <- paste0(dt$occ_global_sel$Ctrl_occurrenceID, ' - ', dt$occ_global_sel$Ctrl_key_family_recordedBy_recordNumber,
            #                   ' / ', dt$occ_global_sel$Ctrl_year, 
            #                   ' / ', dt$occ_global_sel$Ctrl_municipality_standardized, ' - ',dt$occ_global_sel$Ctrl_stateProvince_standardized, ' - ', dt$occ_global_sel$Ctrl_country_standardized,
            #                   ' / Ident.: ', dt$occ_global_sel$Ctrl_identifiedBy)
            #   
            #   
            #   m <- addAwesomeMarkers(m,
            #                          lat = dt$occ_global_sel$Latitude,
            #                          lng = dt$occ_global_sel$Longitude,
            #                          label = label,
            #                          popup = etiquetaTexto,
            #                          options = popupOptions(openPopup = TRUE),
            #                          icon =    icons <- awesomeIcons(icon = "whatever",
            #                                                          iconColor = "black",
            #                                                          library = "ion",
            #                                                          markerColor = 'black'),
            #                          # group='Fora BR',
            #                          layerId=dt$occ_global_sel$ID_PRV
            #   )
            # }
            
            m
          }
        })
      }
      
      
      
      # graficos
      {
        output$serie_coleta <- renderImage({
          shiny::validate(
            need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
          
          outfile <- tempfile(fileext='.png')
          
          
          dt <- data_sel()
          serie_coleta <- dt$serie_coleta
          
          if(NROW(dt$serie_coleta)>0)
          {
            
            outfile <- tempfile(fileext='.png')
            # png(outfile, width=550, height=400)
            png(outfile, width=600, height=400)
            
            # x <- ts(serie_coleta, freq = 1, start = c(min(serie_coleta$Ctrl_year),max(serie_coleta$Ctrl_year)))
            # plot(x)
            barplot(serie_coleta$`COUNT(Ctrl_year)`, 
                    main = paste0('Cronologia de coletas: ',  dt$cronologia_coletas ), 
                    xlab='Anos', 
                    ylab='Número de Coletas', 
                    names.arg = serie_coleta$Ctrl_year, 
                    ylim=c(0, max(serie_coleta$`COUNT(Ctrl_year)`)), 
                    cex.names = 0.8, 
                    xaxs = "i",
                    legend.text='Registro em coleção')
            
            # dygraph(serie_coleta,
            #         main = "sp",#paste0("Coletas de",input$show_sp ," por ano no Brasil"),
            #         xlab = "Anos",
            #         ylab = "Coletas") %>%
            #    dySeries("COUNT(Ctrl_year)", color = "blue", label = "Coletas")
            
            # Generate a png
            dev.off()
          }
          
          list(src = outfile,
               alt = "espécime sem coletas")
          
        }, deleteFile = TRUE)
      }
      
      
      
      # infos
      {
        
        
        # update_unicode <- eventReactive(input$actbtn_unicode,{
        #   input$unicode
        # })
        
        output$status_avalacaoBox <- renderValueBox({
          valueBox(
            value = ifelse(status_avalacao() == TRUE, 'Avaliação concluída e armazenada com sucesso !', 'Avaliação em aberto...'), 
            "Estado da avaliação de risco de extinção", icon = icon("list"),
            color = ifelse(status_avalacao() == TRUE, 'green', 'orange'))
        })
        

        # Parametros LC
        {
          # eoo
          {
          output$eooBox <- renderValueBox({
            valueBox(
              data_sel()$EOO_area, "Extent of Occurrence (EOO)", icon = icon("list"), # Extent of Occurrence (EOO) < 30000 # Espécies amazônicas, 20000 
              color = ifelse(data_sel()$EOO_area < input$eoo_limit ,'red','green'))
          })
          
          output$eoo_map_Box <- renderValueBox({
            valueBox(
              data_sel()$EOO_area, "Extent of Occurrence (EOO)", icon = icon("list"), # Extent of Occurrence (EOO) < 30000 # Espécies amazônicas, 20000 
              color = ifelse(data_sel()$EOO_area < input$eoo_limit ,'red','green'))
          })
          
          output$eoo_tab_Box <- renderValueBox({
            valueBox(
              data_sel()$EOO_area, "Extent of Occurrence (EOO)", icon = icon("list"), # Extent of Occurrence (EOO) < 30000 # Espécies amazônicas, 20000 
              color = ifelse(data_sel()$EOO_area < input$eoo_limit ,'red','green'))
          })
          
          }
          
          output$aooBox <- renderValueBox({
            valueBox(
              (data_sel()$AOO2), "Area of occupancy (AOO)", icon = icon("list"),          # Area of occupancy (AOO) < 3000
              color = ifelse((data_sel()$AOO2) < input$aoo_limit,'red','green'))
          })
          
          output$nregBox <- renderValueBox({
            valueBox(
              data_sel()$totalRegistros_in, "Number of validated records in Brazil", icon = icon("list"),          # Number of records < 30
              # color = ifelse(data_sel()$AOO2<30,'red','green'))
              color = ifelse(data_sel()$totalRegistros_in < input$nreg_limit,'red','green'))
          })
          
          output$nreg_invalidadosBox <- renderValueBox({
            valueBox(
              data_sel()$totalRegistros_invalidados, "Number of invalidated records in Brazil", icon = icon("list"),          # Number of records < 30
              color = 'navy')#'fuchsia')
          })
          
          
          output$nreg_globalBox <- renderValueBox({
            valueBox(
              data_sel()$totalRegistros_global, "Number of records outside Brazil", icon = icon("list"),          # Number of records < 30
              color = 'navy')
            # red, yellow, aqua, blue, light-blue, green, navy, teal, olive, lime, orange, fuchsia, purple, maroon, black.
          })
          
          
          output$regionsBox <- renderValueBox({
            valueBox(
              # ifelse(data_sel()$sp_sel$use=='use',paste0("<a href='", data_sel()$sp_sel$url, "' target='_blank'>","YES","</a>"), 'NO'), "Use", icon = icon("list"),
              data_sel()$regions, "Number of municipality", icon = icon("list"),
              color = 'navy')
          })
          
          
          output$table_municipio <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE, scrollY = '300px', wid  = "100%", height = '300px'),
              {
                shiny::validate(
                  need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
                
                data_sel()$regions_names                     
              }))
          
          output$estadoBox <- renderValueBox({
            valueBox(
              
              # ifelse(data_sel()$sp_sel$use=='use',paste0("<a href='", data_sel()$sp_sel$url, "' target='_blank'>","YES","</a>"), 'NO'), "Use", icon = icon("list"),
              data_sel()$n_estados, "Number of State Province", icon = icon("list"),
              color = 'navy')
          })
          
          output$table_estado <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE, scrollY = '300px', wid  = "100%", height = '300px'),
              {
                shiny::validate(
                  need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
                
                data_sel()$estados_names                     
              }) %>%
              formatStyle(columns="inFB2020?", color = styleEqual(FALSE, "red") ))
          
          output$estadoFB2020Box <- renderValueBox({
            valueBox(
              data_sel()$sp_sel$location_FB2020, "State Province FB2020", icon = icon("list"),
              color = 'navy')
          })
          
          # situação de ameaça
          { 
          output$locationsBox <- renderValueBox({
            valueBox(
              data_sel()$locations_number, "Locations", icon = icon("list"),
              color = ifelse(data_sel()$locations_number > input$locations_min_number,'green','red'))
          })
          
          output$locations_map_Box <- renderValueBox({
            valueBox(
              data_sel()$locations_number, "Locations", icon = icon("list"),
              color = ifelse(data_sel()$locations_number > input$locations_min_number,'green','red'))
          })
          
          output$locations_tab_Box <- renderValueBox({
            valueBox(
              data_sel()$locations_number, "Locations", icon = icon("list"),
              color = ifelse(data_sel()$locations_number > input$locations_min_number,'green','red'))
          })
        }
          
          output$locations2000Box <- renderValueBox({
            valueBox(
              data_sel()$locations_number2000, "Locations 2 km", icon = icon("list"),
              color = 'navy')
          })
          
          
          output$locations50000Box <- renderValueBox({
            valueBox(
              data_sel()$locations_number50000, "Locations 50 km", icon("list"),
              color = 'navy')
          })
        }
        
        # FB2020 
        {
          
          output$group_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$group_FB2020), "Group", icon = icon("list"),
              color = 'navy')
          })
          
          output$family_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$FB2020_Family), "Family", icon = icon("list"),
              color = 'navy')
          })
          
          output$id_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$id_FB2020), "ID FB2020", icon = icon("list"),
              color = 'navy')
            # href = data_sel()$sp_sel$references_FB2020)
          })
          
          output$scientificName_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$scientificName_FB2020), "Scientific name", icon = icon("list"),
              color = 'navy',
              href = data_sel()$sp_sel$references_FB2020)
          })
          
          
          output$taxonRank_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$taxonRank_FB2020), "Taxon Rank", icon = icon("list"),
              color = 'navy')
          })
          
          output$taxonomicStatus_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$taxonomicStatus_FB2020), "Taxonomic Status", icon = icon("list"),
              color = ifelse(data_sel()$sp_sel$taxonomicStatus_FB2020=='NOME_ACEITO', 'blue', 'red'))
          })
          
          output$nomenclaturalStatus_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$nomenclaturalStatus_FB2020), "Nomenclatural Status", icon = icon("list"),
              color = ifelse(data_sel()$sp_sel$nomenclaturalStatus_FB2020 %in% c('NOME_CORRETO','NOME_CORRETO_VIA_CONSERVACAO'), 'blue', 'red'))
          })
          
          output$establishmentMeans_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$establishmentMeans_FB2020), "EstablishmentMeans", icon = icon("list"),
              color = ifelse(data_sel()$sp_sel$establishmentMeans_FB2020=='NATIVA', 'blue', 'red'))
          })
          
          output$endemism_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$endemism_FB2020), "Endemism Brazil", icon = icon("list"), 
              color = ifelse(data_sel()$sp_sel$endemism_FB2020=='Endêmica do Brasil' & data_sel()$totalRegistros_global < 1, 'blue', 'red'))
          })
          
          output$lifeForm_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$lifeForm_FB2020), "Life form", icon = icon("list"), 
              color = 'navy')
          })
          
          output$habitat_FB2020Box <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$habitat_FB2020), "Habitat", icon = icon("list"), 
              color = 'navy')
          })
          
          output$vernacular_FB2020 <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$sp_sel$vernacular_FB2020), "Vernacular name0", icon = icon("list"), 
              color = 'navy')
          })
          
        }           
        
        # # IUCN
        # {
        #    output$IUCN_assessment_presenceBox <- renderValueBox({
        #       valueBox(
        #          value = na.omit(data_sel()$sp_sel$IUCN_assessment_presence), "IUCN Assessment", icon = icon("list"),
        #          color = ifelse( gsub(' ','',data_sel()$sp_sel$IUCN_assessment_presence) == 'NO', 'blue', 'green'))
        #    })
        #    
        #    
        # }
        
        # biomas
        {
          output$table_bioma <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE, scrollY = '300px', wid  = "100%", height = '300px'),
              {
                shiny::validate(
                  need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
                
                dt <- data_sel()
                dt$biomas_names                     
              }) %>%
              formatStyle(columns="inFB2020?", color = styleEqual(FALSE, "red") )
            
            
            
            # formatStyle(columns="Biome", color = ifelse(dt$biomas_names$`inFB2020?`==TRUE, 'green','red') ) #backgroundColor = 'red') #
          )
          
          output$biomeBox <- renderValueBox({
            valueBox(
              data_sel()$n_biomas, "Number of Biomes", icon = icon("list"),
              color = 'navy')
          })
          
          output$biomeFB2020Box <- renderValueBox({
            valueBox(
              na.omit(data_sel()$sp_sel$occurrenceRemarks_FB2020), "Biomes FB2020" ,icon = icon("list"),
              color = 'navy')
          })
          
          
        }
        
        # UC
        {
          
          output$nreg_emUC_PIBox <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$nreg_emUC_PI), "Number of records in PI", icon = icon("list"),
              color = 'navy')
          })
          
          output$nreg_emUC_USBox <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$nreg_emUC_US), "Number of records in US", icon = icon("list"),
              color = 'navy')
          })
          
          output$nUC_PIBox <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$nUC_PI), "Number of conservation units PI", icon = icon("list"),
              color = 'navy')
          })
          
          output$nUC_USBox <- renderValueBox({
            valueBox(
              value = na.omit(data_sel()$nUC_US), "Number of conservation units US", icon = icon("list"),
              color = 'navy')
          })
          
          output$table_uc_PI <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE, scrollY = '300px', wid  = "100%", height = '300px'),
              {
                shiny::validate(
                  need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
                
                data_sel()$uc_names_PI                 
              }))
          
          output$table_uc_US <- DT::renderDataTable(
            DT::datatable(
              options = list(searching = FALSE, paging=FALSE, ordering=FALSE, scrollY = '300px', wid  = "100%", height = '300px'),
              {
                shiny::validate(
                  need(data_sel()$totalRegistros_in>0,  "Espécie sem registros válidos!"))
                data_sel()$uc_names_US                 
              }))
        }
        
        output$table_spp <- DT::renderDataTable(
          DT::datatable(
            # options = list(dom = 't'),
            options = list(searching = FALSE, paging=FALSE, ordering=FALSE),
            {
              dt <- data_sel()
              x <- dt$sp_sel
              x <- t(x) %>% as.data.frame()
              colnames(x) <- c('Informação')
              x
            }))
      }
    }
  }
  
}


#' @section 2. Executar aplicativo
shinyApp(ui, server)







# Tarefas:
# checar se ha THREAT?
# Salvar todas as tags da avaliação
# Frase quando não houver dados populacionais
# Numero total de registros BR na aba 2 e 3
# Salvar ooc completas

# ajustar descricao sp:
# texto mal amostra
# texto dd